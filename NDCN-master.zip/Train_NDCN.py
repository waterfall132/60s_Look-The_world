#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Train NDCN (Non-negative Decoupling and Contrast Network).
Built on the DN4 (2023) codebase by Wenbin Li.

Quick start
    python Train_NDCN.py --dataset_dir /path/to/CUB --data_name CubBird \
        --encoder_model ResNet12_ReLU --classifier_model NDCN \
        --way_num 5 --shot_num 1
"""

from __future__ import print_function
import argparse
import os
import json
import numpy as np
import torch
import torch.nn as nn
import torch.backends.cudnn as cudnn
import torch.optim as optim
import time
from PIL import ImageFile
import sys
sys.dont_write_bytecode = True

import dataset.general_dataloader as FewShotDataloader
import models.network as FewShotNet
import utils

ImageFile.LOAD_TRUNCATED_IMAGES = True
os.environ['CUDA_DEVICE_ORDER'] = 'PCI_BUS_ID'
os.environ.setdefault('CUDA_VISIBLE_DEVICES', '0')


parser = argparse.ArgumentParser()
# ------------------------------ data / io ---------------------------------
parser.add_argument('--dataset_dir', default='/data/Datasets/CUB_birds/For_FewShot')
parser.add_argument('--data_name', default='CubBird', help='miniImageNet|StanfordDog|StanfordCar|CubBird')
parser.add_argument('--mode', default='train')
parser.add_argument('--outf', default='./results/NDCN_')
parser.add_argument('--resume', default='', type=str)
parser.add_argument('--workers', type=int, default=4)
parser.add_argument('--imageSize', type=int, default=84)
parser.add_argument('--train_aug', action='store_true', default=True)
parser.add_argument('--test_aug', action='store_true', default=False)
# ------------------------------ model -------------------------------------
parser.add_argument('--encoder_model', default='ResNet12_ReLU',
					help='Conv64F_Local_ReLU|ResNet12_ReLU|Conv64F_Local|ResNet12')
parser.add_argument('--classifier_model', default='NDCN', help='NDCN|DN4|ProtoNet')
parser.add_argument('--neighbor_k', type=int, default=3)
# ------------------------------ few-shot ----------------------------------
parser.add_argument('--episodeSize', type=int, default=1)
parser.add_argument('--testepisodeSize', type=int, default=1)
parser.add_argument('--epochs', type=int, default=30)
parser.add_argument('--start_epoch', default=0, type=int)
parser.add_argument('--episode_train_num', type=int, default=4000)
parser.add_argument('--episode_val_num', type=int, default=1000)
parser.add_argument('--episode_test_num', type=int, default=1000)
parser.add_argument('--way_num', type=int, default=5)
parser.add_argument('--shot_num', type=int, default=1)
parser.add_argument('--query_num', type=int, default=15)
parser.add_argument('--aug_shot_num', type=int, default=20)
# ------------------------------ NDCN --------------------------------------
ndcn = parser.add_argument_group('NDCN')
ndcn.add_argument('--rank', type=int, default=5, help='r: number of NMF components')
ndcn.add_argument('--n_iter', type=int, default=3, help='T: multiplicative updates')
ndcn.add_argument('--beta', type=float, default=10.0, help='init of gamma_fg (gamma_bg = beta/2)')
ndcn.add_argument('--margin', type=float, default=0.3, help='Delta in the triplet/bg losses')
ndcn.add_argument('--eta', type=float, default=0.1, help='weight of the whole auxiliary loss')
ndcn.add_argument('--lambda_bg', type=float, default=0.05)
ndcn.add_argument('--lambda_div', type=float, default=0.01)
ndcn.add_argument('--lambda_mask', type=float, default=0.001)
ndcn.add_argument('--nonneg_mode', default='relu', choices=['relu', 'shift', 'abs', 'none'],
				  help='how to enforce Z >= 0 when the backbone is not ReLU-terminated')
ndcn.add_argument('--score_mode', default='ref', choices=['ref', 'free'],
				  help='ref = reference-direction alpha; free = activation-norm alpha')
ndcn.add_argument('--frontend', default='ndm', choices=['ndm', 'mustd'])
ndcn.add_argument('--grad_all_iters', action='store_true', default=False,
				  help='backprop through all T updates instead of only the last')
# --------------------- ablation switches (all default ON) ------------------
ab = parser.add_argument_group('ablation')
ab.add_argument('--no_bg_sep', action='store_true', help='drop d_bg_sep from the logit')
ab.add_argument('--no_qbg', action='store_true', help='drop d_qbg from the logit  <-- the (c+) run')
ab.add_argument('--no_triplet', action='store_true')
ab.add_argument('--no_bgloss', action='store_true')
ab.add_argument('--no_div', action='store_true')
ab.add_argument('--no_mask', action='store_true')
# ------------------------------ optim -------------------------------------
parser.add_argument('--lr', type=float, default=0.05)
parser.add_argument('--cosine', type=bool, default=True)
parser.add_argument('--lr_decay_epochs', type=list, default=[60, 80])
parser.add_argument('--lr_decay_rate', type=float, default=0.1)
parser.add_argument('--weight_decay', type=float, default=5e-4)
parser.add_argument('--momentum', type=float, default=0.9)
parser.add_argument('--adam', action='store_true', default=False)
parser.add_argument('--beta1', type=float, default=0.5)
parser.add_argument('--cuda', action='store_true', default=True)
parser.add_argument('--ngpu', type=int, default=1)
parser.add_argument('--nc', type=int, default=3)
parser.add_argument('--print_freq', '-p', default=100, type=int)
parser.add_argument('--seed', type=int, default=0)
opt = parser.parse_args()
opt.cuda = True
cudnn.benchmark = True

torch.manual_seed(opt.seed)
np.random.seed(opt.seed)


def build_ndcn_cfg(opt):
	return dict(
		rank=opt.rank, n_iter=opt.n_iter, beta=opt.beta, margin=opt.margin,
		lambda_bg=opt.lambda_bg, lambda_div=opt.lambda_div, lambda_mask=opt.lambda_mask,
		score_mode=opt.score_mode, frontend=opt.frontend, nonneg_mode=opt.nonneg_mode,
		use_bg_sep=not opt.no_bg_sep, use_qbg=not opt.no_qbg,
		use_triplet=not opt.no_triplet, use_bgloss=not opt.no_bgloss,
		use_div=not opt.no_div, use_mask=not opt.no_mask,
		grad_last_only=not opt.grad_all_iters,
	)


# ============================== train =====================================
def train(train_loader, model, criterion, optimizer, epoch_index, F_txt):
	batch_time, data_time = utils.AverageMeter(), utils.AverageMeter()
	losses, top1 = utils.AverageMeter(), utils.AverageMeter()
	aux_meters = {k: utils.AverageMeter() for k in ['triplet', 'bg', 'div', 'mask']}

	model.train()
	end = time.time()
	for episode_index, (query_images, query_targets, support_images, support_targets) in enumerate(train_loader):
		data_time.update(time.time() - end)

		input_var1 = torch.cat(query_images, 0).cuda()
		input_var2 = torch.cat(support_images, 0).squeeze(0).cuda()
		input_var2 = input_var2.contiguous().view(-1, input_var2.size(2),
												 input_var2.size(3), input_var2.size(4))
		target = torch.cat(query_targets, 0).cuda()

		if opt.classifier_model == 'NDCN':
			output, aux = model(input_var1, input_var2, target)
			loss = criterion(output, target) + opt.eta * aux['total']
			for k in aux_meters:
				aux_meters[k].update(float(aux[k]), target.size(0))
		else:
			output = model(input_var1, input_var2)
			loss = criterion(output, target)

		prec1, _ = utils.accuracy(output, target, topk=(1, 3))
		losses.update(loss.item(), target.size(0))
		top1.update(prec1[0], target.size(0))

		optimizer.zero_grad()
		loss.backward()
		optimizer.step()

		batch_time.update(time.time() - end)
		end = time.time()

		if episode_index % opt.print_freq == 0 and episode_index != 0:
			msg = ('Epoch-({0}): [{1}/{2}]\t'
				   'Time {batch_time.val:.2f} ({batch_time.avg:.2f})\t'
				   'Loss {loss.val:.2f} ({loss.avg:.2f})\t'
				   'Prec@1 {top1.val:.2f} ({top1.avg:.2f})').format(
					   epoch_index, episode_index, len(train_loader),
					   batch_time=batch_time, loss=losses, top1=top1)
			if opt.classifier_model == 'NDCN':
				msg += '\t[tri {:.3f} bg {:.3f} div {:.3f} mask {:.3f}]'.format(
					aux_meters['triplet'].avg, aux_meters['bg'].avg,
					aux_meters['div'].avg, aux_meters['mask'].avg)
			print(msg)
			print(msg, file=F_txt)

	return top1.avg, losses.avg


# ============================== validate ==================================
def validate(val_loader, model, criterion, epoch_index, best_prec1, F_txt, tag='Val'):
	batch_time, losses, top1 = utils.AverageMeter(), utils.AverageMeter(), utils.AverageMeter()
	model.eval()
	accuracies = []

	end = time.time()
	for episode_index, (query_images, query_targets, support_images, support_targets) in enumerate(val_loader):
		input_var1 = torch.cat(query_images, 0).cuda()
		input_var2 = torch.cat(support_images, 0).squeeze(0).cuda()
		input_var2 = input_var2.contiguous().view(-1, input_var2.size(2),
												 input_var2.size(3), input_var2.size(4))
		target = torch.cat(query_targets, 0).cuda()

		output = model(input_var1, input_var2)          # eval mode -> logits only
		loss = criterion(output, target)

		prec1, _ = utils.accuracy(output, target, topk=(1, 3))
		losses.update(loss.item(), target.size(0))
		top1.update(prec1[0], target.size(0))
		accuracies.append(prec1)

		batch_time.update(time.time() - end)
		end = time.time()

		if episode_index % opt.print_freq == 0 and episode_index != 0:
			msg = ('{tag}-({0}): [{1}/{2}]\t'
				   'Time {batch_time.val:.2f} ({batch_time.avg:.2f})\t'
				   'Loss {loss.val:.2f} ({loss.avg:.2f})\t'
				   'Prec@1 {top1.val:.2f} ({top1.avg:.2f})').format(
					   epoch_index, episode_index, len(val_loader), tag=tag,
					   batch_time=batch_time, loss=losses, top1=top1)
			print(msg)
			print(msg, file=F_txt)

	print(' * Prec@1 {top1.avg:.2f} Best_prec1 {best_prec1:.2f}'.format(top1=top1, best_prec1=best_prec1))
	print(' * Prec@1 {top1.avg:.2f} Best_prec1 {best_prec1:.2f}'.format(top1=top1, best_prec1=best_prec1), file=F_txt)
	return top1.avg, losses.avg, accuracies


def log_scalars(model, F_txt):
	"""Print the three learnable logit scalars (Table: learned three-way weights)."""
	m = model.module if hasattr(model, 'module') else model
	if m.classifier_model != 'NDCN':
		return
	c = m.classifier
	line = ('  [logit scalars] |gamma_fg| = {:.3f}   |gamma_bg| = {:.3f}   beta_bg = {:+.3f}'
			.format(float(c.gamma_fg.abs()), float(c.gamma_bg.abs()), float(c.beta_bg)))
	diag = getattr(c, '_diag', {})
	if diag:
		line += ('\n  [diagnostics]   mask_mean(q) = {:.3f}  mask_mean(s) = {:.3f}  '
				 'alpha>0.7 = {:.2f}  proto_offdiag_cos = {:.3f}').format(
			float(diag['mask_mean_q']), float(diag['mask_mean_s']),
			float(diag['alpha_hi']), float(diag['proto_offdiag']))
	print(line)
	print(line, file=F_txt)


if __name__ == '__main__':
	opt.outf, F_txt = utils.set_save_path(opt)

	global best_prec1
	best_prec1 = 0
	model = FewShotNet.define_model(
		encoder_model=opt.encoder_model, classifier_model=opt.classifier_model,
		norm='batch', way_num=opt.way_num, shot_num=opt.shot_num,
		init_type='normal', use_gpu=opt.cuda,
		ndcn_cfg=build_ndcn_cfg(opt) if opt.classifier_model == 'NDCN' else None)

	criterion = nn.CrossEntropyLoss().cuda()
	if opt.adam:
		optimizer = optim.Adam(model.parameters(), lr=opt.lr, betas=(opt.beta1, 0.9), weight_decay=0.0005)
		print("Using Adam Optimizer")
	else:
		optimizer = optim.SGD(model.parameters(), lr=opt.lr, momentum=0.9,
							  dampening=0.9, weight_decay=0.001)
		print("Using SGD Optimizer")

	if opt.resume:
		checkpoint = utils.get_resume_file(opt.resume, F_txt)
		opt.start_epoch = checkpoint['epoch_index']
		best_prec1 = checkpoint['best_prec1']
		model.load_state_dict(checkpoint['model'])
		optimizer.load_state_dict(checkpoint['optimizer'])

	if opt.ngpu > 1:
		model = nn.DataParallel(model, range(opt.ngpu))

	print(opt); print(opt, file=F_txt)
	print(model); print(model, file=F_txt)
	with open(os.path.join(opt.outf, 'config.json'), 'w') as f:
		json.dump(vars(opt), f, indent=2, default=str)

	if opt.cosine:
		eta_min = opt.lr * (opt.lr_decay_rate ** 3)
		scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, opt.epochs, eta_min, -1)

	print('===================================== Training =====================================')
	print('===================================== Training =====================================', file=F_txt)

	Train_losses, Val_losses, Test_losses = [], [], []
	for epoch_item in range(opt.start_epoch, opt.epochs):
		print('==================== Epoch %d ====================' % epoch_item)
		print('==================== Epoch %d ====================' % epoch_item, file=F_txt)

		opt.current_epoch = epoch_item
		train_loader, val_loader, test_loader = FewShotDataloader.get_Fewshot_dataloader(
			opt, ['train', 'val', 'test'])

		prec1_train, train_loss = train(train_loader, model, criterion, optimizer, epoch_item, F_txt)
		Train_losses.append(train_loss)
		log_scalars(model, F_txt)

		with torch.no_grad():
			prec1_val, val_loss, _ = validate(val_loader, model, criterion, epoch_item,
											  best_prec1, F_txt, tag='Val')
		Val_losses.append(val_loss)

		with torch.no_grad():
			prec1_test, test_loss, _ = validate(test_loader, model, criterion, epoch_item,
												best_prec1, F_txt, tag='Test')
		Test_losses.append(test_loss)

		if opt.cosine:
			scheduler.step()
		else:
			utils.adjust_learning_rate(opt, optimizer, epoch_item, F_txt)

		is_best = prec1_val > best_prec1
		best_prec1 = max(prec1_val, best_prec1)

		state = {'epoch_index': epoch_item,
				 'encoder_model': opt.encoder_model,
				 'classifier_model': opt.classifier_model,
				 'ndcn_cfg': build_ndcn_cfg(opt) if opt.classifier_model == 'NDCN' else None,
				 'model': model.state_dict(),
				 'best_prec1': best_prec1,
				 'optimizer': optimizer.state_dict()}
		if is_best:
			utils.save_checkpoint(state, os.path.join(opt.outf, 'model_best.pth.tar'))
		if epoch_item % 10 == 0:
			utils.save_checkpoint(state, os.path.join(opt.outf, 'epoch_%d.pth.tar' % epoch_item))

	utils.plot_loss_curve(opt, Train_losses, Val_losses, Test_losses)
	print('======================================== Training is END ========================================\n')
	print('======================================== Training is END ========================================\n', file=F_txt)
	F_txt.close()
