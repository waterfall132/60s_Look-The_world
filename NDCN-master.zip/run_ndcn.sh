#!/usr/bin/env bash
# =====================================================================
# NDCN experiment runner
#
#   bash run_ndcn.sh stage0        # environment + dataset checks
#   bash run_ndcn.sh stage1        # 5-minute sanity run
#   bash run_ndcn.sh stage2        # baselines (DN4 / ProtoNet)
#   bash run_ndcn.sh stage3        # main Conv-4 results
#   bash run_ndcn.sh stage4        # main ResNet-12 results
#   bash run_ndcn.sh stage5        # component + loss ablations
#   bash run_ndcn.sh stage6        # frontend / score-mode / sensitivity
#
# EDIT THESE THREE LINES FIRST
# =====================================================================
CUB=/data/Datasets/CUB_birds/For_FewShot
DOG=/data/Datasets/Stanford_dogs/For_FewShot
CAR=/data/Datasets/Stanford_cars/For_FewShot
GPU=0

set -e
export CUDA_VISIBLE_DEVICES=$GPU
STAGE=${1:-stage0}

run () { echo; echo ">>> $*"; echo; python "$@"; }

# ---------------------------------------------------------------- stage 0
if [ "$STAGE" = "stage0" ]; then
  run smoke_test.py
  for d in $CUB $DOG $CAR; do
    run check_dataset.py --dataset_dir $d --shot_num 5 --query_num 15
  done
fi

# ---------------------------------------------------------------- stage 1
# Tiny run. Purpose: confirm the loop trains and the diagnostics look sane.
# Expect accuracy to climb above chance (20%) within the first epoch.
if [ "$STAGE" = "stage1" ]; then
  run Train_NDCN.py --dataset_dir $CUB --data_name CubBird \
      --encoder_model Conv64F_Local_ReLU --classifier_model NDCN \
      --way_num 5 --shot_num 1 \
      --epochs 2 --episode_train_num 200 --episode_val_num 100 --episode_test_num 100 \
      --print_freq 50 --outf ./results/SANITY_
fi

# ---------------------------------------------------------------- stage 2
# Baselines under YOUR splits, so the comparison in the paper is apples-to-apples.
if [ "$STAGE" = "stage2" ]; then
  for SHOT in 1 5; do
    run Train_DN4.py --dataset_dir $CUB --data_name CubBird \
        --encoder_model Conv64F_Local --classifier_model DN4 \
        --way_num 5 --shot_num $SHOT --epochs 30 --outf ./results/BASE_DN4_
    run Train_DN4.py --dataset_dir $CUB --data_name CubBird \
        --encoder_model Conv64F --classifier_model ProtoNet \
        --way_num 5 --shot_num $SHOT --epochs 30 --outf ./results/BASE_PN_
  done
fi

# ---------------------------------------------------------------- stage 3
if [ "$STAGE" = "stage3" ]; then
  for DS in "CUB:$CUB:CubBird" "DOG:$DOG:StanfordDog" "CAR:$CAR:StanfordCar"; do
    IFS=: read -r TAG DIR NAME <<< "$DS"
    for SHOT in 1 5; do
      run Train_NDCN.py --dataset_dir $DIR --data_name $NAME \
          --encoder_model Conv64F_Local_ReLU --classifier_model NDCN \
          --way_num 5 --shot_num $SHOT --epochs 30 \
          --episode_train_num 4000 --outf ./results/MAIN_C4_
    done
  done
fi

# ---------------------------------------------------------------- stage 4
if [ "$STAGE" = "stage4" ]; then
  for DS in "CUB:$CUB:CubBird" "DOG:$DOG:StanfordDog" "CAR:$CAR:StanfordCar"; do
    IFS=: read -r TAG DIR NAME <<< "$DS"
    for SHOT in 1 5; do
      run Train_NDCN.py --dataset_dir $DIR --data_name $NAME \
          --encoder_model ResNet12_ReLU --classifier_model NDCN \
          --way_num 5 --shot_num $SHOT --epochs 30 \
          --episode_train_num 4000 --lr 0.05 --outf ./results/MAIN_R12_
    done
  done
fi

# ---------------------------------------------------------------- stage 5
# Component ablation. (c+) is the row the manuscript is missing.
if [ "$STAGE" = "stage5" ]; then
  COMMON="--dataset_dir $CUB --data_name CubBird --encoder_model ResNet12_ReLU \
          --classifier_model NDCN --way_num 5 --shot_num 1 --epochs 30"

  run Train_NDCN.py $COMMON --outf ./results/ABL_c_  \
      --no_bg_sep --no_qbg --no_triplet --no_bgloss --no_div --no_mask
  run Train_NDCN.py $COMMON --outf ./results/ABL_cp_ \
      --no_qbg --no_triplet --no_bgloss --no_div --no_mask      # (c+) two-way
  run Train_NDCN.py $COMMON --outf ./results/ABL_d_  \
      --no_triplet --no_bgloss --no_div --no_mask
  run Train_NDCN.py $COMMON --outf ./results/ABL_e_

  # loss ablation
  run Train_NDCN.py $COMMON --outf ./results/L_tri_  --no_bgloss --no_div --no_mask
  run Train_NDCN.py $COMMON --outf ./results/L_bg_   --no_div --no_mask
  run Train_NDCN.py $COMMON --outf ./results/L_div_  --no_mask
fi

# ---------------------------------------------------------------- stage 6
if [ "$STAGE" = "stage6" ]; then
  COMMON="--dataset_dir $CUB --data_name CubBird --encoder_model ResNet12_ReLU \
          --classifier_model NDCN --way_num 5 --shot_num 1 --epochs 30"

  # frontend generality
  run Train_NDCN.py $COMMON --frontend mustd --outf ./results/FE_mustd_
  run Train_NDCN.py $COMMON --frontend mustd --no_bg_sep --no_qbg --no_bgloss \
      --outf ./results/FE_mustd_fgonly_
  run Train_NDCN.py $COMMON --frontend ndm   --no_bg_sep --no_qbg --no_bgloss \
      --outf ./results/FE_ndm_fgonly_

  # reference-free scoring  (the high-clutter configuration)
  run Train_NDCN.py $COMMON --score_mode free --outf ./results/SM_free_

  # non-negativity study: original LeakyReLU backbone + clipping
  run Train_NDCN.py $COMMON --encoder_model ResNet12 --nonneg_mode relu \
      --outf ./results/NN_clip_

  # gradient through all T updates
  run Train_NDCN.py $COMMON --grad_all_iters --outf ./results/G_allT_

  # sensitivity sweeps
  for R in 2 3 7 9;      do run Train_NDCN.py $COMMON --rank $R   --outf ./results/S_r${R}_;   done
  for T in 1 2 4 5;      do run Train_NDCN.py $COMMON --n_iter $T --outf ./results/S_T${T}_;   done
  for M in 0.1 0.2 0.4 0.5; do run Train_NDCN.py $COMMON --margin $M --outf ./results/S_m${M}_; done
  for E in 0.01 0.05 0.2 0.5; do run Train_NDCN.py $COMMON --eta $E --outf ./results/S_e${E}_; done
fi

echo; echo "stage $STAGE finished."
