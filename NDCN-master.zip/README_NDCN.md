# NDCN 代码包 — 使用说明

基于 DN4 (2023) 代码库实现。放进你的 DN4 目录即可。

```
DN4/
├── models/
│   ├── backbone.py          ← 原样保留
│   ├── classifier.py        ← 原样保留
│   ├── ndcn.py              ← 新增
│   ├── backbone_relu.py     ← 新增
│   └── network.py           ← 替换
├── dataset/general_dataloader.py   ← 原样保留
├── utils.py                 ← 原样保留
├── Train_NDCN.py            ← 新增
├── Test_NDCN.py             ← 新增
└── smoke_test.py            ← 新增（先跑这个）
```

第一步（不用 GPU，30 秒）：

```bash
python smoke_test.py     # 25 项检查应全部 PASS
```

---

## ⚠️ 必读：非负性问题

论文假设骨干网络输出 **Z ≥ 0**。但这份代码库里：

| Backbone | 末端激活 | 负值占比 |
|---|---|---|
| `Conv64F` | ReLU ✅ | 0% |
| `Conv64F_Local` | **LeakyReLU(0.2)** ❌ | ~35–45% |
| `ResNet12` | **LeakyReLU(0.1)** ❌ | ~30–40% |

**如果不处理，NMF 会在一个含大量负数的矩阵上跑，分解结果无意义，Proposition 1/2 也不成立。**

两种解法：

**方案 A（推荐，用于论文报告的数字）** — 用 ReLU 版骨干，假设严格成立：
```bash
--encoder_model ResNet12_ReLU          # 或 Conv64F_Local_ReLU
```
`backbone_relu.py` 里的 `_relu_patch()` 递归把 LeakyReLU 换成 ReLU，其余结构完全不变。

**方案 B（快速验证）** — 保留原骨干，截断负值：
```bash
--encoder_model ResNet12 --nonneg_mode relu
```

⚠️ 不要用 `--nonneg_mode shift`。平移会给所有元素加同一个常数，等于凭空造出一个"处处存在的直流成分"，会显著破坏部件性（Proposition 2），α 打分会失效。它只作为诊断用途留在代码里。

**建议第一件事**：先跑 A 和 B 各一次，把差值记下来。如果差距很小，说明非负性在实践中不敏感，你可以在 Limitations 里如实报告；如果差距大，说明这个假设是实质性的，那更要用方案 A。

---

## 训练

```bash
# CUB, ResNet12, 5-way 1-shot
python Train_NDCN.py \
    --dataset_dir /path/to/CUB_birds/For_FewShot \
    --data_name CubBird \
    --encoder_model ResNet12_ReLU \
    --classifier_model NDCN \
    --way_num 5 --shot_num 1 \
    --epochs 30 --episode_train_num 4000

# Conv-4
python Train_NDCN.py ... --encoder_model Conv64F_Local_ReLU --lr 0.05
```

每个 epoch 结束会打印：

```
[logit scalars] |gamma_fg| = 12.431   |gamma_bg| = 4.882   beta_bg = +0.371
[diagnostics]   mask_mean(q) = 0.447  mask_mean(s) = 0.462  alpha>0.7 = 2.31  proto_offdiag_cos = 0.208
```

这四个诊断量直接对应你论文里的四个说法（掩码均值 ≈0.45、平均 2.4 个高 α 成分、原型不塌缩）。**训练时就盯着它们**，如果 `mask_mean` 跑到 0.05 或 0.95，说明掩码塌缩了，需要调 `--lambda_mask`。

## 测试

```bash
python Test_NDCN.py \
    --resume ./results/NDCN_NDCN_ResNet12_ReLU_Epoch_30_CubBird_84_84_5Way_1Shot/ \
    --dataset_dir /path/to/CUB_birds/For_FewShot --data_name CubBird \
    --encoder_model ResNet12_ReLU --shot_num 1 \
    --dump_diag
```

`--dump_diag` 会输出 `diagnostics.npz` 并直接打印**按前景占比分箱的准确率表** —— 就是我们讨论的"风险二"那组实验。

---

## 论文里各个表对应的命令

### 表：成分消融（Table `tab:ablation`）

| 配置 | 命令附加参数 |
|---|---|
| (c) 只有前景匹配 | `--no_bg_sep --no_qbg --no_triplet --no_bgloss --no_div --no_mask` |
| (c+) 两路 **← 你缺的那一行** | `--no_qbg --no_triplet --no_bgloss --no_div --no_mask` |
| (d) 三路，无辅助损失 | `--no_triplet --no_bgloss --no_div --no_mask` |
| (e) 完整 NDCN | （不加任何 `--no_*`） |

`(c+)` 与 `(d)` 的差值就是 $d_{qbg}$ 的真实贡献。我的预测是 0.1–0.3 个点。

### 表：辅助损失消融（Table `tab:loss_ablation`）

```bash
--no_triplet --no_bgloss --no_div --no_mask     # 基线
--no_bgloss --no_div --no_mask                  # +triplet
--no_div --no_mask                              # +bg
--no_mask                                       # +div
（不加）                                         # 全部
```

### 表：前端通用性（Table `tab:generality`）

```bash
--frontend mustd                # 统计阈值前端（零参数）
--frontend ndm                  # 我们的非负分解
```
每个前端各跑两次：加 `--no_bg_sep --no_qbg --no_bgloss`（FG only）和不加（+BG reuse）。

### 无参考变体（§Mechanism Verification）

```bash
--score_mode free               # 完全不用参考方向，α 由激活能量决定
```
⚠️ 这一项就是我们讨论的"风险一"的解药。建议在**未裁剪的 Dogs / Cars** 上跑 `ref` vs `free` 的对比，如果 `free` 在高杂波数据上反超，那就是一个很强的卖点。

### 超参敏感性（Table `tab:sensitivity`）

```bash
--rank 2 / 3 / 5 / 7 / 9
--n_iter 1 / 2 / 3 / 4 / 5
--margin 0.1 / 0.2 / 0.3 / 0.4 / 0.5
--eta 0.01 / 0.05 / 0.1 / 0.2 / 0.5
--grad_all_iters                # 对照“只回传最后一次更新”的设计
```

### 1-shot vs 5-shot 的 β_bg（我建议补的那一格）

分别用 `--shot_num 1` 和 `--shot_num 5` 训练，看每个 epoch 打印的 `beta_bg`。零额外成本。

---

## 实现要点（与论文的对应关系）

| 论文 | 代码 |
|---|---|
| Eq.(3) NMF 目标 | `NDM.forward` |
| NNDSVD 确定性初始化 | `NDM._nndsvd_init`，全程 `@torch.no_grad()` |
| Eq.(4)(5) 乘法更新 | `NDM._mu_step` |
| 只回传最后一次更新 | `grad_last_only=True`：前 T−1 次在 `no_grad` 下跑并 detach |
| Eq.(6) 行归一化 | `A = W / W.sum(dim=2)` |
| Eq.(7) α 打分 | `NDCN_Metric._alpha`，`score_mode='ref'` |
| Eq.(10) 无参考打分 | `score_mode='free'` |
| Eq.(8) 软掩码 | `_mask`，`clamp(...,0,1)` |
| Eq.(11) 前景/背景池化 | `_pool` |
| Eq.(14) 类原型 | 在 K 张支持图上**联合**质量加权池化，不是逐图池化再平均 |
| Eq.(12) 三路 logit | `forward` 中的 `logit = ...` |
| Eq.(16)(17) 双负样本对比 | `_aux_losses` |

**参数量**：`smoke_test.py` 会验证 head 恰好有 **3 个**参数（`gamma_fg`, `gamma_bg`, `beta_bg`），对应论文 Table `tab:complexity` 里的 "Extra Params = 0"。

**SVD 的梯度**：初始化在 `no_grad` 下，所以永远不会对 SVD 求导（SVD 反向在奇异值接近时数值不稳）。这是有意的。

---

## 已知注意事项

1. **乘法更新收敛慢。** T=3 只是部分收敛（我实测在人造 rank-5 数据上 0.41→0.26）。这不是 bug，MU 是一阶方法。论文里报告的重构误差轨迹要用**真实特征**测，别用随机数。跑 `NDM.recon_trajectory(Z)` 拿真实曲线。

2. **`clamp_min(eps)` 很关键。** sklearn 的 MU + nndsvd 组合会警告"零元素无法被乘法更新修正"。我在初始化后加了 `clamp_min(eps)`，实测收敛比 sklearn 更好（200 步 0.062 vs 0.159）。别删这行。

3. **速度**：CPU 上约 95 ms/episode（ResNet12 形状）。GPU 上主要开销是批量 SVD；如果嫌慢，`--n_iter` 不影响 SVD 次数，真正的开销在 `torch.linalg.svd`。25×640 的批量 SVD 在 3090 上应该 < 5 ms。

4. **Conv-4 的 L=441**，SVD 是 441×64，比 ResNet12 的 25×640 稍慢，但成分数 r=5 远小于 64，分解更稳定。

5. **`--dump_diag` 里的 `R_before` 是代理量**（用"能量最高的一半位置占总能量的比例"），不是真的分割标注。论文里要如实说明这一点，或者接上 CUB 的真实分割标注重算。
