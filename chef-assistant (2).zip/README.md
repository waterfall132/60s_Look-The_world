# Chef Assistant · 厨师助手

Vue 3 + FastAPI 前后端分离版本

---

## 本地开发

### 启动后端
```bash
cd backend
python3 -m venv venv
source venv/bin/activate          # Windows: venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env              # 填入你的 ANTHROPIC_API_KEY
uvicorn main:app --reload --port 8000
```
后端运行在 http://localhost:8000
API 文档在  http://localhost:8000/docs

### 启动前端
```bash
cd frontend
npm install
npm run dev
```
前端运行在 http://localhost:5173（自动代理 /api 到后端）

---

## 部署到腾讯云服务器

### 第一步：前端打包
```bash
cd frontend
npm install
npm run build
# 输出在 backend/static/ 目录
```

### 第二步：上传到服务器
```bash
# 把整个项目上传（排除 node_modules）
scp -r chef-assistant/ root@你的服务器IP:/var/www/
# 或用 rsync（推荐，增量同步）
rsync -avz --exclude 'node_modules' --exclude '__pycache__' --exclude 'venv' \
  chef-assistant/ root@你的服务器IP:/var/www/chef-assistant/
```

### 第三步：在服务器上运行部署脚本
```bash
ssh root@你的服务器IP
cd /var/www/chef-assistant
bash deploy.sh
```

### 第四步：填入 API Key
```bash
nano /var/www/chef-assistant/backend/.env
# 填入：ANTHROPIC_API_KEY=sk-ant-你的key
systemctl restart chef-assistant
```

### 第五步：修改 Nginx 域名
```bash
nano /etc/nginx/sites-available/chef-assistant
# 把 your-domain.com 改成你的实际域名或IP
nginx -t && systemctl reload nginx
```

---

## 常用命令

```bash
# 查看后端日志
journalctl -u chef-assistant -f

# 重启后端
systemctl restart chef-assistant

# 更新代码后重新部署
# 本地 build 前端，rsync 上传，然后：
systemctl restart chef-assistant
systemctl reload nginx
```

---

## 项目结构

```
chef-assistant/
├── frontend/          # Vue 3 + Vite
│   ├── src/
│   │   ├── api.js         # 所有 API 调用集中在这里
│   │   ├── App.vue        # 主框架（tabs / toast）
│   │   ├── main.js        # 路由配置
│   │   ├── views/
│   │   │   ├── Ingredients.vue
│   │   │   ├── Recipes.vue
│   │   │   └── Settings.vue
│   │   └── components/
│   │       └── TimerWidget.vue   # 倒计时组件
│   └── vite.config.js
├── backend/           # FastAPI + SQLite
│   ├── main.py
│   ├── database.py
│   ├── models.py
│   ├── routers/
│   │   ├── ingredients.py    # 含图片压缩 + AI识别代理
│   │   └── recipes.py        # 含步骤 patch 接口
│   ├── uploads/       # 压缩后的图片
│   └── chef.db        # SQLite 数据库
└── nginx/
    └── chef.conf
```
