import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'

export default defineConfig({
  plugins: [vue()],
  server: {
    proxy: {
      // 开发时把 /api 和 /uploads 代理到后端
      '/api': { target: 'http://localhost:8000', changeOrigin: true },
      '/uploads': { target: 'http://localhost:8000', changeOrigin: true }
    }
  },
  build: {
    outDir: '../backend/static',   // build输出到后端static目录，方便Nginx一起托管
    emptyOutDir: true
  }
})
