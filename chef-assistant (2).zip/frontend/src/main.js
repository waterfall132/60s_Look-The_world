import { createApp } from 'vue'
import { createRouter, createWebHistory } from 'vue-router'
import App from './App.vue'
import Ingredients from './views/Ingredients.vue'
import Recipes from './views/Recipes.vue'
import Settings from './views/Settings.vue'

const router = createRouter({
  history: createWebHistory(),
  routes: [
    { path: '/',            redirect: '/ingredients' },
    { path: '/ingredients', component: Ingredients },
    { path: '/recipes',     component: Recipes },
    { path: '/settings',    component: Settings },
  ]
})

createApp(App).use(router).mount('#app')
