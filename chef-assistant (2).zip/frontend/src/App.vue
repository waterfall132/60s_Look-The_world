<template>
  <div id="app-shell">
    <!-- Toast -->
    <Transition name="toast">
      <div v-if="toast.show" class="toast" :class="toast.type">
        <span class="toast-icon">{{ toast.type === 'error' ? '✕' : '✓' }}</span>
        {{ toast.msg }}
      </div>
    </Transition>

    <!-- Header -->
    <header class="header">
      <div class="header-top">
        <div>
          <div class="logo">Chef<span>·</span>助手</div>
          <div class="header-sub">Resort Kitchen Assistant</div>
        </div>
        <div class="counts">
          <span class="badge">{{ counts.ingredients }}</span><span class="count-label">食材</span>
          <span class="badge dim">{{ counts.recipes }}</span><span class="count-label">菜谱</span>
        </div>
      </div>
    </header>

    <!-- Tabs -->
    <nav class="tabs">
      <router-link to="/ingredients" class="tab" active-class="active">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M12 2C8 2 4 6 4 10c0 3 1.5 5.5 4 7v3h8v-3c2.5-1.5 4-4 4-7 0-4-4-8-8-8z" stroke-linecap="round" stroke-linejoin="round"/><path d="M9 21h6" stroke-linecap="round"/></svg>
        食材库
      </router-link>
      <router-link to="/recipes" class="tab" active-class="active">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z" stroke-linecap="round" stroke-linejoin="round"/><path d="M14 2v6h6M8 13h8M8 17h5" stroke-linecap="round"/></svg>
        菜谱
      </router-link>
      <router-link to="/settings" class="tab" active-class="active">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 010 2.83 2 2 0 01-2.83 0l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-4 0v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 01-2.83-2.83l.06-.06A1.65 1.65 0 004.68 15a1.65 1.65 0 00-1.51-1H3a2 2 0 010-4h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 012.83-2.83l.06.06A1.65 1.65 0 009 4.68a1.65 1.65 0 001-1.51V3a2 2 0 014 0v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 012.83 2.83l-.06.06A1.65 1.65 0 0019.4 9a1.65 1.65 0 001.51 1H21a2 2 0 010 4h-.09a1.65 1.65 0 00-1.51 1z" stroke-linecap="round" stroke-linejoin="round"/></svg>
        设置
      </router-link>
    </nav>

    <!-- Page content -->
    <main class="scroll">
      <router-view v-slot="{ Component }">
        <keep-alive>
          <component :is="Component"
            @toast="showToast"
            @counts-updated="updateCounts"
          />
        </keep-alive>
      </router-view>
    </main>
  </div>
</template>

<script setup>
import { reactive, ref } from 'vue'

const toast = reactive({ show: false, msg: '', type: 'success' })
const counts = reactive({ ingredients: 0, recipes: 0 })
let toastTimer = null

function showToast({ msg, type = 'success' }) {
  toast.msg = msg; toast.type = type; toast.show = true
  clearTimeout(toastTimer)
  toastTimer = setTimeout(() => { toast.show = false }, 2500)
}

function updateCounts(c) {
  if (c.ingredients !== undefined) counts.ingredients = c.ingredients
  if (c.recipes !== undefined) counts.recipes = c.recipes
}
</script>

<style>
:root {
  --bg:#0f0f0f;--bg2:#1a1a1a;--bg3:#242424;--bg4:#2e2e2e;
  --accent:#e8c97a;--text:#f0ede8;--text2:#a09890;--text3:#6a6560;
  --danger:#e07060;--success:#6db88a;--border:rgba(255,255,255,0.07);
  --radius:16px;--radius-sm:10px;
  --font-head:'Syne',sans-serif;--font-body:'DM Sans',sans-serif;
}
*{box-sizing:border-box;margin:0;padding:0;-webkit-tap-highlight-color:transparent}
html,body{height:100%;overflow:hidden;background:var(--bg);color:var(--text);font-family:var(--font-body)}
#app-shell{display:flex;flex-direction:column;height:100vh;max-width:480px;margin:0 auto;position:relative;overflow:hidden}

.header{padding:16px 20px 0;flex-shrink:0}
.header-top{display:flex;align-items:center;justify-content:space-between;margin-bottom:20px}
.logo{font-family:var(--font-head);font-size:20px;font-weight:800;letter-spacing:-.5px}
.logo span{color:var(--accent)}
.header-sub{font-size:11px;color:var(--text3);letter-spacing:1px;text-transform:uppercase}
.counts{display:flex;gap:8px;align-items:center}
.badge{background:var(--accent);color:#0f0f0f;font-size:10px;font-weight:700;padding:2px 7px;border-radius:20px;font-family:var(--font-head)}
.badge.dim{background:var(--bg3);color:var(--text2)}
.count-label{font-size:11px;color:var(--text3)}

.tabs{display:flex;gap:4px;background:var(--bg2);border-radius:14px;padding:4px;flex-shrink:0;margin:0 20px 16px}
.tab{flex:1;padding:10px 6px;border-radius:10px;background:none;color:var(--text3);font-family:var(--font-body);font-size:12px;font-weight:500;cursor:pointer;display:flex;flex-direction:column;align-items:center;gap:3px;text-decoration:none;transition:all .2s;border:none}
.tab svg{width:18px;height:18px;stroke-width:1.8}
.tab.active{background:var(--bg4);color:var(--accent)}

.scroll{flex:1;overflow-y:auto;padding:0 20px 80px;scrollbar-width:none}
.scroll::-webkit-scrollbar{display:none}

/* Toast */
.toast{position:absolute;top:20px;left:20px;right:20px;background:var(--bg3);border:1px solid var(--border);border-radius:var(--radius-sm);padding:12px 16px;font-size:13px;z-index:200;display:flex;align-items:center;gap:10px}
.toast.success{border-color:rgba(109,184,138,.3)}
.toast.error{border-color:rgba(224,112,96,.3)}
.toast-icon{font-size:14px;font-weight:700}
.toast.success .toast-icon{color:var(--success)}
.toast.error .toast-icon{color:var(--danger)}
.toast-enter-active,.toast-leave-active{transition:transform .3s cubic-bezier(.34,1.2,.64,1),opacity .3s}
.toast-enter-from,.toast-leave-to{transform:translateY(-60px);opacity:0}

/* Shared component styles */
.section-title{font-family:var(--font-head);font-size:22px;font-weight:700;margin-bottom:16px;letter-spacing:-.5px}
.section-title span{color:var(--accent)}
.section-head{font-family:var(--font-head);font-size:13px;font-weight:700;color:var(--text3);text-transform:uppercase;letter-spacing:1.5px;margin:20px 0 12px}
.fab{position:fixed;bottom:90px;right:calc(50% - 220px);width:52px;height:52px;border-radius:50%;background:var(--accent);border:none;cursor:pointer;display:flex;align-items:center;justify-content:center;box-shadow:0 4px 20px rgba(232,201,122,.35);transition:transform .15s;z-index:50}
.fab:active{transform:scale(.93)}
.fab svg{width:22px;height:22px;stroke:#0f0f0f;stroke-width:2.2}
.search-wrap{position:relative;margin-bottom:16px}
.search-wrap svg{position:absolute;left:14px;top:50%;transform:translateY(-50%);width:16px;height:16px;stroke:var(--text3);stroke-width:2}
.search-input{width:100%;background:var(--bg2);border:1px solid var(--border);border-radius:var(--radius-sm);padding:11px 14px 11px 40px;color:var(--text);font-family:var(--font-body);font-size:14px;outline:none;transition:border-color .2s}
.search-input:focus{border-color:rgba(232,201,122,.3)}
.search-input::placeholder{color:var(--text3)}
.form-group{margin-bottom:16px}
.form-label{font-size:11px;color:var(--text3);letter-spacing:.8px;text-transform:uppercase;margin-bottom:6px;display:block}
.form-input,.form-textarea,.form-select{width:100%;background:var(--bg3);border:1px solid var(--border);border-radius:var(--radius-sm);padding:11px 14px;color:var(--text);font-family:var(--font-body);font-size:14px;outline:none;transition:border-color .2s}
.form-input:focus,.form-textarea:focus{border-color:rgba(232,201,122,.4)}
.form-textarea{resize:vertical;min-height:80px;line-height:1.5}
.form-select{appearance:none;cursor:pointer}
.form-row{display:grid;grid-template-columns:1fr 1fr;gap:12px}
.btn-primary{width:100%;padding:14px;background:var(--accent);color:#0f0f0f;border:none;border-radius:var(--radius-sm);font-family:var(--font-head);font-size:15px;font-weight:700;cursor:pointer;transition:opacity .15s;margin-top:8px}
.btn-primary:active{opacity:.85}
.btn-secondary{width:100%;padding:13px;background:none;color:var(--text2);border:1px solid var(--border);border-radius:var(--radius-sm);font-family:var(--font-body);font-size:14px;cursor:pointer;transition:all .15s;margin-top:8px}
.btn-sm{padding:7px 14px;border-radius:8px;border:1px solid var(--border);background:none;color:var(--text2);font-family:var(--font-body);font-size:12px;cursor:pointer;display:inline-flex;align-items:center;gap:5px;transition:all .15s}
.btn-sm:hover{border-color:var(--accent);color:var(--accent)}
.btn-sm.danger:hover{border-color:var(--danger);color:var(--danger)}
.meta-chip{font-size:12px;background:var(--bg3);color:var(--text2);padding:5px 12px;border-radius:20px;display:inline-flex;align-items:center;gap:5px}
.step-btn{padding:3px 8px;font-size:11px;border:1px solid var(--border);background:none;color:var(--text3);border-radius:6px;cursor:pointer;display:inline-flex;align-items:center;gap:4px;font-family:var(--font-body)}
.step-btn svg{width:11px;height:11px;stroke-width:2}
.empty{text-align:center;padding:40px 20px}
.empty-icon{font-size:48px;margin-bottom:12px}
.empty-title{font-family:var(--font-head);font-size:18px;font-weight:700;margin-bottom:6px}
.empty-sub{font-size:13px;color:var(--text3)}

/* Modal */
.modal-overlay{position:fixed;inset:0;background:rgba(0,0,0,.7);z-index:100;display:flex;flex-direction:column;justify-content:flex-end;backdrop-filter:blur(4px)}
.modal{background:var(--bg2);border-radius:24px 24px 0 0;padding:24px 20px 40px;max-height:90vh;overflow-y:auto;scrollbar-width:none}
.modal::-webkit-scrollbar{display:none}
.modal-handle{width:36px;height:4px;background:var(--bg4);border-radius:2px;margin:0 auto 20px}
.modal-title{font-family:var(--font-head);font-size:20px;font-weight:700;margin-bottom:20px;letter-spacing:-.5px}
.modal-enter-active,.modal-leave-active{transition:opacity .25s}
.modal-enter-from,.modal-leave-to{opacity:0}
.modal-enter-active .modal,.modal-leave-active .modal{transition:transform .25s cubic-bezier(.34,1.2,.64,1)}
.modal-enter-from .modal,.modal-leave-to .modal{transform:translateY(40px)}
</style>
