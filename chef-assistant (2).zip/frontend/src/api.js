import axios from 'axios'

const http = axios.create({ baseURL: '/api' })

// ---- Ingredients ----
export const ingredientApi = {
  list:       ()             => http.get('/ingredients/'),
  get:        (id)           => http.get(`/ingredients/${id}`),
  delete:     (id)           => http.delete(`/ingredients/${id}`),

  // 用 FormData 上传图片+字段
  save(data, imageFile, id) {
    const fd = new FormData()
    fd.append('en',       data.en)
    fd.append('cn',       data.cn)
    fd.append('category', data.category || 'other')
    fd.append('note',     data.note || '')
    if (imageFile) fd.append('image', imageFile)

    return id
      ? http.put(`/ingredients/${id}`, fd)
      : http.post('/ingredients/', fd)
  },

  // AI识别：把文件直接发后端，后端调Claude，避免前端暴露Key
  aiRecognize(imageFile) {
    const fd = new FormData()
    fd.append('image', imageFile)
    return http.post('/ingredients/ai-recognize', fd)
  }
}

// ---- Recipes ----
export const recipeApi = {
  list:       ()             => http.get('/recipes/'),
  get:        (id)           => http.get(`/recipes/${id}`),
  delete:     (id)           => http.delete(`/recipes/${id}`),
  create:     (body)         => http.post('/recipes/', body),
  update:     (id, body)     => http.put(`/recipes/${id}`, body),
  updateSteps:(id, steps)    => http.patch(`/recipes/${id}/steps`, steps),
}
