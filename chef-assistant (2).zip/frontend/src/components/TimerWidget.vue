<template>
  <div class="timer-wrap">
    <!-- Done state -->
    <div v-if="done" class="timer-done">
      <span>✅</span>
      <div>
        <div class="done-text">计时完成 Timer Done!</div>
        <div class="done-sub">{{ fmtTimer(props.total) }} elapsed</div>
      </div>
      <button class="reset-btn" @click="reset">重置</button>
    </div>

    <!-- Active state -->
    <div v-else class="timer-active">
      <!-- Ring -->
      <svg width="52" height="52" viewBox="0 0 52 52" class="ring-svg">
        <circle cx="26" cy="26" r="20" fill="none" stroke="rgba(255,255,255,0.06)" stroke-width="4"/>
        <circle cx="26" cy="26" r="20" fill="none" stroke="#e8c97a" stroke-width="4"
          :stroke-dasharray="circ"
          :stroke-dashoffset="offset"
          stroke-linecap="round"
          style="transition:stroke-dashoffset 0.9s linear"
        />
        <text x="26" y="30" text-anchor="middle"
          transform="rotate(90,26,26) translate(0,-52)"
          style="font-family:'Syne',sans-serif;font-size:11px;font-weight:700;fill:#e8c97a"
        >{{ fmtTimer(remaining) }}</text>
      </svg>

      <div class="timer-controls">
        <div class="timer-label">⏱ {{ labelText }}</div>
        <div class="timer-btns">
          <button v-if="!running" class="t-btn start" @click="start">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="#0f0f0f"><polygon points="5 3 19 12 5 21 5 3"/></svg>
            开始
          </button>
          <button v-else class="t-btn pause" @click="pause">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor"><rect x="6" y="4" width="4" height="16"/><rect x="14" y="4" width="4" height="16"/></svg>
            暂停
          </button>
          <button class="t-btn reset-s" @click="reset">重置</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onUnmounted } from 'vue'

const props = defineProps({ total: Number, recipeId: String, stepIndex: Number })
const emit  = defineEmits(['done'])

const remaining = ref(props.total)
const running   = ref(false)
const done      = ref(false)
let   interval  = null

const circ   = computed(() => (2 * Math.PI * 20).toFixed(2))
const offset = computed(() => ((2 * Math.PI * 20) * remaining.value / props.total).toFixed(2))

const labelText = computed(() => {
  const m = Math.floor(props.total / 60), s = props.total % 60
  return `${m}分${s ? s + '秒' : ''} / ${m}min${s ? s + 's' : ''}`
})

function fmtTimer(sec) {
  const m = Math.floor(sec / 60), s = sec % 60
  return String(m).padStart(2,'0') + ':' + String(s).padStart(2,'0')
}

function start() {
  if (running.value || done.value) return
  running.value = true
  interval = setInterval(() => {
    remaining.value--
    if (remaining.value <= 0) {
      clearInterval(interval)
      running.value = false
      done.value = true
      if (navigator.vibrate) navigator.vibrate([300, 100, 300, 100, 300])
      try {
        const ctx = new (window.AudioContext || window.webkitAudioContext)()
        ;[0, 0.4, 0.8].forEach(t => {
          const o = ctx.createOscillator(), g = ctx.createGain()
          o.connect(g); g.connect(ctx.destination)
          o.frequency.value = 880
          g.gain.setValueAtTime(0.4, ctx.currentTime + t)
          g.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + t + 0.3)
          o.start(ctx.currentTime + t); o.stop(ctx.currentTime + t + 0.35)
        })
      } catch {}
      emit('done')
    }
  }, 1000)
}

function pause() {
  clearInterval(interval)
  running.value = false
}

function reset() {
  clearInterval(interval)
  running.value = false
  done.value = false
  remaining.value = props.total
}

onUnmounted(() => clearInterval(interval))
</script>

<style scoped>
.timer-wrap { margin-top: 8px }
.timer-done {
  display:flex;align-items:center;gap:10px;
  background:rgba(109,184,138,.12);border:1px solid rgba(109,184,138,.25);
  border-radius:12px;padding:10px 14px;
}
.timer-done span { font-size:20px }
.done-text { font-size:13px;font-weight:500;color:var(--success) }
.done-sub  { font-size:11px;color:var(--text3);margin-top:1px }
.reset-btn { margin-left:auto;padding:5px 12px;background:none;border:1px solid rgba(109,184,138,.3);border-radius:8px;color:var(--success);font-size:12px;cursor:pointer;font-family:var(--font-body) }

.timer-active { display:flex;align-items:center;gap:12px;background:rgba(232,201,122,.07);border:1px solid rgba(232,201,122,.18);border-radius:12px;padding:10px 14px }
.ring-svg { flex-shrink:0;transform:rotate(-90deg) }
.timer-controls { flex:1;min-width:0 }
.timer-label { font-size:11px;color:var(--text3);margin-bottom:4px }
.timer-btns { display:flex;gap:6px;flex-wrap:wrap }

.t-btn { display:inline-flex;align-items:center;gap:5px;padding:6px 14px;border-radius:8px;font-family:'Syne',sans-serif;font-size:12px;font-weight:700;cursor:pointer;border:none }
.t-btn.start { background:var(--accent);color:#0f0f0f }
.t-btn.pause { background:var(--bg4);border:1px solid var(--border);color:var(--text) }
.t-btn.reset-s { background:none;border:1px solid var(--border);color:var(--text3);font-family:'DM Sans',sans-serif;font-weight:400 }
</style>
