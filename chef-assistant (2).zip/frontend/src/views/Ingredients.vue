<template>
  <div>
    <div class="section-title">食材库 <span>Ingredients</span></div>

    <!-- Search -->
    <div class="search-wrap">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35" stroke-linecap="round"/></svg>
      <input class="search-input" v-model="search" placeholder="搜索食材 / Search ingredients...">
    </div>

    <!-- Grid -->
    <div class="ingr-grid" v-if="filtered.length">
      <div class="ingr-card" v-for="item in filtered" :key="item.id" @click="openDetail(item)">
        <div class="ingr-img-wrap">
          <img v-if="item.image_url" :src="item.image_url" :alt="item.en" loading="lazy">
          <div v-else class="ingr-img-placeholder">{{ catEmoji[item.category] || '🥣' }}</div>
        </div>
        <div class="ingr-body">
          <div class="ingr-en">{{ item.en }}</div>
          <div class="ingr-cn">{{ item.cn }}</div>
          <div v-if="item.note" class="ingr-note">{{ item.note.substring(0,60) }}{{ item.note.length > 60 ? '...' : '' }}</div>
          <div class="ingr-tag">{{ catLabels[item.category] || '其他' }}</div>
        </div>
      </div>
    </div>

    <!-- Empty -->
    <div class="empty" v-else>
      <div class="empty-icon">🥬</div>
      <div class="empty-title">食材库是空的</div>
      <div class="empty-sub">点击 + 按钮添加第一个食材<br>Tap + to add your first ingredient</div>
    </div>

    <!-- FAB -->
    <button class="fab" @click="openAdd">
      <svg viewBox="0 0 24 24" fill="none"><path d="M12 5v14M5 12h14" stroke-linecap="round" stroke-linejoin="round"/></svg>
    </button>

    <!-- Detail panel -->
    <Transition name="modal">
      <div class="modal-overlay" v-if="detail" @click.self="detail = null">
        <div class="modal">
          <div class="modal-handle"></div>
          <img v-if="detail.image_url" :src="detail.image_url" style="width:100%;border-radius:var(--radius);margin-bottom:16px;max-height:200px;object-fit:cover">
          <div v-else style="width:100%;height:120px;border-radius:var(--radius);background:var(--bg3);display:flex;align-items:center;justify-content:center;font-size:56px;margin-bottom:16px">{{ catEmoji[detail.category] || '🥣' }}</div>
          <div style="font-family:var(--font-head);font-size:24px;font-weight:800">{{ detail.cn }}</div>
          <div style="color:var(--accent);font-size:14px;margin:4px 0 16px">{{ detail.en }}</div>
          <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:16px">
            <span class="meta-chip">{{ catLabels[detail.category] || '其他' }}</span>
          </div>
          <div v-if="detail.note" class="section-head">备注 Notes</div>
          <div v-if="detail.note" style="font-size:14px;line-height:1.7;color:var(--text2);background:var(--bg3);padding:14px;border-radius:var(--radius-sm)">{{ detail.note }}</div>
          <div style="display:flex;gap:8px;margin-top:20px">
            <button class="btn-sm" @click="openEdit(detail)">✏️ 编辑</button>
            <button class="btn-sm danger" @click="confirmDelete(detail)">🗑 删除</button>
          </div>
        </div>
      </div>
    </Transition>

    <!-- Add/Edit Modal -->
    <Transition name="modal">
      <div class="modal-overlay" v-if="form.open" @click.self="closeForm">
        <div class="modal">
          <div class="modal-handle"></div>
          <div class="modal-title">{{ form.id ? '编辑食材' : '添加食材' }} {{ form.id ? 'Edit' : 'Add' }} Ingredient</div>

          <!-- Image upload -->
          <div class="upload-area" @click="triggerFileInput">
            <input ref="fileInput" type="file" accept="image/*" style="display:none" @change="handleImage">
            <div v-if="!form.previewUrl" class="upload-placeholder">
              <div style="font-size:32px;margin-bottom:8px">📷</div>
              <div style="font-size:13px;color:var(--text2)">点击拍照或选择图片</div>
              <div style="font-size:11px;color:var(--text3);margin-top:4px">Tap to take photo or upload</div>
            </div>
            <img v-else :src="form.previewUrl" style="width:100%;max-height:160px;object-fit:cover;border-radius:var(--radius-sm)">
          </div>

          <!-- AI result -->
          <div v-if="ai.state !== 'idle'" class="ai-result">
            <div class="ai-label">✨ AI识别 Recognition</div>
            <div v-if="ai.state === 'loading'" style="display:flex;gap:4px;align-items:center;padding:8px 0">
              <span class="dot"></span><span class="dot"></span><span class="dot"></span>
              <span style="font-size:12px;color:var(--text3);margin-left:4px">识别中...</span>
            </div>
            <template v-else-if="ai.state === 'done'">
              <div style="font-family:var(--font-head);font-size:18px;font-weight:700;color:var(--accent)">{{ ai.result.en }}</div>
              <div style="font-size:14px;color:var(--text2);margin-top:2px">{{ ai.result.cn }}</div>
              <div style="font-size:12px;color:var(--text3);margin-top:6px;line-height:1.5">{{ ai.result.desc }}</div>
            </template>
            <div v-else style="font-size:13px;color:var(--danger)">识别失败，请手动填写</div>
          </div>

          <div style="height:14px"></div>

          <div class="form-group">
            <label class="form-label">英文名称 English Name *</label>
            <input class="form-input" v-model="form.en" placeholder="e.g. Thyme">
          </div>
          <div class="form-group">
            <label class="form-label">中文名称 Chinese Name *</label>
            <input class="form-input" v-model="form.cn" placeholder="e.g. 百里香">
          </div>
          <div class="form-group">
            <label class="form-label">分类 Category</label>
            <select class="form-select form-input" v-model="form.category">
              <option v-for="(label, val) in catLabels" :key="val" :value="val">{{ label }}</option>
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">备注 Notes</label>
            <textarea class="form-textarea" v-model="form.note" placeholder="存储方式、常见用途..."></textarea>
          </div>

          <button class="btn-primary" :disabled="saving" @click="save">
            {{ saving ? '保存中...' : '保存食材 Save Ingredient' }}
          </button>
          <button class="btn-secondary" @click="closeForm">取消 Cancel</button>
        </div>
      </div>
    </Transition>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { ingredientApi } from '../api.js'

const emit = defineEmits(['toast', 'counts-updated'])

// ---- data ----
const items  = ref([])
const search = ref('')
const detail = ref(null)
const saving = ref(false)
const fileInput = ref(null)

const filtered = computed(() =>
  search.value
    ? items.value.filter(i =>
        i.en.toLowerCase().includes(search.value.toLowerCase()) ||
        i.cn.includes(search.value) ||
        (i.note||'').toLowerCase().includes(search.value.toLowerCase()))
    : items.value
)

// ---- form state ----
const emptyForm = () => ({ open:false, id:null, en:'', cn:'', category:'other', note:'', previewUrl:'', imageFile:null })
const form = ref(emptyForm())

// ---- AI state ----
const ai = ref({ state: 'idle', result: null })  // idle | loading | done | error

// ---- constants ----
const catLabels = { herb:'香草 Herb', vegetable:'蔬菜 Vegetable', meat:'肉类 Meat', seafood:'海鲜 Seafood', dairy:'乳制品 Dairy', spice:'香料 Spice', sauce:'酱料 Sauce', grain:'谷物 Grain', fruit:'水果 Fruit', other:'其他 Other' }
const catEmoji  = { herb:'🌿', vegetable:'🥦', meat:'🥩', seafood:'🐟', dairy:'🧀', spice:'🧂', sauce:'🫙', grain:'🌾', fruit:'🍎', other:'🥣' }

// ---- load ----
async function load() {
  const res = await ingredientApi.list()
  items.value = res.data
  emit('counts-updated', { ingredients: items.value.length })
}
onMounted(load)

// ---- open/close ----
function openAdd()    { form.value = emptyForm(); form.value.open = true; ai.value = { state:'idle' } }
function openEdit(i)  { form.value = { open:true, id:i.id, en:i.en, cn:i.cn, category:i.category||'other', note:i.note||'', previewUrl:i.image_url||'', imageFile:null }; detail.value=null; ai.value={ state:'idle' } }
function openDetail(i){ detail.value = i }
function closeForm()  { form.value.open = false }

// ---- image handling (FIXED: 用 File 对象，不转 base64) ----
function triggerFileInput() { fileInput.value?.click() }

async function handleImage(event) {
  const file = event.target.files[0]
  if (!file) return

  // 预览用 object URL，不转 base64，避免手机端异步卡死
  form.value.previewUrl = URL.createObjectURL(file)
  form.value.imageFile  = file    // 保存 File 对象，save时再上传

  // AI识别
  ai.value = { state: 'loading' }
  try {
    const res = await ingredientApi.aiRecognize(file)
    ai.value = { state: 'done', result: res.data }
    // 自动填充
    if (!form.value.en) form.value.en = res.data.en
    if (!form.value.cn) form.value.cn = res.data.cn
    form.value.category = res.data.category || 'other'
    if (!form.value.note) form.value.note = res.data.desc
  } catch {
    ai.value = { state: 'error' }
  }
}

// ---- save (上传时才处理图片) ----
async function save() {
  if (!form.value.en.trim() || !form.value.cn.trim()) {
    emit('toast', { msg: '请填写英文名和中文名', type: 'error' }); return
  }
  saving.value = true
  try {
    await ingredientApi.save(
      { en: form.value.en, cn: form.value.cn, category: form.value.category, note: form.value.note },
      form.value.imageFile,   // File 对象（可能为 null）
      form.value.id
    )
    emit('toast', { msg: form.value.id ? '食材已更新' : '食材已添加' })
    closeForm()
    await load()
  } catch {
    emit('toast', { msg: '保存失败，请重试', type: 'error' })
  } finally {
    saving.value = false
  }
}

// ---- delete ----
async function confirmDelete(item) {
  if (!confirm(`删除 ${item.cn}？`)) return
  await ingredientApi.delete(item.id)
  detail.value = null
  emit('toast', { msg: '已删除' })
  await load()
}
</script>

<style scoped>
.ingr-grid{display:grid;grid-template-columns:1fr 1fr;gap:12px}
.ingr-card{background:var(--bg2);border-radius:var(--radius);border:1px solid var(--border);overflow:hidden;cursor:pointer;transition:border-color .2s}
.ingr-card:active{border-color:rgba(232,201,122,.3)}
.ingr-img-wrap{width:100%;height:110px;overflow:hidden;background:var(--bg3)}
.ingr-img-wrap img{width:100%;height:100%;object-fit:cover}
.ingr-img-placeholder{width:100%;height:110px;display:flex;align-items:center;justify-content:center;font-size:36px;background:var(--bg3)}
.ingr-body{padding:10px 12px}
.ingr-en{font-family:var(--font-head);font-size:13px;font-weight:600;color:var(--accent);text-transform:uppercase;letter-spacing:.5px;margin-bottom:2px}
.ingr-cn{font-size:14px;font-weight:500}
.ingr-note{font-size:11px;color:var(--text3);margin-top:4px;line-height:1.4}
.ingr-tag{display:inline-block;font-size:10px;background:var(--bg4);color:var(--text2);padding:2px 7px;border-radius:20px;margin-top:6px}

.upload-area{border:1.5px dashed rgba(232,201,122,.3);border-radius:var(--radius);padding:28px 20px;text-align:center;cursor:pointer;transition:border-color .2s;overflow:hidden}
.upload-area:hover{border-color:rgba(232,201,122,.6)}
.upload-placeholder{}

.ai-result{background:rgba(232,201,122,.08);border:1px solid rgba(232,201,122,.2);border-radius:var(--radius-sm);padding:14px;margin-top:12px}
.ai-label{font-size:10px;color:var(--accent);text-transform:uppercase;letter-spacing:1px;margin-bottom:6px}

.dot{width:6px;height:6px;border-radius:50%;background:var(--accent);animation:blink 1.2s infinite}
.dot:nth-child(2){animation-delay:.2s}
.dot:nth-child(3){animation-delay:.4s}
@keyframes blink{0%,80%,100%{opacity:.2;transform:scale(.8)}40%{opacity:1;transform:scale(1)}}
</style>
