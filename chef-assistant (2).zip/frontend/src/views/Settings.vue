﻿<template>
  <div>
    <div class="section-title">设置 <span>Settings</span></div>

    <div class="setting-item">
      <div>
        <div class="setting-label">服务器状态 Server</div>
        <div class="setting-sub" :style="{ color: health === 'ok' ? 'var(--success)' : 'var(--danger)' }">
          {{ health === 'ok' ? '✓ 后端正常运行' : health === 'checking' ? '检查中...' : '✗ 连接失败' }}
        </div>
      </div>
    </div>

    <div class="setting-item">
      <div style="width:100%">
        <div class="setting-label">数据管理 Data</div>
        <div class="setting-sub" style="margin-bottom:12px">导出或导入所有食材和菜谱数据</div>
        <div style="display:flex;gap:8px;flex-wrap:wrap">
          <button class="action-btn" @click="exportData" :disabled="exporting">
            {{ exporting ? '导出中...' : '导出数据' }}
          </button>
          <button class="action-btn" @click="triggerImport" :disabled="importing">
            {{ importing ? '导入中...' : '导入数据' }}
          </button>
          <input ref="importFile" type="file" accept=".json" style="display:none" @change="importData">
        </div>
        <div v-if="importMsg" :style="{ color: importMsg.ok ? 'var(--success)' : 'var(--danger)', fontSize:'12px', marginTop:'8px' }">
          {{ importMsg.text }}
        </div>
      </div>
    </div>

    <div class="setting-item">
      <div>
        <div class="setting-label">关于 About</div>
        <div class="setting-sub">厨师助手 v2.0 · Vue 3 + FastAPI · 数据存储于服务器</div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import axios from 'axios'

const emit = defineEmits(['toast'])

const health = ref('checking')
const exporting = ref(false)
const importing = ref(false)
const importFile = ref(null)
const importMsg = ref(null)

onMounted(async () => {
  try {
    await axios.get('/api/health')
    health.value = 'ok'
  } catch {
    health.value = 'error'
  }
})

async function exportData() {
  exporting.value = true
  try {
    const [ingr, recipes] = await Promise.all([
      axios.get('/api/ingredients/'),
      axios.get('/api/recipes/')
    ])
    const data = {
      version: 2,
      exportedAt: new Date().toISOString(),
      ingredients: ingr.data,
      recipes: recipes.data
    }
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' })
    const a = document.createElement('a')
    a.href = URL.createObjectURL(blob)
    a.download = 'chef-backup-' + new Date().toISOString().slice(0,10) + '.json'
    a.click()
    emit('toast', { msg: '数据已导出' })
  } catch {
    emit('toast', { msg: '导出失败', type: 'error' })
  } finally {
    exporting.value = false
  }
}

function triggerImport() {
  importFile.value?.click()
}

async function importData(event) {
  const file = event.target.files[0]
  if (!file) return
  importing.value = true
  importMsg.value = null
  try {
    const text = await file.text()
    const data = JSON.parse(text)
    if (!data.ingredients || !data.recipes) {
      importMsg.value = { ok: false, text: 'JSON格式错误' }
      return
    }
    let ingrOk = 0, recipeOk = 0, failed = 0
    for (const item of data.ingredients) {
      try {
        const fd = new FormData()
        fd.append('en', item.en || '')
        fd.append('cn', item.cn || '')
        fd.append('category', item.category || 'other')
        fd.append('note', item.note || '')
        await axios.post('/api/ingredients/', fd)
        ingrOk++
      } catch { failed++ }
    }
    for (const r of data.recipes) {
      try {
        await axios.post('/api/recipes/', {
          name_cn: r.name_cn || r.nameCn || '',
          name_en: r.name_en || r.nameEn || '',
          servings: String(r.servings || '4'),
          time: String(r.time || ''),
          difficulty: r.difficulty || 'medium',
          ingredients: r.ingredients || [],
          steps: (r.steps || []).map(s =>
            typeof s === 'string' ? { text: s, timer: 0 } : { text: s.text || '', timer: s.timer || 0 }
          ),
          note: r.note || ''
        })
        recipeOk++
      } catch { failed++ }
    }
    importMsg.value = { ok: true, text: '导入完成：' + ingrOk + ' 食材，' + recipeOk + ' 菜谱' + (failed ? '，' + failed + ' 条失败' : '') }
    emit('toast', { msg: '导入成功：' + ingrOk + ' 食材 + ' + recipeOk + ' 菜谱' })
  } catch {
    importMsg.value = { ok: false, text: '导入失败：JSON解析错误' }
    emit('toast', { msg: '导入失败', type: 'error' })
  } finally {
    importing.value = false
    event.target.value = ''
  }
}
</script>

<style scoped>
.setting-item { padding: 16px 0; border-bottom: 1px solid var(--border) }
.setting-label { font-size: 15px; font-weight: 500; margin-bottom: 4px }
.setting-sub { font-size: 12px; color: var(--text3) }
.action-btn {
  padding: 10px 18px;
  background: none;
  border: 1px solid var(--border);
  border-radius: 10px;
  color: var(--text2);
  font-family: var(--font-body);
  font-size: 13px;
  cursor: pointer;
  transition: all 0.15s;
}
.action-btn:hover { border-color: var(--accent); color: var(--accent); }
.action-btn:disabled { opacity: 0.5; cursor: not-allowed; }
</style>