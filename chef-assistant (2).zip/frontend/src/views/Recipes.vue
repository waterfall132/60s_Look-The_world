<template>
  <div>
    <div class="section-title">菜谱 <span>Recipes</span></div>

    <div class="search-wrap">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35" stroke-linecap="round"/></svg>
      <input class="search-input" v-model="search" placeholder="搜索菜谱 / Search recipes...">
    </div>

    <!-- List -->
    <div class="recipe-list" v-if="filtered.length">
      <div class="recipe-card" v-for="r in filtered" :key="r.id" @click="openDetail(r.id)">
        <div class="recipe-header">
          <div>
            <div class="recipe-name">{{ r.name_cn }}</div>
            <div class="recipe-name-en">{{ r.name_en }}</div>
          </div>
          <div class="recipe-badge">{{ diffLabels[r.difficulty] || '中等' }}</div>
        </div>
        <div class="recipe-chips">
          <span class="step-chip" v-if="r.time">⏱ {{ r.time }} min</span>
          <span class="step-chip" v-if="r.servings">🍽 {{ r.servings }} servings</span>
          <span class="step-chip">📝 {{ r.steps.length }} 步骤</span>
          <span class="step-chip">🥬 {{ r.ingredients.length }} 食材</span>
        </div>
      </div>
    </div>
    <div class="empty" v-else>
      <div class="empty-icon">📖</div>
      <div class="empty-title">还没有菜谱</div>
      <div class="empty-sub">点击 + 创建第一个菜谱</div>
    </div>

    <!-- FAB -->
    <button class="fab" @click="openAdd">
      <svg viewBox="0 0 24 24" fill="none"><path d="M12 5v14M5 12h14" stroke-linecap="round" stroke-linejoin="round"/></svg>
    </button>

    <!-- ===== DETAIL MODAL ===== -->
    <Transition name="modal">
      <div class="modal-overlay" v-if="detail" @click.self="detail = null">
        <div class="modal">
          <div class="modal-handle"></div>
          <div style="font-family:var(--font-head);font-size:24px;font-weight:800;letter-spacing:-1px">{{ detail.name_cn }}</div>
          <div style="color:var(--accent);font-size:14px;margin:4px 0 12px">{{ detail.name_en }}</div>
          <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:16px">
            <span class="meta-chip" v-if="detail.time">⏱ {{ detail.time }} min</span>
            <span class="meta-chip" v-if="detail.servings">🍽 {{ detail.servings }} servings</span>
            <span class="meta-chip">{{ diffLabels[detail.difficulty] || '中等' }}</span>
          </div>
          <div style="display:flex;gap:8px;margin-bottom:20px">
            <button class="btn-sm" @click="openEdit(detail)">✏️ 编辑基本信息</button>
            <button class="btn-sm danger" @click="confirmDelete(detail.id)">🗑 删除</button>
          </div>

          <!-- Ingredients -->
          <template v-if="detail.ingredients?.length">
            <div class="section-head">原材料 Ingredients</div>
            <div class="ingr-detail-list">
              <div class="ingr-detail-item" v-for="(item, i) in detail.ingredients" :key="i">
                <span class="ingr-detail-name">{{ parseIngr(item).name }}</span>
                <span class="ingr-detail-amount">{{ parseIngr(item).amount }}</span>
              </div>
            </div>
          </template>

          <!-- Steps -->
          <div class="section-head" style="margin-top:24px">制作步骤 Steps</div>
          <div v-for="(step, i) in detail.steps" :key="i" class="step-detail-item">
            <div class="step-num-big">{{ String(i+1).padStart(2,'0') }}</div>
            <div style="flex:1;min-width:0">
              <div class="step-detail-text">{{ step.text }}</div>

              <!-- Timer widget -->
              <TimerWidget v-if="step.timer > 0"
                :key="`${detail.id}-${i}`"
                :total="step.timer"
                :recipe-id="detail.id"
                :step-index="i"
                @done="onTimerDone"
              />

              <!-- Step actions -->
              <div style="display:flex;gap:6px;margin-top:8px;flex-wrap:wrap">
                <button class="step-btn" @click="openStepEdit(i)">✏️ 编辑</button>
                <button class="step-btn" style="color:var(--danger)" @click="deleteStep(i)">✕ 删除</button>
                <button class="step-btn" v-if="i > 0" @click="moveStep(i,-1)">↑</button>
                <button class="step-btn" v-if="i < detail.steps.length-1" @click="moveStep(i,1)">↓</button>
              </div>
            </div>
          </div>
          <div v-if="!detail.steps.length" style="color:var(--text3);font-size:13px;padding:10px 0">还没有步骤，在下方添加</div>

          <!-- Add step -->
          <div class="step-add">
            <input v-model="newStepText" placeholder="添加新步骤 Add step..." @keydown.enter="addStep">
            <button @click="addStep">+ 添加</button>
          </div>

          <div v-if="detail.note" class="section-head" style="margin-top:20px">备注 Notes</div>
          <div v-if="detail.note" style="font-size:14px;line-height:1.7;color:var(--text2);background:var(--bg3);padding:14px;border-radius:var(--radius-sm)">{{ detail.note }}</div>
        </div>
      </div>
    </Transition>

    <!-- ===== ADD/EDIT RECIPE MODAL ===== -->
    <Transition name="modal">
      <div class="modal-overlay" v-if="form.open" @click.self="closeForm">
        <div class="modal">
          <div class="modal-handle"></div>
          <div class="modal-title">{{ form.id ? '编辑菜谱' : '创建菜谱' }}</div>
          <div class="form-group">
            <label class="form-label">菜名（中文）*</label>
            <input class="form-input" v-model="form.name_cn" placeholder="e.g. 香煎三文鱼">
          </div>
          <div class="form-group">
            <label class="form-label">菜名（英文）*</label>
            <input class="form-input" v-model="form.name_en" placeholder="e.g. Pan-Seared Salmon">
          </div>
          <div class="form-row">
            <div class="form-group">
              <label class="form-label">份数 Servings</label>
              <input class="form-input" v-model="form.servings" type="number" placeholder="4" min="1">
            </div>
            <div class="form-group">
              <label class="form-label">时间 Time (min)</label>
              <input class="form-input" v-model="form.time" type="number" placeholder="30" min="1">
            </div>
          </div>
          <div class="form-group">
            <label class="form-label">难度 Difficulty</label>
            <select class="form-select form-input" v-model="form.difficulty">
              <option value="easy">简单 Easy</option>
              <option value="medium">中等 Medium</option>
              <option value="hard">复杂 Hard</option>
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">原材料（每行一项，名称+用量）</label>
            <textarea class="form-textarea" v-model="form.ingredients_raw" placeholder="Salmon fillet 200g&#10;Butter 30g&#10;Lemon 1pc"></textarea>
          </div>
          <div class="form-group">
            <label class="form-label">备注 Notes</label>
            <textarea class="form-textarea" v-model="form.note" style="min-height:60px" placeholder="特殊技巧、注意事项..."></textarea>
          </div>
          <button class="btn-primary" :disabled="saving" @click="saveRecipe">{{ saving ? '保存中...' : '保存菜谱 Save' }}</button>
          <button class="btn-secondary" @click="closeForm">取消 Cancel</button>
        </div>
      </div>
    </Transition>

    <!-- ===== EDIT STEP MODAL ===== -->
    <Transition name="modal">
      <div class="modal-overlay" v-if="stepForm.open" @click.self="stepForm.open=false">
        <div class="modal">
          <div class="modal-handle"></div>
          <div class="modal-title">编辑步骤 Edit Step</div>
          <div class="form-group">
            <label class="form-label">步骤内容</label>
            <textarea class="form-textarea" v-model="stepForm.text" style="min-height:120px"></textarea>
          </div>
          <div class="form-group">
            <label class="form-label">⏱ 倒计时 Countdown Timer（0 = 无计时）</label>
            <div style="display:flex;align-items:center;gap:10px">
              <input class="form-input" v-model.number="stepForm.mins" type="number" min="0" style="width:80px;text-align:center">
              <span style="color:var(--text2);font-size:14px">分钟 min</span>
              <input class="form-input" v-model.number="stepForm.secs" type="number" min="0" max="59" style="width:80px;text-align:center">
              <span style="color:var(--text2);font-size:14px">秒 sec</span>
            </div>
            <div style="font-size:11px;color:var(--text3);margin-top:6px">例如烤箱 3 分钟 → 填 3 分 0 秒</div>
          </div>
          <button class="btn-primary" @click="saveStep">保存 Save</button>
          <button class="btn-secondary" @click="stepForm.open=false">取消 Cancel</button>
        </div>
      </div>
    </Transition>
  </div>
</template>

<script setup>
import { ref, computed, onMounted, defineAsyncComponent } from 'vue'
import { recipeApi } from '../api.js'

const TimerWidget = defineAsyncComponent(() => import('../components/TimerWidget.vue'))

const emit = defineEmits(['toast', 'counts-updated'])

const recipes  = ref([])
const search   = ref('')
const detail   = ref(null)
const saving   = ref(false)
const newStepText = ref('')

const filtered = computed(() =>
  search.value
    ? recipes.value.filter(r =>
        r.name_cn.includes(search.value) ||
        r.name_en.toLowerCase().includes(search.value.toLowerCase()))
    : recipes.value
)

const diffLabels = { easy:'简单 Easy', medium:'中等 Medium', hard:'复杂 Hard' }

const emptyForm = () => ({ open:false, id:null, name_cn:'', name_en:'', servings:'4', time:'', difficulty:'medium', ingredients_raw:'', note:'' })
const form = ref(emptyForm())

const stepForm = ref({ open:false, index:-1, text:'', mins:0, secs:0 })

async function load() {
  const res = await recipeApi.list()
  recipes.value = res.data
  emit('counts-updated', { recipes: recipes.value.length })
}
onMounted(load)

async function openDetail(id) {
  const res = await recipeApi.get(id)
  detail.value = res.data
}

function openAdd()   { form.value = emptyForm(); form.value.open = true }
function openEdit(r) {
  form.value = {
    open:true, id:r.id,
    name_cn:r.name_cn, name_en:r.name_en,
    servings:r.servings, time:r.time,
    difficulty:r.difficulty,
    ingredients_raw: (r.ingredients||[]).join('\n'),
    note:r.note||''
  }
  detail.value = null
}
function closeForm() { form.value.open = false }

async function saveRecipe() {
  if (!form.value.name_cn.trim() || !form.value.name_en.trim()) {
    emit('toast', { msg:'请填写菜名', type:'error' }); return
  }
  saving.value = true
  const body = {
    name_cn: form.value.name_cn, name_en: form.value.name_en,
    servings: String(form.value.servings || 4),
    time: String(form.value.time || ''),
    difficulty: form.value.difficulty,
    ingredients: form.value.ingredients_raw.split('\n').filter(l=>l.trim()),
    steps: form.value.id ? (recipes.value.find(r=>r.id===form.value.id)?.steps || []) : [],
    note: form.value.note
  }
  try {
    if (form.value.id) await recipeApi.update(form.value.id, body)
    else await recipeApi.create(body)
    emit('toast', { msg: form.value.id ? '菜谱已更新' : '菜谱已创建' })
    closeForm()
    await load()
  } catch {
    emit('toast', { msg:'保存失败', type:'error' })
  } finally { saving.value = false }
}

async function confirmDelete(id) {
  if (!confirm('删除这个菜谱？')) return
  await recipeApi.delete(id)
  detail.value = null
  emit('toast', { msg:'已删除' })
  await load()
}

// ---- Steps ----
function parseIngr(str) {
  const m = str.match(/^(.*?)(\s+\S+)$/)
  return m ? { name: m[1].trim(), amount: m[2].trim() } : { name: str, amount: '' }
}

async function addStep() {
  const text = newStepText.value.trim()
  if (!text || !detail.value) return
  detail.value.steps.push({ text, timer: 0 })
  newStepText.value = ''
  await recipeApi.updateSteps(detail.value.id, detail.value.steps)
  emit('toast', { msg:'步骤已添加' })
}

async function deleteStep(i) {
  detail.value.steps.splice(i, 1)
  await recipeApi.updateSteps(detail.value.id, detail.value.steps)
}

async function moveStep(i, dir) {
  const steps = detail.value.steps
  const j = i + dir
  if (j < 0 || j >= steps.length) return
  ;[steps[i], steps[j]] = [steps[j], steps[i]]
  await recipeApi.updateSteps(detail.value.id, detail.value.steps)
}

function openStepEdit(i) {
  const s = detail.value.steps[i]
  stepForm.value = { open:true, index:i, text:s.text, mins:Math.floor(s.timer/60), secs:s.timer%60 }
}

async function saveStep() {
  const i = stepForm.value.index
  detail.value.steps[i] = {
    text: stepForm.value.text,
    timer: Math.max(0, (stepForm.value.mins||0)*60 + (stepForm.value.secs||0))
  }
  await recipeApi.updateSteps(detail.value.id, detail.value.steps)
  stepForm.value.open = false
  emit('toast', { msg:'步骤已更新' })
}

function onTimerDone() {
  emit('toast', { msg:'⏰ 计时完成！Timer done!' })
}
</script>

<style scoped>
.recipe-list{display:flex;flex-direction:column;gap:12px}
.recipe-card{background:var(--bg2);border-radius:var(--radius);border:1px solid var(--border);padding:16px;cursor:pointer;transition:border-color .2s}
.recipe-card:active{border-color:rgba(232,201,122,.3)}
.recipe-header{display:flex;align-items:flex-start;justify-content:space-between;gap:10px}
.recipe-name{font-family:var(--font-head);font-size:16px;font-weight:700;letter-spacing:-.3px}
.recipe-name-en{font-size:12px;color:var(--accent);margin-top:2px}
.recipe-badge{font-size:10px;background:var(--bg3);color:var(--text2);padding:4px 10px;border-radius:20px;white-space:nowrap;flex-shrink:0}
.recipe-chips{margin-top:10px;padding-top:10px;border-top:1px solid var(--border);display:flex;gap:6px;flex-wrap:wrap}
.step-chip{font-size:11px;color:var(--text3);background:var(--bg3);padding:3px 8px;border-radius:6px}
.ingr-detail-list{display:flex;flex-direction:column;gap:8px}
.ingr-detail-item{display:flex;justify-content:space-between;align-items:center;padding:10px 14px;background:var(--bg3);border-radius:var(--radius-sm)}
.ingr-detail-name{font-size:14px}
.ingr-detail-amount{font-size:13px;color:var(--accent);font-weight:500}
.step-detail-item{display:flex;gap:16px;margin-bottom:16px}
.step-num-big{font-family:var(--font-head);font-size:32px;font-weight:800;color:rgba(232,201,122,.2);flex-shrink:0;line-height:1;min-width:36px}
.step-detail-text{font-size:15px;line-height:1.7;padding-top:4px}
.step-add{display:flex;gap:8px;margin-top:16px}
.step-add input{flex:1;background:var(--bg3);border:1px solid var(--border);border-radius:var(--radius-sm);padding:10px 12px;color:var(--text);font-family:var(--font-body);font-size:13px;outline:none}
.step-add input:focus{border-color:rgba(232,201,122,.3)}
.step-add button{padding:10px 16px;background:var(--accent);border:none;border-radius:var(--radius-sm);color:#0f0f0f;font-family:var(--font-head);font-size:13px;font-weight:700;cursor:pointer;white-space:nowrap}
</style>
