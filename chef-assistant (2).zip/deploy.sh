#!/bin/bash
# deploy.sh - 在服务器上运行这个脚本完成部署
# 用法: bash deploy.sh

set -e
echo "===== Chef Assistant 部署脚本 ====="

PROJECT_DIR="/var/www/chef-assistant"
BACKEND_DIR="$PROJECT_DIR/backend"
STATIC_DIR="$PROJECT_DIR/static"

# 1. 创建目录
mkdir -p $BACKEND_DIR $STATIC_DIR

# 2. 复制后端文件（假设你已把项目上传到服务器）
echo "[1/5] 复制后端文件..."
cp -r backend/* $BACKEND_DIR/
mkdir -p $BACKEND_DIR/uploads

# 3. 安装 Python 依赖
echo "[2/5] 安装 Python 依赖..."
cd $BACKEND_DIR
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt

# 4. 配置 .env（如果还没有）
if [ ! -f "$BACKEND_DIR/.env" ]; then
  echo "[3/5] 创建 .env 文件..."
  cp .env.example .env
  echo "⚠️  请编辑 $BACKEND_DIR/.env 填入你的 ANTHROPIC_API_KEY"
fi

# 5. 创建 systemd 服务（让后端开机自启）
echo "[4/5] 创建系统服务..."
cat > /etc/systemd/system/chef-assistant.service << EOF
[Unit]
Description=Chef Assistant FastAPI Backend
After=network.target

[Service]
User=www-data
WorkingDirectory=$BACKEND_DIR
ExecStart=$BACKEND_DIR/venv/bin/uvicorn main:app --host 127.0.0.1 --port 8000 --workers 2
Restart=always
RestartSec=3
EnvironmentFile=$BACKEND_DIR/.env

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable chef-assistant
systemctl restart chef-assistant

# 6. 配置 Nginx
echo "[5/5] 配置 Nginx..."
cp nginx/chef.conf /etc/nginx/sites-available/chef-assistant
ln -sf /etc/nginx/sites-available/chef-assistant /etc/nginx/sites-enabled/
nginx -t && systemctl reload nginx

echo ""
echo "===== 部署完成！====="
echo "后端服务状态: systemctl status chef-assistant"
echo "记得编辑 .env: nano $BACKEND_DIR/.env"
echo "记得修改 nginx/chef.conf 里的域名，然后运行 nginx -t && systemctl reload nginx"
