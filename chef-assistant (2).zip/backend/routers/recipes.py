import uuid
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from pydantic import BaseModel
from typing import Optional, List, Any

from database import get_db
from models import Recipe

router = APIRouter(prefix="/api/recipes", tags=["recipes"])

# ---------- Schemas ----------
class StepSchema(BaseModel):
    text: str
    timer: int = 0          # 秒，0表示无计时

class RecipeBody(BaseModel):
    name_cn: str
    name_en: str
    servings: Optional[str] = "4"
    time: Optional[str] = ""
    difficulty: Optional[str] = "medium"
    ingredients: Optional[List[str]] = []
    steps: Optional[List[StepSchema]] = []
    note: Optional[str] = ""

# ---------- Routes ----------
@router.get("/")
def list_recipes(db: Session = Depends(get_db)):
    items = db.query(Recipe).order_by(Recipe.updated_at.desc()).all()
    return [_to_dict(r) for r in items]

@router.get("/{recipe_id}")
def get_recipe(recipe_id: str, db: Session = Depends(get_db)):
    r = db.query(Recipe).filter(Recipe.id == recipe_id).first()
    if not r:
        raise HTTPException(404, "Not found")
    return _to_dict(r)

@router.post("/")
def create_recipe(body: RecipeBody, db: Session = Depends(get_db)):
    r = Recipe(
        id=uuid.uuid4().hex,
        name_cn=body.name_cn,
        name_en=body.name_en,
        servings=body.servings,
        time=body.time,
        difficulty=body.difficulty,
        ingredients=body.ingredients,
        steps=[s.dict() for s in body.steps],
        note=body.note
    )
    db.add(r)
    db.commit()
    db.refresh(r)
    return _to_dict(r)

@router.put("/{recipe_id}")
def update_recipe(recipe_id: str, body: RecipeBody, db: Session = Depends(get_db)):
    r = db.query(Recipe).filter(Recipe.id == recipe_id).first()
    if not r:
        raise HTTPException(404, "Not found")
    r.name_cn     = body.name_cn
    r.name_en     = body.name_en
    r.servings    = body.servings
    r.time        = body.time
    r.difficulty  = body.difficulty
    r.ingredients = body.ingredients
    r.steps       = [s.dict() for s in body.steps]
    r.note        = body.note
    db.commit()
    db.refresh(r)
    return _to_dict(r)

# 只更新steps（用于步骤增删改排序）
@router.patch("/{recipe_id}/steps")
def update_steps(recipe_id: str, steps: List[StepSchema], db: Session = Depends(get_db)):
    r = db.query(Recipe).filter(Recipe.id == recipe_id).first()
    if not r:
        raise HTTPException(404, "Not found")
    r.steps = [s.dict() for s in steps]
    db.commit()
    return {"ok": True, "steps": r.steps}

@router.delete("/{recipe_id}")
def delete_recipe(recipe_id: str, db: Session = Depends(get_db)):
    r = db.query(Recipe).filter(Recipe.id == recipe_id).first()
    if not r:
        raise HTTPException(404, "Not found")
    db.delete(r)
    db.commit()
    return {"ok": True}

def _to_dict(r: Recipe):
    return {
        "id": r.id,
        "name_cn": r.name_cn, "name_en": r.name_en,
        "servings": r.servings, "time": r.time,
        "difficulty": r.difficulty,
        "ingredients": r.ingredients or [],
        "steps": r.steps or [],
        "note": r.note,
        "updated_at": str(r.updated_at)
    }
