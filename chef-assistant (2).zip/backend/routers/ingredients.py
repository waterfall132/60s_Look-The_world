import uuid, os, io
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form
from fastapi.responses import JSONResponse
from sqlalchemy.orm import Session
from PIL import Image
from pydantic import BaseModel
from typing import Optional

from database import get_db
from models import Ingredient

router = APIRouter(prefix="/api/ingredients", tags=["ingredients"])

UPLOAD_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "backend", "uploads")
os.makedirs(UPLOAD_DIR, exist_ok=True)

MAX_IMAGE_SIZE = (800, 800)   # 最大像素
JPEG_QUALITY   = 75           # 压缩质量

# ---------- Pydantic schemas ----------
class IngredientCreate(BaseModel):
    en: str
    cn: str
    category: Optional[str] = "other"
    note: Optional[str] = ""
    image_url: Optional[str] = ""

class IngredientUpdate(IngredientCreate):
    pass

# ---------- 图片压缩 ----------
def compress_and_save(file_bytes: bytes, filename: str) -> str:
    img = Image.open(io.BytesIO(file_bytes)).convert("RGB")
    img.thumbnail(MAX_IMAGE_SIZE, Image.LANCZOS)
    save_path = os.path.join(UPLOAD_DIR, filename)
    img.save(save_path, "JPEG", quality=JPEG_QUALITY, optimize=True)
    return f"/uploads/{filename}"

# ---------- Routes ----------
@router.get("/")
def list_ingredients(db: Session = Depends(get_db)):
    items = db.query(Ingredient).order_by(Ingredient.updated_at.desc()).all()
    return [_to_dict(i) for i in items]

@router.get("/{item_id}")
def get_ingredient(item_id: str, db: Session = Depends(get_db)):
    item = db.query(Ingredient).filter(Ingredient.id == item_id).first()
    if not item:
        raise HTTPException(404, "Not found")
    return _to_dict(item)

@router.post("/")
async def create_ingredient(
    en: str = Form(...),
    cn: str = Form(...),
    category: str = Form("other"),
    note: str = Form(""),
    image: Optional[UploadFile] = File(None),
    db: Session = Depends(get_db)
):
    image_url = ""
    if image and image.filename:
        data = await image.read()
        ext  = "jpg"
        filename = f"{uuid.uuid4().hex}.{ext}"
        image_url = compress_and_save(data, filename)

    item = Ingredient(
        id=uuid.uuid4().hex,
        en=en, cn=cn,
        category=category, note=note,
        image_url=image_url
    )
    db.add(item)
    db.commit()
    db.refresh(item)
    return _to_dict(item)

@router.put("/{item_id}")
async def update_ingredient(
    item_id: str,
    en: str = Form(...),
    cn: str = Form(...),
    category: str = Form("other"),
    note: str = Form(""),
    image: Optional[UploadFile] = File(None),
    db: Session = Depends(get_db)
):
    item = db.query(Ingredient).filter(Ingredient.id == item_id).first()
    if not item:
        raise HTTPException(404, "Not found")

    item.en = en
    item.cn = cn
    item.category = category
    item.note = note

    if image and image.filename:
        # 删除旧图
        if item.image_url:
            old_path = os.path.join(UPLOAD_DIR, os.path.basename(item.image_url))
            if os.path.exists(old_path):
                os.remove(old_path)
        data = await image.read()
        filename = f"{uuid.uuid4().hex}.jpg"
        item.image_url = compress_and_save(data, filename)

    db.commit()
    db.refresh(item)
    return _to_dict(item)

@router.delete("/{item_id}")
def delete_ingredient(item_id: str, db: Session = Depends(get_db)):
    item = db.query(Ingredient).filter(Ingredient.id == item_id).first()
    if not item:
        raise HTTPException(404, "Not found")
    if item.image_url:
        path = os.path.join(UPLOAD_DIR, os.path.basename(item.image_url))
        if os.path.exists(path):
            os.remove(path)
    db.delete(item)
    db.commit()
    return {"ok": True}

# ---------- AI识别 proxy（避免前端暴露API Key） ----------
@router.post("/ai-recognize")
async def ai_recognize(image: UploadFile = File(...)):
    """把图片发给Claude API做识别，API Key存在服务器.env里"""
    import httpx, base64, json
    api_key = os.getenv("ANTHROPIC_API_KEY", "")
    if not api_key:
        raise HTTPException(400, "ANTHROPIC_API_KEY not configured on server")

    data = await image.read()
    # 先压缩
    img = Image.open(io.BytesIO(data)).convert("RGB")
    img.thumbnail((512, 512), Image.LANCZOS)
    buf = io.BytesIO()
    img.save(buf, "JPEG", quality=70)
    b64 = base64.b64encode(buf.getvalue()).decode()

    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.post(
            "https://api.anthropic.com/v1/messages",
            headers={"x-api-key": api_key, "anthropic-version": "2023-06-01", "Content-Type": "application/json"},
            json={
                "model": "claude-sonnet-4-20250514",
                "max_tokens": 400,
                "messages": [{
                    "role": "user",
                    "content": [
                        {"type": "image", "source": {"type": "base64", "media_type": "image/jpeg", "data": b64}},
                        {"type": "text", "text": 'Identify this food ingredient. Reply ONLY in this JSON format: {"en":"English name","cn":"中文名称","category":"herb/vegetable/meat/seafood/dairy/spice/sauce/grain/fruit/other","desc":"One sentence about storage and common uses"}'}
                    ]
                }]
            }
        )
    result = resp.json()
    text = result["content"][0]["text"].replace("```json","").replace("```","").strip()
    return json.loads(text)

def _to_dict(item: Ingredient):
    return {
        "id": item.id, "en": item.en, "cn": item.cn,
        "category": item.category, "note": item.note,
        "image_url": item.image_url,
        "updated_at": str(item.updated_at)
    }
