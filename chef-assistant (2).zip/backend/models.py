from sqlalchemy import Column, String, Integer, Text, JSON, DateTime
from sqlalchemy.sql import func
from database import Base

class Ingredient(Base):
    __tablename__ = "ingredients"

    id        = Column(String, primary_key=True, index=True)
    en        = Column(String, nullable=False)
    cn        = Column(String, nullable=False)
    category  = Column(String, default="other")
    note      = Column(Text, default="")
    image_url = Column(String, default="")           # 相对路径 /uploads/xxx.jpg
    updated_at = Column(DateTime, server_default=func.now(), onupdate=func.now())


class Recipe(Base):
    __tablename__ = "recipes"

    id          = Column(String, primary_key=True, index=True)
    name_cn     = Column(String, nullable=False)
    name_en     = Column(String, nullable=False)
    servings    = Column(String, default="4")
    time        = Column(String, default="")
    difficulty  = Column(String, default="medium")
    ingredients = Column(JSON, default=list)         # ["Salmon 200g", ...]
    steps       = Column(JSON, default=list)         # [{"text":"...", "timer":180}, ...]
    note        = Column(Text, default="")
    updated_at  = Column(DateTime, server_default=func.now(), onupdate=func.now())
