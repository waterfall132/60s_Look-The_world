from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from dotenv import load_dotenv
import os

load_dotenv()

from database import engine, Base
from routers import ingredients, recipes

# 建表
Base.metadata.create_all(bind=engine)

app = FastAPI(title="Chef Assistant API", version="1.0.0")

# CORS（开发时允许所有，生产环境改成你的域名）
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 挂载上传目录，让 /uploads/xxx.jpg 可以被访问
UPLOAD_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "uploads")
os.makedirs(UPLOAD_DIR, exist_ok=True)
app.mount("/uploads", StaticFiles(directory=UPLOAD_DIR), name="uploads")

# 注册路由
app.include_router(ingredients.router)
app.include_router(recipes.router)

@app.get("/api/health")
def health():
    return {"status": "ok"}
