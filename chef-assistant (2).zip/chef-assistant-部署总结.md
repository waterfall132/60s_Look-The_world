# Chef Assistant 部署总结

> 腾讯云 Ubuntu 22.04 · Vue 3 + FastAPI + SQLite · Nginx (Docker) 反向代理

---

## 一、最终架构

```
浏览器
  │
  ▼
Docker Nginx (端口 80/443)
  │  ├── twohornedcarp.com → visa-card-app（原有项目，不受影响）
  │  └── default_server   → http://172.17.0.1:8001（chef-assistant 后端）
  │
  ▼
uvicorn (127.0.0.1→0.0.0.0:8001, systemd 守护)
  │  ├── /api/ingredients  → SQLite 数据库
  │  ├── /api/recipes      → SQLite 数据库
  │  ├── /uploads/         → 本地图片文件
  │  └── /                 → 前端静态文件 (Vue 3 SPA)
```

---

## 二、踩过的坑（按时间顺序）

### 坑 1：`python3-venv` 未安装

**现象：** `deploy.sh` 执行时创建虚拟环境失败。

**原因：** Ubuntu 22.04 默认不带 `python3-venv`。

**解决：**
```bash
sudo apt install python3.10-venv
```

---

### 坑 2：`deploy.sh` 路径错误——`.env.example` 找不到

**现象：** 脚本报 `cp: cannot stat '.env.example': No such file or directory`

**原因：** `.env.example` 在 `backend/` 子目录，脚本在父目录执行时路径不对。

**解决：** 手动进入 `/var/www/chef-assistant/backend/` 创建 `.env` 并填写 `ANTHROPIC_API_KEY`。

---

### 坑 3：服务以 `www-data` 用户运行，但文件所有者是 `ubuntu`

**现象：** systemd 服务启动后立刻报 `PermissionError: [Errno 13] Permission denied`

**原因：** `/etc/systemd/system/chef-assistant.service` 中 `User=www-data`，但部署目录归 `ubuntu` 所有。

**解决：**
```bash
sudo chown -R www-data:www-data /var/www/chef-assistant/backend
sudo chmod 775 /var/www/chef-assistant/backend
sudo chmod 664 /var/www/chef-assistant/backend/chef.db
sudo chmod -R 775 /var/www/chef-assistant/backend/uploads
```

---

### 坑 4：`ingredients.py` 里 `__file` 打错（少一个下划线）

**现象：** `NameError: name '__file' is not defined. Did you mean: '__file__'?`

**原因：** 手动编辑文件时将 `__file__` 写成了 `__file`。

**解决：** `sudo nano routers/ingredients.py` 改回 `__file__`。

---

### 坑 5：SQLite 数据库文件不存在 / 只读

**现象：** `sqlite3.OperationalError: unable to open database file` 及 `attempt to write a readonly database`

**原因：** `chef.db` 文件不存在，且目录权限不足。

**解决：**
```bash
touch /var/www/chef-assistant/backend/chef.db
sudo chown -R www-data:www-data /var/www/chef-assistant/backend
sudo chmod 777 /var/www/chef-assistant/backend/chef.db
```

---

### 坑 6：前端 node_modules 是在 Windows 下安装的

**现象：** 服务器上执行 `npm run build` 报 `Cannot find module @rollup/rollup-linux-x64-gnu`

**原因：** node_modules 包含 Windows 平台的二进制文件（`@rollup/rollup-win32-x64-gnu`），无法在 Linux 上运行。

**解决：** 在本地 Windows 上重新 `npm install` 再 `npm run build`，或服务器上删除 node_modules 重装。

---

### 坑 7：服务器 Node.js 版本过低（不支持顶层 await）

**现象：** `SyntaxError: Unexpected reserved word` at `await import('source-map-support')`

**原因：** 系统自带 Node.js 版本太旧。

**解决：** 用 nvm 升级到 Node 18：
```bash
curl -fsSL https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.0/install.sh | bash
source ~/.bashrc
nvm install 18 && nvm use 18
```

---

### 坑 8：前端构建输出目录不是 `dist/`

**现象：** 找不到 `dist` 文件夹。

**原因：** `vite.config.js` 中配置了 `outDir: '../backend/static'`，输出直接到后端 static 目录。

**解决：** 从 `chef-assistant/backend/static/` 上传，而不是找 `dist/`。

---

### 坑 9：Nginx 无法启动——80 端口被 Docker 占用

**现象：** `nginx: [emerg] bind() to 0.0.0.0:80 failed (98: Unknown error)`

**原因：** 已有项目 `visa-card-app` 通过 Docker 容器占用了 80 端口。

**解决：** 不另起 Nginx，而是在 Docker 容器内的 Nginx 配置里添加新 server 块：
```bash
sudo nano /home/ubuntu/visa-card-app/nginx/nginx.conf
# 在 http{} 块末尾添加：
server {
    listen 80 default_server;
    server_name _;
    location / {
        proxy_pass http://172.17.0.1:8001;
    }
}
docker exec visa-card-app_nginx_1 nginx -s reload
```

---

### 坑 10：腾讯云服务器无法用公网 IP 访问自己

**现象：** 在服务器上 `curl http://43.165.172.x` 超时，但 `curl http://127.0.0.1` 正常。

**原因：** 腾讯云网络限制，服务器不能通过公网 IP 回环访问自身。

**解决：** 本地测试用 `curl http://127.0.0.1`；从外部客户端访问公网 IP。

---

### 坑 11：真实公网 IP 填错

**现象：** 浏览器访问 `43.165.172.1` 超时，实际无法访问。

**原因：** 腾讯云控制台显示的 IP 末位看错了。

**解决：**
```bash
curl -s ifconfig.me
# 实际 IP：43.165.172.199
```

---

### 坑 12：Docker 容器内无法访问宿主机后端（后端监听 127.0.0.1）

**现象：** Docker Nginx 转发报 502，容器内 `curl http://172.17.0.1:8001` 失败。

**原因：** uvicorn 绑定的是 `127.0.0.1:8001`，Docker 容器只能通过宿主机网关 `172.17.0.1` 访问，但 127.0.0.1 不对外暴露。

**解决：** 修改 systemd 服务，将 `--host 127.0.0.1` 改为 `--host 0.0.0.0`：
```bash
sudo nano /etc/systemd/system/chef-assistant.service
# ExecStart=... --host 0.0.0.0 --port 8001 ...
sudo systemctl daemon-reload && sudo systemctl restart chef-assistant.service
```

---

### 坑 13：后端没有挂载前端静态文件

**现象：** 访问根路径返回 `{"detail":"Not Found"}`

**原因：** `main.py` 只挂载了 `/uploads/`，没有挂载前端 SPA。

**解决：** 在 `main.py` 末尾添加：
```python
from fastapi.responses import FileResponse
STATIC_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "static")
if os.path.exists(STATIC_DIR):
    app.mount("/assets", StaticFiles(directory=os.path.join(STATIC_DIR, "assets")), name="assets")

    @app.get("/")
    def serve_index():
        return FileResponse(os.path.join(STATIC_DIR, "index.html"))

    @app.get("/{full_path:path}")
    def serve_spa(full_path: str):
        return FileResponse(os.path.join(STATIC_DIR, "index.html"))
```

---

### 坑 14：新增 server 块放到了 http{} 外面

**现象：** `nginx -t` 报 syntax error，或配置不生效。

**原因：** 手动编辑 nginx.conf 时缩进错误，`server {}` 块写在了最外层而不是 `http {}` 内部。

**解决：** 确认 server 块在 `http {` 和对应的 `}` 之间。

---

### 坑 15：前端静态文件上传到了错误目录

**现象：** 更新前端后页面没有变化，服务器上文件确实是新的，但后端返回的仍是旧页面。

**原因：** 存在两个 static 目录：
- `/var/www/chef-assistant/static/`（Nginx 直接服务，但实际未用）
- `/var/www/chef-assistant/backend/static/`（后端 FastAPI 挂载并服务的目录）

每次都上传到了错误的第一个目录。

**解决：** 始终上传到 `/var/www/chef-assistant/backend/static/`：
```bash
cp -r /home/ubuntu/chef_assistant/backend/static/* /var/www/chef-assistant/backend/static/
```

---

### 坑 16：Settings.vue 文件编码错误（GBK 乱码）

**现象：** 文件内容显示为乱码（`璁剧疆`、`鏈嶅姟`），Vite 编译后 JS 中不包含新增的导出导入功能。

**原因：** 通过 Claude 生成文件时，下载的文件编码为 GBK，覆盖原 UTF-8 文件后中文全部乱码，Vite 编译异常但不报错，只是跳过了乱码内容。

**解决：** 在服务器上直接用 `cat > file << 'EOF'` 重写文件（服务器环境默认 UTF-8），避开 Windows 编码问题：
```bash
cat > src/views/Settings.vue << 'VUEEOF'
# ... 文件内容 ...
VUEEOF
```

---

### 坑 17：App.vue 使用 keep-alive 缓存了旧组件

**现象：** 前端已更新，但设置页面显示的仍是旧内容。

**原因：** `<keep-alive>` 缓存了 Settings 组件实例，即使 JS 文件更新，浏览器不强制刷新时也不会重新挂载组件。

**解决：** 彻底关闭浏览器再重新打开（不是 F5 刷新），或使用无痕模式，确保加载最新 JS。

---

## 三、正确的完整部署流程（供以后参考）

### 1. 服务器准备

```bash
# 安装依赖
sudo apt install python3.10-venv nginx -y   # 如果没有其他 Nginx 占用 80 端口

# 创建目录
sudo mkdir -p /var/www/chef-assistant/backend
sudo chown -R www-data:www-data /var/www/chef-assistant
```

### 2. 部署后端

```bash
cd /var/www/chef-assistant/backend
python3 -m venv venv
venv/bin/pip install -r requirements.txt

# 创建数据库文件
touch chef.db
mkdir -p uploads

# 创建 .env
echo "ANTHROPIC_API_KEY=sk-ant-xxxx" > .env

# 设置权限
sudo chown -R www-data:www-data /var/www/chef-assistant/backend
sudo chmod 664 chef.db
sudo chmod 775 uploads
```

### 3. 创建 systemd 服务

```ini
# /etc/systemd/system/chef-assistant.service
[Unit]
Description=Chef Assistant FastAPI Backend
After=network.target

[Service]
User=www-data
WorkingDirectory=/var/www/chef-assistant/backend
ExecStart=/var/www/chef-assistant/backend/venv/bin/uvicorn main:app --host 0.0.0.0 --port 8001 --workers 2
Restart=always
RestartSec=3
EnvironmentFile=/var/www/chef-assistant/backend/.env

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl daemon-reload
sudo systemctl enable --now chef-assistant.service
```

### 4. 构建前端并部署

**本地 Windows：**
```powershell
cd chef-assistant\frontend
npm install
npm run build
# 构建输出在 ..\backend\static\
scp -r ..\backend\static\* ubuntu@服务器IP:/var/www/chef-assistant/backend/static/
```

**或直接在服务器上构建（需要 Node 18）：**
```bash
cd /home/ubuntu/chef_assistant/frontend
npm install
node_modules/.bin/vite build
cp -r /home/ubuntu/chef_assistant/backend/static/* /var/www/chef-assistant/backend/static/
```

### 5. 配置 Nginx

**独立服务器（无其他项目）：**
```nginx
server {
    listen 80;
    server_name 你的IP或域名;
    location / {
        proxy_pass http://127.0.0.1:8001;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

**与 Docker Nginx 共存（本项目情况）：**

在 Docker 容器的 nginx.conf 的 `http {}` 块末尾添加：
```nginx
server {
    listen 80 default_server;
    server_name _;
    location / {
        proxy_pass http://172.17.0.1:8001;  # 172.17.0.1 = Docker宿主机网关
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

```bash
docker exec 容器名 nginx -t
docker exec 容器名 nginx -s reload
```

---

## 四、日常更新流程

### 更新前端

```powershell
# 本地修改代码后
cd chef-assistant\frontend
npm run build
scp -r ..\backend\static\* ubuntu@43.165.172.199:/var/www/chef-assistant/backend/static/
```

> ⚠️ 注意：一定要上传到 `/var/www/chef-assistant/backend/static/`，不是 `/var/www/chef-assistant/static/`

### 更新后端

```bash
# 修改代码后
sudo systemctl restart chef-assistant.service
sudo systemctl status chef-assistant.service
```

---

## 五、关键路径速查

| 用途 | 路径 |
|------|------|
| 后端代码 | `/var/www/chef-assistant/backend/` |
| 前端静态文件 | `/var/www/chef-assistant/backend/static/` |
| 图片上传目录 | `/var/www/chef-assistant/backend/uploads/` |
| SQLite 数据库 | `/var/www/chef-assistant/backend/chef.db` |
| 环境变量 | `/var/www/chef-assistant/backend/.env` |
| systemd 服务 | `/etc/systemd/system/chef-assistant.service` |
| Docker Nginx 配置 | `/home/ubuntu/visa-card-app/nginx/nginx.conf` |
| 前端源码 | `/home/ubuntu/chef_assistant/frontend/src/` |

---

## 六、常用排查命令

```bash
# 查看后端服务状态和日志
sudo systemctl status chef-assistant.service
sudo journalctl -u chef-assistant.service -n 50 --no-pager

# 测试后端是否正常
curl -s http://127.0.0.1:8001/api/health
curl -s http://127.0.0.1:8001/api/ingredients

# 查看端口监听
ss -tlnp | grep 8001

# 重载 Docker Nginx
docker exec visa-card-app_nginx_1 nginx -t
docker exec visa-card-app_nginx_1 nginx -s reload
docker logs visa-card-app_nginx_1 --tail 20

# 查看真实公网 IP
curl -s ifconfig.me
```
