import { defineStore } from 'pinia'
import { ref, computed } from 'vue'

// ── 翻译字典 ──────────────────────────────────────────────
const messages = {
  zh: {
    // 导航
    'nav.map': '避雷地图', 'nav.table': '数据明细', 'nav.analysis': '统计分析',
    'nav.forum': '论坛', 'nav.import': '导入导出', 'nav.admin': '后台管理',
    'nav.login': '登录', 'nav.register': '注册',
    'nav.profile': '个人中心', 'nav.myPosts': '我的帖子', 'nav.logout': '退出登录',
    'nav.admin.tag': '管理员', 'nav.vip.tag': 'VIP',
    // 统计卡
    'stat.records': '避雷记录', 'stat.locations': '覆盖地点',
    'stat.avgWage': '平均时薪', 'stat.highRisk': '高风险记录',
    // 地图
    'map.topRegions': '🔴 踩坑最多地区', 'map.topReasons': '⚠️ 主要避雷理由', 'map.topJobs': '💼 高频避雷岗位',
    // VIP
    'vip.bannerTitle': '当前为受限视图', 'vip.bannerDesc': '普通用户仅可查看部分信息（每州前3条、无原帖链接）。成为 VIP 解锁全部避雷记录与原帖链接。',
    'vip.contact': '联系管理员开通 VIP',
    // 论坛
    'forum.title': '💬 社区论坛', 'forum.sub': '分享经历 · 寻找搭子 · 交流面签',
    'forum.newPost': '✏️ 发帖', 'forum.loginToPost': '登录后发帖',
    'forum.all': '全部', 'forum.latest': '最新', 'forum.hot': '热门',
    'forum.posts': '个帖子', 'forum.empty': '还没有帖子，来发第一帖吧！', 'forum.loading': '加载中…',
    'forum.prev': '上一页', 'forum.next': '下一页',
    // 通用
    'common.save': '保存', 'common.cancel': '取消', 'common.delete': '删除',
    'common.edit': '编辑', 'common.confirm': '确认', 'common.search': '搜索',
    // 登录注册
    'auth.login': '登录', 'auth.register': '注册', 'auth.username': '用户名',
    'auth.password': '密码', 'auth.email': '邮箱', 'auth.code': '邮箱验证码',
    'auth.getCode': '获取验证码', 'auth.forgot': '忘记密码？',
    'auth.noAccount': '还没有账号？', 'auth.hasAccount': '已有账号？',
    'auth.registerNow': '立即注册', 'auth.goLogin': '去登录',
    // 主题/语言
    'theme.light': '白天模式', 'theme.dark': '夜间模式',
  },
  en: {
    'nav.map': 'Risk Map', 'nav.table': 'Records', 'nav.analysis': 'Analytics',
    'nav.forum': 'Forum', 'nav.import': 'Import/Export', 'nav.admin': 'Admin',
    'nav.login': 'Log in', 'nav.register': 'Sign up',
    'nav.profile': 'Profile', 'nav.myPosts': 'My Posts', 'nav.logout': 'Log out',
    'nav.admin.tag': 'Admin', 'nav.vip.tag': 'VIP',
    'stat.records': 'Records', 'stat.locations': 'Locations',
    'stat.avgWage': 'Avg Wage', 'stat.highRisk': 'High Risk',
    'map.topRegions': '🔴 Most Reported Regions', 'map.topReasons': '⚠️ Top Warning Reasons', 'map.topJobs': '💼 Frequently Flagged Jobs',
    'vip.bannerTitle': 'Limited view', 'vip.bannerDesc': 'Free users see partial info only (top 3 per state, no source links). Upgrade to VIP to unlock all records and original post links.',
    'vip.contact': 'Contact admin for VIP',
    'forum.title': '💬 Community Forum', 'forum.sub': 'Share experiences · Find partners · Visa talk',
    'forum.newPost': '✏️ New Post', 'forum.loginToPost': 'Log in to post',
    'forum.all': 'All', 'forum.latest': 'Latest', 'forum.hot': 'Hot',
    'forum.posts': 'posts', 'forum.empty': 'No posts yet — be the first!', 'forum.loading': 'Loading…',
    'forum.prev': 'Prev', 'forum.next': 'Next',
    'common.save': 'Save', 'common.cancel': 'Cancel', 'common.delete': 'Delete',
    'common.edit': 'Edit', 'common.confirm': 'Confirm', 'common.search': 'Search',
    'auth.login': 'Log in', 'auth.register': 'Sign up', 'auth.username': 'Username',
    'auth.password': 'Password', 'auth.email': 'Email', 'auth.code': 'Email Code',
    'auth.getCode': 'Send Code', 'auth.forgot': 'Forgot password?',
    'auth.noAccount': "Don't have an account?", 'auth.hasAccount': 'Already have an account?',
    'auth.registerNow': 'Sign up now', 'auth.goLogin': 'Log in',
    'theme.light': 'Light Mode', 'theme.dark': 'Dark Mode',
  }
}

export const useSettingsStore = defineStore('settings', () => {
  const theme = ref(localStorage.getItem('swt_theme') || 'dark')   // dark | light
  const locale = ref(localStorage.getItem('swt_locale') || 'zh')   // zh | en

  function applyTheme() {
    document.documentElement.setAttribute('data-theme', theme.value)
    localStorage.setItem('swt_theme', theme.value)
  }
  function toggleTheme() {
    theme.value = theme.value === 'dark' ? 'light' : 'dark'
    applyTheme()
  }
  function setLocale(l) {
    locale.value = l
    localStorage.setItem('swt_locale', l)
  }
  function toggleLocale() {
    setLocale(locale.value === 'zh' ? 'en' : 'zh')
  }

  const t = computed(() => {
    const dict = messages[locale.value] || messages.zh
    return (key) => dict[key] ?? messages.zh[key] ?? key
  })

  return { theme, locale, applyTheme, toggleTheme, setLocale, toggleLocale, t }
})
