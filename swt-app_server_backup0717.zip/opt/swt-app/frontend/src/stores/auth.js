import { defineStore } from 'pinia'
import { ref, computed } from 'vue'
import { authApi } from '../api/index.js'

export const useAuthStore = defineStore('auth', () => {
  const token = ref(localStorage.getItem('swt_token') || '')
  const user = ref(JSON.parse(localStorage.getItem('swt_user') || 'null'))

  const isLoggedIn = computed(() => !!token.value && !!user.value)
  const isAdmin = computed(() => user.value?.role === 'admin')
  const isVip = computed(() => user.value?.role === 'admin' || user.value?.is_vip === true)

  function _persist() {
    if (token.value) localStorage.setItem('swt_token', token.value)
    else localStorage.removeItem('swt_token')
    if (user.value) localStorage.setItem('swt_user', JSON.stringify(user.value))
    else localStorage.removeItem('swt_user')
  }

  async function login(username, password) {
    const res = await authApi.login({ username, password })
    token.value = res.token
    user.value = res.user
    _persist()
    return res
  }

  async function register(
  username,
  password,
  email,
  code,
  inviteCode = '') {
    const res = await authApi.register({
  username,
  password,
  email,
  code,
  invite_code: inviteCode
})
    token.value = res.token
    user.value = res.user
    _persist()
    return res
  }

  async function refreshMe() {
    if (!token.value) return
    try {
      const me = await authApi.me()
      user.value = me
      _persist()
    } catch (e) {
      logout()
    }
  }

  function setUser(u) {
    user.value = u
    _persist()
  }

  function logout() {
    token.value = ''
    user.value = null
    _persist()
  }

  return { token, user, isLoggedIn, isAdmin,isVip, login, register, refreshMe, setUser, logout }
})
