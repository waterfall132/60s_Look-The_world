<template>
  <div v-if="!auth.isVip" class="vip-banner">
    <span class="icon">👑</span>
    <span>{{ text }}</span>
    <button v-if="!auth.user" @click="$router.push('/register')">立即注册</button>
  </div>
</template>

<script setup>
import { computed } from 'vue'
import { useAuthStore } from '../stores/auth'

const auth = useAuthStore()
const text = computed(() =>
  auth.user ? 'VIP 可查看完整内容 · 联系管理员开通' : 'VIP 可查看完整内容'
)
</script>

<style scoped>
.vip-banner {
  background: linear-gradient(135deg, #FFD700, #FFA500);
  padding: 12px 20px;
  margin-bottom: 20px;
  border-radius: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 12px;
  color: #000;
  font-weight: 500;
}
.icon { font-size: 20px; }
button {
  padding: 6px 16px;
  background: #000;
  color: #FFD700;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-weight: 600;
}
button:hover { background: #333; }
</style>
