﻿import axios from 'axios'

const BASE = import.meta.env.VITE_API_BASE || '/api'

const api = axios.create({ baseURL: BASE, timeout: 30000 })

// 请求拦截器：自动注入 token
api.interceptors.request.use(config => {
  const token = localStorage.getItem('swt_token')
  if (token) {
    config.headers.Authorization = `Bearer ${token}`
  }
  return config
})

// 响应拦截器：解包 data，统一错误处理
api.interceptors.response.use(
  res => res.data,
  err => {
    // 401 时清除登录态
    if (err.response?.status === 401) {
      localStorage.removeItem('swt_token')
      localStorage.removeItem('swt_user')
    }
    return Promise.reject(new Error(err.response?.data?.detail || err.message || '请求失败'))
  }
)

// ── 避雷记录 ──────────────────────────────────────────────
export const recordsApi = {
  list: (params) => api.get('/records', { params }),
  get: (id) => api.get(`/records/${id}`),
  submit: (data) => api.post('/records/submit', data),
  create: (data) => api.post('/records', data),
  update: (id, data) => api.put(`/records/${id}`, data),
  review: (id, data) => api.put(`/records/${id}/review`, data),
  delete: (id) => api.delete(`/records/${id}`),
  deleteAll: () => api.delete('/records'),
  toggleFavorite: (id, groupId) => api.post(`/records/${id}/favorite`, null, { params: groupId ? { group_id: groupId } : {} }),
  feedback: (id, data) => api.post(`/records/${id}/feedback`, data),
}

export const statsApi = {
  get: () => api.get('/stats'),
  mapData: () => api.get('/map-data'),
  health: () => api.get('/health')
}

export const importExportApi = {
  import: (file) => {
    const form = new FormData()
    form.append('file', file)
    return api.post('/import', form, {
      headers: { 'Content-Type': 'multipart/form-data' }
    })
  },
  exportBlob: (valuableOnly = true) => {
    const token = localStorage.getItem('swt_token')
    return axios.get(`${BASE}/export?valuable_only=${valuableOnly}`, {
      responseType: 'blob',
      headers: token ? { Authorization: `Bearer ${token}` } : {}
    })
  }
}

export const assessmentApi = {
  quota: () => api.get('/assessments/quota'),
  employer: (data) => api.post('/assessments/employer', data),
}


// ── 美签面签助手题库 ─────────────────────────────────────
export const visaCardsApi = {
  templates: () => api.get('/visa-cards/templates'),
  list: () => api.get('/visa-cards'),
  create: (data) => api.post('/visa-cards', data),
  update: (id, data) => api.put(`/visa-cards/${id}`, data),
  delete: (id) => api.delete(`/visa-cards/${id}`),
  replace: (cards) => api.post('/visa-cards/replace', { cards }),
  importTemplate: (templateId) => api.post(`/visa-cards/templates/${templateId}/import`),
}
// ── 认证 / 用户 ───────────────────────────────────────────
export const authApi = {
  sendCode: (data) => api.post('/auth/send-code', data),
  register: (data) => api.post('/auth/register', data),
  login: (data) => api.post('/auth/login', data),
  forgotPassword: (data) => api.post('/auth/forgot-password', data),
  me: () => api.get('/auth/me'),
  updateMe: (data) => api.put('/auth/me', data),
  changePassword: (data) => api.put('/auth/me/password', data),
  getUser: (id) => api.get(`/auth/users/${id}`),
  favorites: (params) => api.get('/me/favorites', { params }),
  favoriteGroups: () => api.get('/favorite-groups'),
  createFavoriteGroup: (data) => api.post('/favorite-groups', data),
  updateFavoriteGroup: (id, data) => api.put(`/favorite-groups/${id}`, data),
  deleteFavoriteGroup: (id) => api.delete(`/favorite-groups/${id}`),
  moveFavorite: (id, data) => api.put(`/favorites/${id}`, data),
}

// ── 论坛 ──────────────────────────────────────────────────
export const forumApi = {
  categories: () => api.get('/forum/categories'),
  category: (slug) => api.get(`/forum/categories/${slug}`),
  posts: (params) => api.get('/forum/posts', { params }),
  post: (id) => api.get(`/forum/posts/${id}`),
  createPost: (data) => api.post('/forum/posts', data),
  updatePost: (id, data) => api.put(`/forum/posts/${id}`, data),
  deletePost: (id) => api.delete(`/forum/posts/${id}`),
  toggleLike: (id) => api.post(`/forum/posts/${id}/like`),
  comments: (postId) => api.get(`/forum/posts/${postId}/comments`),
  createComment: (postId, data) => api.post(`/forum/posts/${postId}/comments`, data),
  deleteComment: (id) => api.delete(`/forum/comments/${id}`),
  myPosts: () => api.get('/forum/my/posts'),
  report: (data) => api.post('/forum/reports', data),
  notifications: () => api.get('/forum/notifications'),
  markNotificationsRead: () => api.post('/forum/notifications/read'),
  drafts: () => api.get('/forum/drafts'),
  createDraft: (data) => api.post('/forum/drafts', data),
  updateDraft: (id, data) => api.put(`/forum/drafts/${id}`, data),
  deleteDraft: (id) => api.delete(`/forum/drafts/${id}`),
}

// ── 管理员 ────────────────────────────────────────────────
export const adminApi = {
  toggleVip: (userId) => api.post(`/admin/users/${userId}/vip`),
  overview: () => api.get('/admin/overview'),
  aiConfig: () => api.get('/admin/ai-config'),
  updateAiConfig: (data) => api.put('/admin/ai-config', data),
  testAiConfig: (data) => api.post('/admin/ai-config/test', data),
  announcements: (params) => api.get('/admin/announcements', { params }),
  createAnnouncement: (data) => api.post('/admin/announcements', data),
  updateAnnouncement: (id, data) => api.put(`/admin/announcements/${id}`, data),
  deleteAnnouncement: (id) => api.delete(`/admin/announcements/${id}`),
  users: (params) => api.get('/admin/users', { params }),
  updateUser: (id, data) => api.put(`/admin/users/${id}`, data),
  resetPassword: (id, data) => api.put(`/admin/users/${id}/password`, data),
  deleteUser: (id) => api.delete(`/admin/users/${id}`),
  createCategory: (data) => api.post('/admin/categories', data),
  updateCategory: (id, data) => api.put(`/admin/categories/${id}`, data),
  deleteCategory: (id) => api.delete(`/admin/categories/${id}`),
  posts: (params) => api.get('/admin/posts', { params }),
  moderatePost: (id, data) => api.put(`/admin/posts/${id}/moderate`, data),
  deletePost: (id) => api.delete(`/admin/posts/${id}`),
  reports: (params) => api.get('/admin/reports', { params }),
  moderateReport: (id, data) => api.put(`/admin/reports/${id}`, data),
  recordFeedback: (params) => api.get('/admin/record-feedback', { params }),
  moderateRecordFeedback: (id, data) => api.put(`/admin/record-feedback/${id}`, data),
  sensitiveWords: () => api.get('/admin/sensitive-words'),
  createSensitiveWord: (data) => api.post('/admin/sensitive-words', data),
  updateSensitiveWord: (id, data) => api.put(`/admin/sensitive-words/${id}`, data),
  deleteSensitiveWord: (id) => api.delete(`/admin/sensitive-words/${id}`),
  bans: () => api.get('/admin/bans'),
  createBan: (data) => api.post('/admin/bans', data),
  liftBan: (id) => api.post(`/admin/bans/${id}/lift`),
  inviteCodes: () =>
  api.get('/admin/invite-codes'),

  createInviteCode: (data) =>
      api.post('/admin/invite-codes', data),

  updateInviteCode: (id, data) =>
      api.put(`/admin/invite-codes/${id}`, data),

  deleteInviteCode: (id) =>
      api.delete(`/admin/invite-codes/${id}`),
}

export default api

