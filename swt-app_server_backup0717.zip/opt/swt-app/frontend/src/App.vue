﻿<template>
  <div class="app">
    <header class="nav">
      <div class="nav-brand" @click="$router.push('/map')" style="cursor:pointer">
        <span class="brand-swt">SWT</span><span class="brand-text">避雷</span>
        <span class="brand-sub">{{ settings.locale === 'zh' ? '情报系统' : 'Intel System' }}</span>
      </div>

      <nav class="nav-links" :class="{ open: menuOpen }">
        <router-link to="/map" @click="menuOpen=false">🗺️ <span>{{ t('nav.map') }}</span></router-link>
        <router-link to="/table" @click="menuOpen=false">📋 <span>{{ t('nav.table') }}</span></router-link>
        <router-link to="/analysis" @click="menuOpen=false">📈 <span>{{ t('nav.analysis') }}</span></router-link>
        <router-link to="/assessment" @click="menuOpen=false">📍 <span>{{ settings.locale === 'zh' ? '雇主评估' : 'Assessment' }}</span></router-link>
        <router-link v-if="auth.isLoggedIn" to="/visa-cards" @click="menuOpen=false">🎙️ <span>{{ settings.locale === 'zh' ? '面签助手' : 'Visa Prep' }}</span></router-link>
        <router-link to="/forum" @click="menuOpen=false">💬 <span>{{ t('nav.forum') }}</span></router-link>
        <router-link v-if="auth.isAdmin" to="/import" @click="menuOpen=false">⬇️ <span>{{ t('nav.import') }}</span></router-link>
        <router-link v-if="auth.isAdmin" to="/admin" class="admin-link" @click="menuOpen=false">⚙️ <span>{{ t('nav.admin') }}</span></router-link>
      </nav>

      <div class="nav-right">
        <!-- 主题切换 -->
        <button class="icon-btn" :title="settings.theme === 'dark' ? t('theme.light') : t('theme.dark')" @click="settings.toggleTheme()">
          {{ settings.theme === 'dark' ? '☀️' : '🌙' }}
        </button>
        <!-- 语言切换 -->
        <button class="icon-btn lang-btn" title="中 / EN" @click="settings.toggleLocale()">
          {{ settings.locale === 'zh' ? 'EN' : '中' }}
        </button>

        <div v-if="auth.isLoggedIn" class="notice-menu" ref="noticeEl">
          <button class="icon-btn notice-btn" title="通知" @click.stop="toggleNotifications">
            🔔
            <span v-if="unreadCount" class="notice-dot">{{ unreadCount > 9 ? '9+' : unreadCount }}</span>
          </button>
          <div v-if="noticeOpen" class="notice-dropdown">
            <div class="notice-head">
              <b>通知</b>
              <button v-if="notifications.length" @click.stop="markNotificationsRead">全部已读</button>
            </div>
            <div v-if="!notifications.length" class="notice-empty">暂无通知</div>
            <div v-else class="notice-list">
              <div v-for="n in notifications.slice(0, 8)" :key="n.id" :class="['notice-row', { unread: !n.is_read }]" @click="openNotification(n)">
                <div class="notice-title">{{ n.title }}</div>
                <div class="notice-body">{{ n.body }}</div>
              </div>
            </div>
          </div>
        </div>

        <div v-if="auth.isLoggedIn" class="user-menu" @click="userMenuOpen = !userMenuOpen" ref="userMenuEl">
          <span class="user-avatar">{{ auth.user.avatar }}</span>
          <span class="user-name">{{ auth.user.username }}</span>
          <span v-if="auth.isAdmin" class="admin-tag">{{ t('nav.admin.tag') }}</span>
          <span v-else-if="auth.user.is_vip" class="vip-tag">👑 {{ t('nav.vip.tag') }}</span>
          <div v-if="userMenuOpen" class="user-dropdown">
            <router-link to="/profile" @click="userMenuOpen=false">👤 {{ t('nav.profile') }}</router-link>
            <router-link to="/my-posts" @click="userMenuOpen=false">📝 {{ t('nav.myPosts') }}</router-link>
            <a @click="doLogout">🚪 {{ t('nav.logout') }}</a>
          </div>
        </div>
        <div v-else class="auth-buttons">
          <router-link to="/login" class="btn-login">{{ t('nav.login') }}</router-link>
          <router-link to="/register" class="btn-register">{{ t('nav.register') }}</router-link>
        </div>

        <button class="menu-toggle" @click="menuOpen = !menuOpen">☰</button>
      </div>
    </header>

    <main class="main-content">
      <router-view v-slot="{ Component }">
        <transition name="fade" mode="out-in">
          <component :is="Component" />
        </transition>
      </router-view>
    </main>
  </div>
</template>

<script setup>
import { ref, computed, onMounted, onUnmounted } from 'vue'
import { useRouter } from 'vue-router'
import { useAuthStore } from './stores/auth.js'
import { useSettingsStore } from './stores/settings.js'
import { forumApi } from './api/index.js'

const auth = useAuthStore()
const settings = useSettingsStore()
const router = useRouter()
const menuOpen = ref(false)
const userMenuOpen = ref(false)
const noticeOpen = ref(false)
const userMenuEl = ref(null)
const noticeEl = ref(null)
const notifications = ref([])
const unreadCount = ref(0)

const t = computed(() => settings.t)

function doLogout() {
  auth.logout()
  userMenuOpen.value = false
  noticeOpen.value = false
  router.push('/map')
}

function handleClickOutside(e) {
  if (userMenuEl.value && !userMenuEl.value.contains(e.target)) {
    userMenuOpen.value = false
  }
  if (noticeEl.value && !noticeEl.value.contains(e.target)) {
    noticeOpen.value = false
  }
}

async function loadNotifications() {
  if (!auth.isLoggedIn) return
  try {
    const res = await forumApi.notifications()
    notifications.value = res.notifications || []
    unreadCount.value = res.unread || 0
  } catch {
    notifications.value = []
    unreadCount.value = 0
  }
}

async function toggleNotifications() {
  noticeOpen.value = !noticeOpen.value
  userMenuOpen.value = false
  if (noticeOpen.value) await loadNotifications()
}

async function markNotificationsRead() {
  await forumApi.markNotificationsRead()
  await loadNotifications()
}

function openNotification(n) {
  noticeOpen.value = false
  if (n.link_url) {
    if (n.link_url.startsWith('http')) window.open(n.link_url, '_blank', 'noopener')
    else router.push(n.link_url)
    return
  }
  if (n.target_type === 'post' && n.target_id) router.push(`/forum/post/${n.target_id}`)
  else if (n.target_type === 'record' && n.target_id) router.push(`/records/${n.target_id}`)
}

onMounted(async () => {
  settings.applyTheme()
  document.addEventListener('click', handleClickOutside)
  if (auth.token) {
    await auth.refreshMe()
    await loadNotifications()
  }
})
onUnmounted(() => document.removeEventListener('click', handleClickOutside))
</script>

<style>
* { box-sizing: border-box; margin: 0; padding: 0; }

/* ===== 夜间模式（默认）===== */
:root, [data-theme="dark"] {
  --bg: #0a0e1a;
  --surface: #111827;
  --surface2: #1a2235;
  --border: #1e2d47;
  --accent: #f97316;
  --accent2: #3b82f6;
  --accent3: #10b981;
  --red: #ef4444;
  --amber: #f59e0b;
  --text: #e2e8f0;
  --muted: #64748b;
  --nav-bg: linear-gradient(135deg, #0f172a, #1e293b);
  --shadow: rgba(0,0,0,.5);
  --map-tile-filter: none;
  --nav-h: 56px;
}

/* ===== 白天模式 ===== */
[data-theme="light"] {
  --bg: #f4f6fa;
  --surface: #ffffff;
  --surface2: #eef1f6;
  --border: #d8dfe9;
  --accent: #ea580c;
  --accent2: #2563eb;
  --accent3: #059669;
  --red: #dc2626;
  --amber: #d97706;
  --text: #1e293b;
  --muted: #64748b;
  --nav-bg: linear-gradient(135deg, #ffffff, #f1f5f9);
  --shadow: rgba(100,116,139,.25);
  --map-tile-filter: none;
}

body {
  font-family: 'Noto Sans SC', -apple-system, BlinkMacSystemFont, sans-serif;
  background: var(--bg);
  color: var(--text);
  min-height: 100vh;
  transition: background .25s, color .25s;
}

.app { display: flex; flex-direction: column; min-height: 100vh; }

.nav {
  height: var(--nav-h);
  background: var(--nav-bg);
  border-bottom: 1px solid var(--border);
  display: flex;
  align-items: center;
  padding: 0 24px;
  gap: 24px;
  position: sticky;
  top: 0;
  z-index: 1000;
}

.nav-brand { display: flex; align-items: baseline; gap: 4px; flex-shrink: 0; }
.brand-swt { font-family: 'Space Mono', monospace; font-size: 18px; font-weight: 700; color: var(--accent); }
.brand-text { font-size: 18px; font-weight: 700; color: var(--text); }
.brand-sub { font-size: 11px; color: var(--muted); margin-left: 6px; }

.nav-links { display: flex; gap: 4px; flex: 1; }
.nav-links a {
  color: var(--muted); text-decoration: none; padding: 6px 12px;
  border-radius: 6px; font-size: 13px; font-weight: 500; transition: all 0.2s;
  white-space: nowrap;
}
.nav-links a:hover { color: var(--text); background: var(--surface2); }
.nav-links a.router-link-active { color: var(--accent); background: rgba(249,115,22,.12); }
.admin-link { border: 1px solid var(--border); }
.admin-link.router-link-active { border-color: var(--accent) !important; }

.nav-right { display: flex; align-items: center; gap: 8px; flex-shrink: 0; }

.icon-btn {
  background: transparent; border: 1px solid var(--border); color: var(--text);
  width: 32px; height: 32px; border-radius: 8px; cursor: pointer; font-size: 14px;
  display: flex; align-items: center; justify-content: center; transition: all .2s;
  font-family: inherit;
}
.icon-btn:hover { border-color: var(--accent2); }
.lang-btn { font-size: 11px; font-weight: 700; }

.auth-buttons { display: flex; gap: 8px; }
.btn-login, .btn-register {
  text-decoration: none; padding: 6px 14px; border-radius: 6px;
  font-size: 13px; font-weight: 600; transition: all .2s;
}
.btn-login { color: var(--text); border: 1px solid var(--border); }
.btn-login:hover { border-color: var(--accent2); }
.btn-register { background: var(--accent); color: #fff; }
.btn-register:hover { opacity: .9; }

.user-menu {
  display: flex; align-items: center; gap: 8px; cursor: pointer;
  padding: 5px 10px; border-radius: 8px; position: relative;
  border: 1px solid var(--border); transition: all .2s;
}
.user-menu:hover { border-color: var(--accent2); }
.user-avatar { font-size: 18px; }
.user-name { font-size: 13px; font-weight: 600; }
.admin-tag { font-size: 9px; background: var(--accent); color: #fff; padding: 1px 6px; border-radius: 99px; font-weight: 700; }
.vip-tag { font-size: 9px; background: linear-gradient(135deg, #f59e0b, #f97316); color: #fff; padding: 1px 6px; border-radius: 99px; font-weight: 700; }
.user-dropdown {
  position: absolute; top: calc(100% + 8px); right: 0;
  background: var(--surface); border: 1px solid var(--border);
  border-radius: 8px; padding: 6px; min-width: 150px;
  box-shadow: 0 8px 32px var(--shadow); z-index: 1001;
}
.user-dropdown a {
  display: block; padding: 8px 12px; color: var(--text);
  text-decoration: none; font-size: 13px; border-radius: 6px; cursor: pointer;
}
.user-dropdown a:hover { background: var(--surface2); }
.notice-menu { position: relative; }
.notice-btn { position: relative; }
.notice-dot {
  position: absolute; top: -5px; right: -6px; min-width: 16px; height: 16px;
  padding: 0 4px; border-radius: 99px; background: var(--red); color: #fff;
  font-size: 9px; display: flex; align-items: center; justify-content: center;
  border: 1px solid var(--surface);
}
.notice-dropdown {
  position: absolute; top: calc(100% + 8px); right: 0; width: 320px;
  background: var(--surface); border: 1px solid var(--border); border-radius: 8px;
  box-shadow: 0 8px 32px var(--shadow); z-index: 1001; padding: 8px;
}
.notice-head { display: flex; justify-content: space-between; align-items: center; padding: 4px 4px 8px; font-size: 13px; }
.notice-head button { background: transparent; border: 0; color: var(--accent2); cursor: pointer; font-family: inherit; font-size: 11px; }
.notice-empty { color: var(--muted); font-size: 12px; padding: 18px; text-align: center; }
.notice-list { display: flex; flex-direction: column; gap: 6px; max-height: 360px; overflow: auto; }
.notice-row { border: 1px solid var(--border); border-radius: 7px; padding: 8px; cursor: pointer; }
.notice-row.unread { border-color: var(--accent2); background: rgba(59,130,246,.08); }
.notice-title { font-size: 12px; font-weight: 700; margin-bottom: 3px; }
.notice-body { color: var(--muted); font-size: 11px; line-height: 1.5; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; }

.menu-toggle { display: none; background: transparent; border: none; color: var(--text); font-size: 22px; cursor: pointer; }

.main-content { flex: 1; overflow: auto; }

.fade-enter-active, .fade-leave-active { transition: opacity 0.2s, transform 0.2s; }
.fade-enter-from { opacity: 0; transform: translateY(8px); }
.fade-leave-to { opacity: 0; transform: translateY(-4px); }

.page { padding: 20px 24px; max-width: 1400px; margin: 0 auto; width: 100%; }
.page-title { font-size: 18px; font-weight: 700; margin-bottom: 16px; color: var(--text); }

.stat-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; margin-bottom: 20px; }
.stat-card { background: var(--surface); border: 1px solid var(--border); border-radius: 10px; padding: 16px; }
.stat-num { font-family: 'Space Mono', monospace; font-size: 28px; font-weight: 700; color: var(--accent); }
.stat-label { font-size: 11px; color: var(--muted); margin-top: 4px; text-transform: uppercase; letter-spacing: .5px; }

.panel { background: var(--surface); border: 1px solid var(--border); border-radius: 10px; padding: 16px; }
.panel-title { font-size: 12px; font-weight: 700; color: var(--text); margin-bottom: 12px; text-transform: uppercase; letter-spacing: .5px; }

.btn { padding: 7px 16px; border-radius: 6px; border: none; cursor: pointer; font-size: 13px; font-weight: 600; transition: all 0.2s; font-family: inherit; }
.btn-primary { background: var(--accent); color: #fff; }
.btn-primary:hover:not(:disabled) { opacity: .9; transform: translateY(-1px); }
.btn-outline { background: transparent; color: var(--accent2); border: 1px solid var(--accent2); }
.btn-outline:hover { background: rgba(59,130,246,.1); }
.btn-danger { background: transparent; color: var(--red); border: 1px solid var(--red); }
.btn-danger:hover { background: rgba(239,68,68,.1); }
.btn:disabled { opacity: .5; cursor: not-allowed; }

.chip { display: inline-block; padding: 2px 7px; border-radius: 99px; font-size: 10px; background: rgba(249,115,22,.1); color: var(--accent); border: 1px solid rgba(249,115,22,.25); margin: 1px; }
.chip-blue { background: rgba(59,130,246,.1); color: var(--accent2); border-color: rgba(59,130,246,.25); }
.chip-green { background: rgba(16,185,129,.1); color: var(--accent3); border-color: rgba(16,185,129,.25); }

.sev-badge { display: inline-block; padding: 2px 7px; border-radius: 99px; font-size: 11px; font-weight: 700; font-family: 'Space Mono', monospace; }
.sev-5 { background: rgba(239,68,68,.15); color: var(--red); border: 1px solid rgba(239,68,68,.3); }
.sev-4 { background: rgba(245,158,11,.15); color: var(--amber); border: 1px solid rgba(245,158,11,.3); }
.sev-3 { background: rgba(59,130,246,.15); color: var(--accent2); border: 1px solid rgba(59,130,246,.3); }
.sev-2, .sev-1, .sev-0 { background: rgba(100,116,139,.15); color: var(--muted); border: 1px solid rgba(100,116,139,.3); }

input, select, textarea {
  background: var(--surface2); border: 1px solid var(--border); color: var(--text);
  padding: 7px 12px; border-radius: 6px; font-size: 13px; font-family: inherit;
  outline: none; transition: border-color 0.2s;
}
input:focus, select:focus, textarea:focus { border-color: var(--accent2); }
input::placeholder { color: var(--muted); }

table { width: 100%; border-collapse: collapse; font-size: 12px; }
th { background: var(--surface2); padding: 9px 12px; text-align: left; font-weight: 600; color: var(--muted); font-size: 11px; text-transform: uppercase; letter-spacing: .5px; border-bottom: 1px solid var(--border); white-space: nowrap; position: sticky; top: 0; z-index: 10; }
td { padding: 9px 12px; border-bottom: 1px solid var(--border); vertical-align: top; }
tr:hover td { background: var(--surface2); }

.link-a { color: var(--accent2); text-decoration: none; font-size: 11px; cursor: pointer; }
.link-a:hover { text-decoration: underline; }

.bar-row { display: grid; grid-template-columns: 160px 1fr 32px; gap: 8px; align-items: center; margin: 6px 0; font-size: 12px; }
.bar-track { height: 6px; background: var(--surface2); border-radius: 99px; overflow: hidden; }
.bar-fill { height: 100%; border-radius: 99px; transition: width .8s ease; }
.bar-count { color: var(--muted); font-family: 'Space Mono', monospace; font-size: 11px; text-align: right; }

.toast { position: fixed; bottom: 24px; right: 24px; background: var(--surface); border: 1px solid var(--border); border-radius: 8px; padding: 12px 16px; font-size: 13px; z-index: 9999; box-shadow: 0 8px 32px var(--shadow); animation: slideUp .3s ease; }
.toast.success { border-color: var(--accent3); color: var(--accent3); }
.toast.error { border-color: var(--red); color: var(--red); }
@keyframes slideUp { from { opacity:0; transform: translateY(20px); } to { opacity:1; transform:none; } }

.auth-card { max-width: 400px; margin: 60px auto; background: var(--surface); border: 1px solid var(--border); border-radius: 14px; padding: 32px; }
.auth-card h2 { font-size: 22px; margin-bottom: 6px; }
.auth-card .sub { color: var(--muted); font-size: 13px; margin-bottom: 24px; }
.form-group { margin-bottom: 16px; }
.form-group label { display: block; font-size: 12px; color: var(--muted); margin-bottom: 6px; }
.form-group input, .form-group textarea, .form-group select { width: 100%; }
.form-error { color: var(--red); font-size: 12px; margin-top: 8px; }
.form-foot { margin-top: 20px; text-align: center; font-size: 13px; color: var(--muted); }
.form-foot a { color: var(--accent2); text-decoration: none; }

/* VIP 升级提示横幅 */
.vip-banner {
  display: flex; align-items: center; gap: 12px; flex-wrap: wrap;
  background: linear-gradient(135deg, rgba(245,158,11,.12), rgba(249,115,22,.08));
  border: 1px solid rgba(245,158,11,.35); border-radius: 10px;
  padding: 12px 16px; margin-bottom: 16px; font-size: 13px;
}
.vip-banner .vb-icon { font-size: 22px; }
.vip-banner .vb-title { font-weight: 700; color: var(--amber); }
.vip-banner .vb-desc { color: var(--muted); font-size: 12px; flex: 1; min-width: 200px; }

@media (max-width: 900px) {
  .stat-grid { grid-template-columns: repeat(2,1fr); }
  .nav { padding: 0 12px; gap: 10px; }
  .menu-toggle { display: block; }
  .nav-links {
    position: fixed; top: var(--nav-h); left: 0; right: 0;
    flex-direction: column; background: var(--surface);
    border-bottom: 1px solid var(--border); padding: 8px;
    transform: translateY(-150%); transition: transform .25s; z-index: 999;
  }
  .nav-links.open { transform: translateY(0); }
  .nav-links a { padding: 10px 14px; }
  .brand-sub { display: none; }
  .user-name { display: none; }
  .page { padding: 16px; }
}
</style>


