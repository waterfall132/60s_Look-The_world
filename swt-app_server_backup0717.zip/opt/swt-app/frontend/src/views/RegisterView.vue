<template>
  <div class="page">
    <div class="auth-card">
      <h2>注册</h2>
      <div class="sub">加入 SWT 避雷社区</div>

      <div class="form-group">
        <label>用户名 <small>(2-20 字符)</small></label>
        <input v-model="username" placeholder="起个名字" />
      </div>

      <div class="form-group">
        <label>邮箱</label>
        <input v-model="email" type="email" placeholder="your@email.com" />
      </div>

      <div class="form-group">
        <label>邮箱验证码</label>
        <div class="code-row">
          <input v-model="code" placeholder="6 位验证码" maxlength="6" />
          <button class="btn btn-outline code-btn" :disabled="countdown > 0 || sending" @click="sendCode">
            {{ countdown > 0 ? `${countdown}s 后重发` : (sending ? '发送中…' : '获取验证码') }}
          </button>
        </div>
        <!-- 开发模式：把验证码直接显示出来，方便本地调试 -->
        <div v-if="devCode" class="dev-code">
          🛠 开发模式验证码：<b>{{ devCode }}</b>（上线后会真发到邮箱）
        </div>
      </div>


      <div class="form-group">
        <label>邀请码（可选）</label>
        <input
            v-model="inviteCode"
           placeholder="输入邀请码可获得VIP，例如 FOUNDING200"/>
      </div>

      <div class="form-group">
        <label>密码 <small>(至少 6 位)</small></label>
        <input v-model="password" type="password" @keyup.enter="doRegister" placeholder="设置密码" />
      </div>

      <button class="btn btn-primary" style="width:100%" :disabled="loading" @click="doRegister">
        {{ loading ? '注册中…' : '注册' }}
      </button>

      <div v-if="error" class="form-error">{{ error }}</div>
      <div class="form-foot">
        已有账号？<router-link to="/login">去登录</router-link>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onUnmounted } from 'vue'
import { useRouter } from 'vue-router'
import { useAuthStore } from '../stores/auth.js'
import { authApi } from '../api/index.js'

const auth = useAuthStore()
const router = useRouter()

const username = ref('')
const email = ref('')
const code = ref('')
const password = ref('')
const inviteCode = ref('')
const loading = ref(false)
const sending = ref(false)
const error = ref('')
const countdown = ref(0)
const devCode = ref('')
let timer = null

function isValidEmail(e) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e)
}

async function sendCode() {
  error.value = ''
  if (!isValidEmail(email.value)) { error.value = '请输入有效的邮箱地址'; return }
  sending.value = true
  try {
    const res = await authApi.sendCode({ email: email.value.trim(), purpose: 'register' })
    // 开发模式后端会返回 dev_code
    if (res.dev_code) devCode.value = res.dev_code
    // 启动倒计时
    countdown.value = 60
    timer = setInterval(() => {
      countdown.value--
      if (countdown.value <= 0) clearInterval(timer)
    }, 1000)
  } catch (e) {
    error.value = e.message
  } finally {
    sending.value = false
  }
}

async function doRegister() {
  error.value = ''
  if (!username.value || !password.value) { error.value = '请填写用户名和密码'; return }
  if (!isValidEmail(email.value)) { error.value = '请输入有效的邮箱地址'; return }
  if (!code.value.trim()) { error.value = '请填写邮箱验证码'; return }
  loading.value = true
  try {
    await auth.register(
  username.value.trim(),
  password.value,
  email.value.trim(),
  code.value.trim(),
  inviteCode.value.trim())
    router.push('/forum')
  } catch (e) {
    error.value = e.message
  } finally {
    loading.value = false
  }
}

onUnmounted(() => { if (timer) clearInterval(timer) })
</script>

<style scoped>
.code-row { display: flex; gap: 8px; }
.code-row input { flex: 1; }
.code-btn { white-space: nowrap; flex-shrink: 0; padding: 7px 12px; font-size: 12px; }
.dev-code {
  margin-top: 8px; padding: 8px 10px; background: rgba(16,185,129,.08);
  border: 1px dashed rgba(16,185,129,.4); border-radius: 6px;
  font-size: 12px; color: var(--accent3);
}
.dev-code b { font-family: 'Space Mono', monospace; font-size: 14px; letter-spacing: 1px; }
</style>
