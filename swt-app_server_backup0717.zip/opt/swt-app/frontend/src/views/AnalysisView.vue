<template>
  <div class="page">
    <div v-if="loading" class="empty">加载中…</div>
    <div v-else-if="!stats.total" class="empty">暂无数据，请先导入记录</div>
    <div v-else class="analysis-grid">

      <!-- Top stats -->
      <div class="stat-grid" style="grid-column:1/-1">
        <div class="stat-card"><div class="stat-num">{{ stats.total }}</div><div class="stat-label">有效记录</div></div>
        <div class="stat-card"><div class="stat-num">{{ stats.located }}</div><div class="stat-label">覆盖州数</div></div>
        <div class="stat-card"><div class="stat-num">{{ stats.high_severity }}</div><div class="stat-label">高风险 ≥4</div></div>
        <div class="stat-card">
          <div class="stat-num" style="color:var(--accent3)">{{ stats.wage_stats?.avg ? '$'+stats.wage_stats.avg : '—' }}</div>
          <div class="stat-label">平均时薪</div>
        </div>
      </div>

      <!-- Reasons full bar chart -->
      <div class="panel" style="grid-column:1/-1">
        <div class="panel-title">⚠️ 避雷理由排行（全量）</div>
        <div v-for="[reason, cnt] in (stats.reason_counts || [])" :key="reason"
             class="bar-row" style="grid-template-columns:200px 1fr 32px;margin:8px 0">
          <div style="font-size:12px">{{ reason }}</div>
          <div class="bar-track" style="height:8px">
            <div class="bar-fill" :style="{ width: barW(cnt, stats.reason_counts)+'%', background:'linear-gradient(90deg,#ef4444,#f97316)' }"></div>
          </div>
          <div class="bar-count">{{ cnt }}</div>
        </div>
      </div>

      <!-- State ranking -->
      <div class="panel">
        <div class="panel-title">🗺️ 踩坑州排行</div>
        <div v-for="([st, cnt], i) in (stats.state_counts || [])" :key="st"
             class="bar-row" style="grid-template-columns:48px 1fr 32px;margin:8px 0">
          <div style="font-weight:700;color:var(--accent);font-family:'Space Mono',monospace">{{ st }}</div>
          <div class="bar-track">
            <div class="bar-fill" :style="{ width: barW(cnt, stats.state_counts)+'%', background: stateColor(i) }"></div>
          </div>
          <div class="bar-count">{{ cnt }}</div>
        </div>
      </div>

      <!-- Severity distribution -->
      <div class="panel">
        <div class="panel-title">📊 严重度分布</div>
        <div v-for="sev in [5,4,3,2,1]" :key="sev"
             class="bar-row" style="grid-template-columns:72px 1fr 32px;margin:8px 0">
          <div><span :class="'sev-badge sev-'+sev">严重{{ sev }}</span></div>
          <div class="bar-track" style="height:8px">
            <div class="bar-fill" :style="{ width: barWSev(sev)+'%', background: sevColor(sev) }"></div>
          </div>
          <div class="bar-count">{{ stats.severity_distribution?.[sev] || 0 }}</div>
        </div>
      </div>

      <!-- Wage stats -->
      <div class="panel">
        <div class="panel-title">💰 时薪统计</div>
        <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px;margin:12px 0">
          <div style="text-align:center">
            <div style="font-size:26px;font-weight:700;color:var(--accent3);font-family:'Space Mono',monospace">${{ stats.wage_stats?.avg || '—' }}</div>
            <div style="font-size:10px;color:var(--muted)">平均时薪</div>
          </div>
          <div style="text-align:center">
            <div style="font-size:26px;font-weight:700;color:var(--red);font-family:'Space Mono',monospace">${{ stats.wage_stats?.min || '—' }}</div>
            <div style="font-size:10px;color:var(--muted)">最低时薪</div>
          </div>
          <div style="text-align:center">
            <div style="font-size:26px;font-weight:700;color:var(--accent2);font-family:'Space Mono',monospace">${{ stats.wage_stats?.max || '—' }}</div>
            <div style="font-size:10px;color:var(--muted)">最高时薪</div>
          </div>
        </div>
        <div style="font-size:11px;color:var(--muted);line-height:1.8">
          <span v-for="w in (stats.wage_stats?.samples || [])" :key="w"
                style="margin-right:6px;font-family:'Space Mono',monospace;color:var(--accent3)">${{ w }}</span>
        </div>
      </div>

      <!-- Top positions -->
      <div class="panel" style="grid-column:1/-1">
        <div class="panel-title">💼 高频避雷岗位 TOP20</div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:4px 24px">
          <div v-for="[pos, cnt] in (stats.position_counts || [])" :key="pos"
               class="bar-row" style="grid-template-columns:200px 1fr 32px;margin:5px 0">
            <div style="font-size:11px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" :title="pos">{{ pos }}</div>
            <div class="bar-track">
              <div class="bar-fill" :style="{ width: barW(cnt, stats.position_counts)+'%', background:'#3b82f6' }"></div>
            </div>
            <div class="bar-count">{{ cnt }}</div>
          </div>
        </div>
      </div>

    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { statsApi } from '../api/index.js'

const stats = ref({})
const loading = ref(false)

const STATE_COLORS = ['#3b82f6','#60a5fa','#93c5fd','#bfdbfe','#dbeafe']
const SEV_COLORS = { 5:'#ef4444', 4:'#f97316', 3:'#3b82f6', 2:'#64748b', 1:'#475569' }

const stateColor = (i) => STATE_COLORS[Math.min(i, 4)]
const sevColor = (s) => SEV_COLORS[s]

const barW = (cnt, arr) => {
  if (!arr?.length) return 0
  const max = Math.max(...arr.map(x => x[1]))
  return max ? Math.round(cnt / max * 100) : 0
}

const barWSev = (sev) => {
  const dist = stats.value.severity_distribution || {}
  const max = Math.max(1, ...Object.values(dist))
  return Math.round((dist[sev] || 0) / max * 100)
}

onMounted(async () => {
  loading.value = true
  try { stats.value = await statsApi.get() }
  catch (e) { console.error(e) }
  finally { loading.value = false }
})
</script>

<style scoped>
.analysis-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
.stat-grid { grid-template-columns: repeat(4, 1fr); }
.empty { text-align: center; padding: 80px; color: var(--muted); font-size: 16px; }
@media (max-width: 900px) {
  .analysis-grid { grid-template-columns: 1fr; }
}
</style>
