<VipBanner />
<template>
  <div class="page">
    <div class="stat-grid">
      <div class="stat-card"><div class="stat-num">{{ stats.total || 0 }}</div><div class="stat-label">{{ t('stat.records') }}</div></div>
      <div class="stat-card"><div class="stat-num">{{ stats.located || 0 }}</div><div class="stat-label">{{ t('stat.locations') }}</div></div>
      <div class="stat-card"><div class="stat-num">{{ stats.avg_wage ? '$'+stats.avg_wage : '—' }}</div><div class="stat-label">{{ t('stat.avgWage') }}</div></div>
      <div class="stat-card"><div class="stat-num">{{ stats.high_severity || 0 }}</div><div class="stat-label">{{ t('stat.highRisk') }}</div></div>
    </div>

    <div v-if="limited" class="vip-banner">
      <span class="vb-icon">👑</span>
      <div>
        <div class="vb-title">{{ t('vip.bannerTitle') }}</div>
        <div class="vb-desc">{{ t('vip.bannerDesc') }}</div>
      </div>
      <router-link v-if="!auth.isLoggedIn" to="/register" class="btn btn-primary" style="text-decoration:none">{{ t('nav.register') }}</router-link>
      <span v-else style="font-size:12px;color:var(--amber)">{{ t('vip.contact') }}</span>
    </div>
    <div class="map-layout">
      <div id="leaflet-map" ref="mapEl"></div>
      <div class="map-side">
        <div class="panel">
          <div class="panel-title">{{ t('map.topRegions') }}</div>
          <div v-for="loc in mapLocations.slice(0,12)" :key="loc.state"
               class="loc-item" @click="focusLocation(loc)">
            <div class="loc-name">{{ loc.name }} <small>{{ loc.state }}</small></div>
            <div class="loc-count" :style="{ color: sevColor(loc.max_severity) }">{{ loc.count }}</div>
          </div>
        </div>
        <div class="panel">
          <div class="panel-title">{{ t('map.topReasons') }}</div>
          <div v-for="[reason, cnt] in (stats.reason_counts || []).slice(0,8)" :key="reason" class="bar-row">
            <div style="font-size:11px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" :title="reason">{{ reason.slice(0,13) }}</div>
            <div class="bar-track"><div class="bar-fill" :style="{ width: barW(cnt, stats.reason_counts) + '%', background: '#ef4444' }"></div></div>
            <div class="bar-count">{{ cnt }}</div>
          </div>
        </div>
        <div class="panel">
          <div class="panel-title">{{ t('map.topJobs') }}</div>
          <div v-for="[pos, cnt] in (stats.position_counts || []).slice(0,8)" :key="pos" class="bar-row">
            <div style="font-size:11px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" :title="pos">{{ pos.slice(0,13) }}</div>
            <div class="bar-track"><div class="bar-fill" :style="{ width: barW(cnt, stats.position_counts) + '%', background: '#3b82f6' }"></div></div>
            <div class="bar-count">{{ cnt }}</div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import VipBanner from '../components/VipBanner.vue'
import { ref, computed, onMounted, onUnmounted } from 'vue'
import { statsApi } from '../api/index.js'
import { useSettingsStore } from '../stores/settings.js'
import { useAuthStore } from '../stores/auth.js'

const settings = useSettingsStore()
const auth = useAuthStore()
const t = computed(() => settings.t)
const limited = ref(false)

const mapEl = ref(null)
const isMobile = ref(window.innerWidth <= 768)
function handleResize() { isMobile.value = window.innerWidth <= 768 }

const stats = ref({})
const mapLocations = ref([])
let leafletMap = null
const markerMap = {}

const popupPages = {}

const SEV_COLORS = { 5: '#ef4444', 4: '#f97316', 3: '#3b82f6', 2: '#64748b', 1: '#64748b' }
const sevColor = (s) => SEV_COLORS[s] || '#64748b'
const barW = (cnt, arr) => {
  if (!arr || !arr.length) return 0
  const max = Math.max(...arr.map(x => x[1]))
  return max ? Math.round(cnt / max * 100) : 0
}

function escapeHtml(s) {
  if (!s) return ''
  return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;')
}

// popup 宽度按屏幕动态计算
function popupWidth() {
  const vw = window.innerWidth
  if (vw <= 768) {
    // 移动端：视口的 86%，夹在 250~330 之间
    return Math.max(250, Math.min(330, Math.round(vw * 0.86)))
  }
  return 460
}

function popupPageSize() {
  return window.innerWidth <= 768 ? 2 : 4
}

function buildPopupHtml(loc) {
  const page = popupPages[loc.state] || 0
  const total = loc.records.length
  const pageSize = popupPageSize()
  const totalPages = Math.ceil(total / pageSize)
  const start = page * pageSize
  const pageRecords = loc.records.slice(start, start + pageSize)

  const avgW = loc.avg_wage ? `· 均薪 $${loc.avg_wage}/h` : ''
  const topR = (loc.top_reasons || []).map(([r]) => `<span class="popup-chip">${escapeHtml(r)}</span>`).join('')

  const recHtml = pageRecords.map(rec => {
    const sevBg = SEV_COLORS[rec.severity] || '#64748b'
    const srcTag = rec.source_type === 'comment'
      ? '<span class="popup-src popup-src-c">评论</span>'
      : rec.source_type === 'user'
        ? '<span class="popup-src popup-src-u">用户上报</span>'
        : '<span class="popup-src popup-src-p">帖子</span>'
    return `
      <div class="popup-rec">
        <div class="popup-rec-head">
          <span class="popup-job">${escapeHtml(rec.job_position || '未知岗位')}</span>
          <span class="popup-sev" style="background:${sevBg}22;color:${sevBg};border:1px solid ${sevBg}55">${rec.severity}</span>
          ${srcTag}
        </div>
        <div class="popup-reasons">${(rec.avoidance_reasons || []).slice(0, 4).map(escapeHtml).join(' · ')}</div>
        <div class="popup-summary">${escapeHtml(rec.summary || '')}</div>
        ${rec.id ? `<a href="/records/${escapeHtml(rec.id)}" class="popup-link">站内详情</a>` : ''}
        ${rec.note_url ? `<a href="${escapeHtml(rec.note_url)}" target="_blank" class="popup-link">查看原帖 ↗</a>` : ''}
      </div>`
  }).join('')

  // 非 VIP 且该州还有更多记录时显示升级提示
  let vipHint = ''
  if (limited.value && loc.count > loc.records.length) {
    vipHint = `<div class="popup-vip-hint">👑 该地区共 ${loc.count} 条记录，VIP 可查看全部及原帖链接</div>`
  }

  let pager = ''
  if (totalPages > 1) {
    pager = `
      <div class="popup-pager">
        <button type="button" class="popup-btn" data-popup-state="${escapeHtml(loc.state)}" data-popup-delta="-1" ${page <= 0 ? 'disabled' : ''}>← 上一页</button>
        <span class="popup-page-info">${page + 1} / ${totalPages}（共 ${total} 条）</span>
        <button type="button" class="popup-btn" data-popup-state="${escapeHtml(loc.state)}" data-popup-delta="1" ${page >= totalPages - 1 ? 'disabled' : ''}>下一页 →</button>
      </div>`
  }

  // 用一个固定宽度的内层容器包裹，宽度由 JS 算好，CSS 不再插手宽度
  const w = popupWidth()
  return `
    <div class="popup-box" style="width:${w}px">
      <div class="popup-title">${escapeHtml(loc.name)} · ${loc.count} 条踩坑</div>
      <div class="popup-sub">${escapeHtml(loc.state)} ${avgW}</div>
      <div class="popup-chips">${topR}</div>
      ${recHtml}
      ${vipHint}
      ${pager}
    </div>`
}

function protectPopupEvents(popup) {
  if (!window.L || !popup) return
  const el = popup.getElement && popup.getElement()
  if (!el) return
  window.L.DomEvent.disableClickPropagation(el)
  window.L.DomEvent.disableScrollPropagation(el)
}

// 直接改当前打开的 popup 内容，不重新 openPopup，避免移动端翻页后弹窗被关闭。
function turnPopupPage(stateCode, delta) {
  const loc = mapLocations.value.find(l => l.state === stateCode)
  if (!loc) return

  const totalPages = Math.ceil(loc.records.length / popupPageSize())
  const cur = popupPages[stateCode] || 0
  const next = Math.max(0, Math.min(totalPages - 1, cur + delta))
  if (next === cur) return
  popupPages[stateCode] = next

  const marker = markerMap[stateCode]
  if (!marker) return
  const popup = marker.getPopup()
  if (!popup) return

  // 原地更新内容
  popup.setContent(buildPopupHtml(loc))
  // 仅当 popup 当前确实是打开状态才 update（不重新 open，避免闪烁/消失）
  if (marker.isPopupOpen && marker.isPopupOpen()) {
    popup.update()
    protectPopupEvents(popup)
  }
}

function handlePopupPager(event) {
  const btn = event.target.closest && event.target.closest('.popup-btn[data-popup-state]')
  if (!btn) return

  event.preventDefault()
  event.stopPropagation()
  turnPopupPage(btn.dataset.popupState, Number(btn.dataset.popupDelta || 0))
}

function stopPopupTouch(event) {
  if (!event.target.closest || !event.target.closest('.swt-popup')) return
  event.stopPropagation()
}

async function loadData() {
  try {
    const [s, m] = await Promise.all([statsApi.get(), statsApi.mapData()])
    stats.value = s
    mapLocations.value = m.locations
    limited.value = !!m.limited
    renderMarkers(m.locations)
  } catch (e) { console.error(e) }
}

function initMap() {
  if (!window.L || leafletMap) return
  leafletMap = window.L.map(mapEl.value, { scrollWheelZoom: true, tap: false }).setView([37.5, -96], 4)
  window.L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
    attribution: '© OpenStreetMap, CartoDB', maxZoom: 18
  }).addTo(leafletMap)
}

function renderMarkers(locations) {
  if (!leafletMap) return
  Object.values(markerMap).forEach(m => m.remove())
  Object.keys(markerMap).forEach(k => delete markerMap[k])

  const w = popupWidth()
  for (const loc of locations) {
    popupPages[loc.state] = 0
    const r = Math.max(10, Math.min(38, 7 + loc.count * 6))
    const col = sevColor(loc.max_severity)
    const marker = window.L.circleMarker([loc.lat, loc.lng], {
      radius: r, color: col, weight: 2, fillColor: col, fillOpacity: 0.45
    }).addTo(leafletMap)

    // maxWidth 给足，真实宽度由内层 .popup-box 的内联 width 决定
    marker.bindPopup(buildPopupHtml(loc), {
      maxWidth: w + 40,
      minWidth: w,
      autoPan: true,
      autoPanPadding: [16, 16],
      keepInView: true,
      closeOnClick: false,
      className: 'swt-popup'
    })

    // 打开时重置到第一页并刷新内容
    marker.on('popupopen', () => {
      popupPages[loc.state] = 0
      const popup = marker.getPopup()
      popup.setContent(buildPopupHtml(loc))
      protectPopupEvents(popup)
    })

    markerMap[loc.state] = marker
  }
}

function focusLocation(loc) {
  if (!leafletMap) return
  leafletMap.setView([loc.lat, loc.lng], 7)
  const marker = markerMap[loc.state]
  if (marker) {
    popupPages[loc.state] = 0
    marker.openPopup()
  }
}

function loadLeaflet() {
  return new Promise((resolve) => {
    if (window.L) return resolve()
    const link = document.createElement('link')
    link.rel = 'stylesheet'
    link.href = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css'
    document.head.appendChild(link)
    const script = document.createElement('script')
    script.src = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js'
    script.onload = resolve
    document.head.appendChild(script)
  })
}

onMounted(async () => {
  window.addEventListener('resize', handleResize)
  document.addEventListener('click', handlePopupPager, true)
  document.addEventListener('touchstart', stopPopupTouch, true)
  if (!window.L) await loadLeaflet()
  initMap()
  await loadData()
})

onUnmounted(() => {
  window.removeEventListener('resize', handleResize)
  document.removeEventListener('click', handlePopupPager, true)
  document.removeEventListener('touchstart', stopPopupTouch, true)
  if (leafletMap) { leafletMap.remove(); leafletMap = null }
})
</script>

<style scoped>
.map-layout {
  display: grid;
  grid-template-columns: 1fr 320px;
  gap: 16px;
  height: calc(100vh - 180px);
  min-height: 500px;
}
#leaflet-map { border-radius: 10px; border: 1px solid var(--border); overflow: hidden; min-height: 500px; }
.map-side { display: flex; flex-direction: column; gap: 12px; overflow-y: auto; }
.loc-item { display: flex; justify-content: space-between; align-items: center; padding: 7px 0; border-top: 1px solid var(--border); cursor: pointer; }
.loc-item:first-child { border-top: 0; }
.loc-item:hover { opacity: .8; }
.loc-name { font-size: 13px; font-weight: 600; }
.loc-name small { font-size: 10px; font-weight: 400; color: var(--muted); margin-left: 4px; }
.loc-count { font-family: 'Space Mono', monospace; font-weight: 700; font-size: 16px; }

@media (max-width: 768px) {
  .map-layout { grid-template-columns: 1fr; height: auto; min-height: auto; }
  #leaflet-map { height: 55vh; min-height: 340px; }
  .map-side { max-height: none; overflow: visible; }
}
</style>

<style>
/* ===== Leaflet 弹窗（全局，非 scoped） ===== */
.swt-popup .leaflet-popup-content-wrapper {
  background: var(--surface); border: 1px solid var(--border); border-radius: 12px;
  box-shadow: 0 8px 32px var(--shadow); color: var(--text); padding: 0;
}
.swt-popup .leaflet-popup-tip { background: var(--surface); border: 1px solid var(--border); }

/* 关键：不再用 width:auto，让 content 收缩包裹内层固定宽度的 .popup-box */
.swt-popup .leaflet-popup-content {
  margin: 0 !important;
  width: fit-content !important;
  max-width: none !important;
  line-height: 1.5;
}
.swt-popup a.leaflet-popup-close-button { color: #64748b; padding: 8px 8px 0 0; z-index: 2; }

/* .popup-box 自带内联 width（JS 算好），这里只管内边距和换行 */
.popup-box { padding: 14px; box-sizing: border-box; max-height: 68vh; overflow-y: auto; overscroll-behavior: contain; }
.popup-title { font-weight: 700; font-size: 14px; color: #f97316; word-break: break-word; }
.popup-sub { color: var(--muted); font-size: 11px; margin: 4px 0 8px; }
.popup-chips { margin-bottom: 8px; }
.popup-chip {
  display: inline-block; padding: 2px 6px; border-radius: 99px; font-size: 10px;
  background: rgba(249,115,22,.1); color: #f97316; border: 1px solid rgba(249,115,22,.2); margin: 1px;
}
.popup-rec { background: var(--surface2); border-radius: 8px; padding: 10px; margin-top: 8px; }
.popup-rec-head { display: flex; align-items: center; gap: 6px; flex-wrap: wrap; }
.popup-job { font-weight: 600; font-size: 12px; word-break: break-word; }
.popup-sev { padding: 0 6px; border-radius: 99px; font-size: 10px; font-weight: 700; }
.popup-src { padding: 0 6px; border-radius: 99px; font-size: 9px; font-weight: 600; }
.popup-src-p { background: rgba(59,130,246,.15); color: #60a5fa; }
.popup-src-c { background: rgba(16,185,129,.15); color: #10b981; }
.popup-src-u { background: rgba(245,158,11,.15); color: #f59e0b; }
.popup-reasons { color: var(--muted); margin-top: 4px; font-size: 10px; word-break: break-word; }
.popup-summary { color: var(--muted); font-size: 11px; margin-top: 5px; line-height: 1.6; word-break: break-word; overflow-wrap: break-word; }
.popup-link { color: #3b82f6; font-size: 10px; display: inline-block; margin-top: 5px; text-decoration: none; }
.popup-pager { display: flex; align-items: center; justify-content: space-between; gap: 8px; margin-top: 10px; padding-top: 8px; border-top: 1px solid var(--border); }
.popup-page-info { font-size: 10px; color: var(--muted); white-space: nowrap; }
.popup-btn { background: transparent; color: #3b82f6; border: 1px solid #3b82f6; border-radius: 5px; padding: 3px 8px; font-size: 10px; cursor: pointer; font-family: inherit; white-space: nowrap; }
.popup-btn:hover:not(:disabled) { background: rgba(59,130,246,.1); }
.popup-btn:disabled { opacity: .35; cursor: not-allowed; }
.popup-vip-hint {
  margin-top: 10px; padding: 8px 10px; border-radius: 8px; font-size: 11px;
  background: rgba(245,158,11,.1); border: 1px dashed rgba(245,158,11,.4); color: var(--amber);
}

@media (max-width: 768px) {
  .popup-pager { flex-wrap: wrap; justify-content: center; }
  .popup-page-info { order: -1; width: 100%; text-align: center; margin-bottom: 4px; }
  .popup-btn { min-height: 34px; padding: 7px 12px; font-size: 12px; }
  .popup-box { max-height: 62vh; }
}
</style>
