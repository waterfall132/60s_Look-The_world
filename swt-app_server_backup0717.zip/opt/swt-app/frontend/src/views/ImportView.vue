<template>
  <div class="page">
    <div class="io-grid">

      <!-- Import -->
      <div class="panel">
        <div class="panel-title">⬆️ 导入 JSONL 数据</div>
        <p class="desc">支持从 swt_extractor.py 输出的 JSONL 文件直接导入，每行一条 JSON 记录。</p>

        <div class="upload-zone"
             :class="{ dragover }"
             @dragover.prevent="dragover = true"
             @dragleave="dragover = false"
             @drop.prevent="onDrop"
             @click="fileInput.click()">
          <div v-if="!selectedFile" class="upload-hint">
            <div style="font-size:32px;margin-bottom:8px">📂</div>
            <div>点击或拖拽 .jsonl 文件到这里</div>
            <div style="font-size:11px;color:var(--muted);margin-top:4px">支持 swt_extractor.py 输出格式</div>
          </div>
          <div v-else class="file-selected">
            <span>📄 {{ selectedFile.name }}</span>
            <span style="color:var(--muted);font-size:11px;margin-left:8px">{{ (selectedFile.size/1024).toFixed(1) }} KB</span>
          </div>
        </div>
        <input ref="fileInput" type="file" accept=".jsonl,.json" style="display:none" @change="onFileChange" />

        <div class="import-opts">
          <span class="import-mode">追加导入：新数据会加入当前数据库，已有数据不会被清空。</span>
        </div>

        <button class="btn btn-primary" :disabled="!selectedFile || importing" @click="doImport">
          {{ importing ? '导入中…' : '🚀 开始导入' }}
        </button>

        <div v-if="importResult" class="result-box" :class="importResult.ok ? 'ok' : 'err'">
          <div v-if="importResult.ok">
            ✅ 成功导入 <strong>{{ importResult.imported }}</strong> 条记录
            （跳过重复 {{ importResult.skipped_duplicates || 0 }} 条，文件共 {{ importResult.total_in_file }} 条）
          </div>
          <div v-else>❌ 导入失败：{{ importResult.message }}</div>
          <div v-if="importResult.errors?.length" class="errors">
            <div style="margin-top:8px;font-weight:600">错误详情 ({{ importResult.errors.length }} 条):</div>
            <div v-for="e in importResult.errors.slice(0,5)" :key="e" style="font-size:11px">{{ e }}</div>
          </div>
        </div>
      </div>

      <!-- Export -->
      <div class="panel">
        <div class="panel-title">⬇️ 导出数据</div>
        <p class="desc">将当前数据库中的记录导出为 JSONL 文件，可用于备份或在其他环境使用。</p>

        <div class="export-opts">
          <label class="checkbox-label">
            <input type="checkbox" v-model="valuableOnly" />
            <span>仅导出有价值记录（valuable=true）</span>
          </label>
        </div>

        <div class="export-info">
          <div class="stat-card">
            <div class="stat-num">{{ totalCount }}</div>
            <div class="stat-label">当前记录总数</div>
          </div>
        </div>

        <button class="btn btn-outline" :disabled="exporting" @click="doExport">
          {{ exporting ? '导出中…' : '⬇️ 下载 JSONL 文件' }}
        </button>
      </div>

      <!-- Format spec -->
      <div class="panel" style="grid-column:1/-1">
        <div class="panel-title">📋 JSONL 格式规范</div>
        <p class="desc">每行一条 JSON 对象，字段如下：</p>
        <div class="code-block">{{ formatExample }}</div>
      </div>

    </div>

    <!-- Toast -->
    <div v-if="toast.show" :class="['toast', toast.type]">{{ toast.msg }}</div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { importExportApi, statsApi } from '../api/index.js'

const fileInput = ref(null)
const selectedFile = ref(null)
const dragover = ref(false)
const valuableOnly = ref(true)
const importing = ref(false)
const exporting = ref(false)
const importResult = ref(null)
const totalCount = ref(0)
const toast = ref({ show: false, msg: '', type: 'success' })

const formatExample = `{
  "valuable": true,
  "source_type": "post",              // "post" 或 "comment"
  "job_position": "lifeguard",        // 岗位名称（英文）
  "location_name": "Tennessee",       // 工作地点
  "city": null,
  "state": "TN",                      // 美国州缩写
  "hourly_wage": 13,                  // 时薪（美元数字）
  "tips": "无小费",
  "hours_per_day": 10,               // 每天工时
  "hours_per_week": null,
  "avoidance_reasons": ["暴晒/户外高温", "工时过长"],  // 避雷标签数组
  "severity": 5,                     // 严重度 1-5
  "confidence": 0.95,               // 置信度 0-1
  "employer": null,
  "summary": "避雷摘要（50字内）",
  "note_url": "https://www.xiaohongshu.com/..."
}`

function onDrop(e) {
  dragover.value = false
  const file = e.dataTransfer.files[0]
  if (file) selectedFile.value = file
}
function onFileChange(e) {
  selectedFile.value = e.target.files[0] || null
}

async function doImport() {
  if (!selectedFile.value) return
  importing.value = true
  importResult.value = null
  try {
    const res = await importExportApi.import(selectedFile.value)
    importResult.value = { ok: true, ...res }
    showToast(`成功导入 ${res.imported} 条，跳过重复 ${res.skipped_duplicates || 0} 条`, 'success')
    await loadCount()
  } catch (e) {
    importResult.value = { ok: false, message: e.message }
    showToast('导入失败: ' + e.message, 'error')
  } finally {
    importing.value = false
  }
}

async function doExport() {
  exporting.value = true
  try {
    const res = await importExportApi.exportBlob(valuableOnly.value)
    const url = URL.createObjectURL(new Blob([res.data]))
    const a = document.createElement('a')
    a.href = url
    a.download = `swt_records_${new Date().toISOString().slice(0,10)}.jsonl`
    a.click()
    URL.revokeObjectURL(url)
    showToast('导出成功', 'success')
  } catch (e) {
    showToast('导出失败: ' + e.message, 'error')
  } finally {
    exporting.value = false
  }
}

async function loadCount() {
  try {
    const h = await statsApi.health()
    totalCount.value = h.total
  } catch {}
}

function showToast(msg, type = 'success') {
  toast.value = { show: true, msg, type }
  setTimeout(() => { toast.value.show = false }, 3000)
}

onMounted(loadCount)
</script>

<style scoped>
.io-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
.desc { font-size: 13px; color: var(--muted); margin-bottom: 16px; line-height: 1.6; }
.upload-zone {
  border: 2px dashed var(--border);
  border-radius: 8px;
  padding: 32px;
  text-align: center;
  cursor: pointer;
  margin-bottom: 16px;
  transition: all .2s;
  font-size: 13px;
}
.upload-zone:hover, .upload-zone.dragover {
  border-color: var(--accent);
  background: rgba(249,115,22,.05);
}
.upload-hint { color: var(--muted); }
.file-selected { color: var(--accent3); font-weight: 600; }
.import-opts, .export-opts { margin-bottom: 16px; }
.import-mode { color: var(--accent3); font-size: 13px; font-weight: 600; }
.checkbox-label { display: flex; align-items: center; gap: 8px; font-size: 13px; cursor: pointer; }
.checkbox-label input { width: 14px; height: 14px; accent-color: var(--accent); }
.export-info { margin-bottom: 16px; }
.export-info .stat-card { max-width: 160px; }
.result-box {
  margin-top: 16px;
  padding: 12px 16px;
  border-radius: 8px;
  font-size: 13px;
}
.result-box.ok { background: rgba(16,185,129,.1); border: 1px solid rgba(16,185,129,.3); color: var(--accent3); }
.result-box.err { background: rgba(239,68,68,.1); border: 1px solid rgba(239,68,68,.3); color: var(--red); }
.errors { margin-top: 8px; font-size: 11px; opacity: .8; }
.code-block {
  background: var(--surface2);
  border: 1px solid var(--border);
  border-radius: 8px;
  padding: 16px;
  font-family: 'Space Mono', monospace;
  font-size: 11px;
  white-space: pre;
  overflow-x: auto;
  color: var(--text);
  line-height: 1.7;
}
@media (max-width: 900px) {
  .io-grid { grid-template-columns: 1fr; }
}
</style>
