<template>
  <div class="page">
    <div class="page-title">👤 个人中心</div>

    <div v-if="loading" class="empty">加载中…</div>

    <template v-else>
      <!-- 资料卡 -->
      <div class="profile-grid">
        <div class="panel">
          <div class="panel-title">基本资料</div>

          <div class="avatar-preview">
            <span class="big-avatar">{{ form.avatar }}</span>
            <div>
              <div class="pf-username">{{ me.username }}</div>
              <div class="pf-role">
                <span :class="['role-tag', me.role === 'admin' ? 'admin' : 'user']">
                  {{ me.role === 'admin' ? '管理员' : '普通用户' }}
                </span>
                <span class="pf-join">注册于 {{ formatDate(me.created_at) }}</span>
              </div>
            </div>
          </div>

          <div class="form-group">
            <label>选择头像</label>
            <div class="emoji-picker">
              <span v-for="e in AVATARS" :key="e"
                    :class="['emoji-opt', { active: form.avatar === e }]"
                    @click="form.avatar = e">{{ e }}</span>
            </div>
          </div>

          <div class="form-group">
            <label>邮箱</label>
            <input v-model="form.email" type="email" placeholder="your@email.com" />
          </div>

          <div class="form-group">
            <label>个人简介</label>
            <textarea v-model="form.bio" rows="3" placeholder="介绍一下自己…" maxlength="500"></textarea>
          </div>

          <button class="btn btn-primary" :disabled="savingProfile" @click="saveProfile">
            {{ savingProfile ? '保存中…' : '保存资料' }}
          </button>
          <span v-if="profileMsg" class="inline-msg" :class="profileMsgType">{{ profileMsg }}</span>
        </div>

        <!-- 统计 + 改密码 -->
        <div class="profile-side">
          <div class="panel">
            <div class="panel-title">我的数据</div>
            <div class="mini-stats">
              <div class="mini-stat">
                <div class="ms-num">{{ me.post_count ?? 0 }}</div>
                <div class="ms-label">发帖</div>
              </div>
              <div class="mini-stat">
                <div class="ms-num">{{ me.comment_count ?? 0 }}</div>
                <div class="ms-label">回复</div>
              </div>
            </div>
            <router-link to="/my-posts" class="btn btn-outline" style="width:100%;text-align:center;text-decoration:none;display:block;margin-top:12px">
              查看我的帖子 →
            </router-link>
          </div>

          <div class="panel">
            <div class="panel-title">我的收藏</div>
            <div class="group-tabs">
              <button :class="{ active: activeGroup === '' }" @click="setGroup('')">全部</button>
              <button :class="{ active: activeGroup === 'ungrouped' }" @click="setGroup('ungrouped')">未分组</button>
              <button v-for="g in favoriteGroups" :key="g.id" :class="{ active: activeGroup === g.id }" @click="setGroup(g.id)">
                {{ g.name }} {{ g.favorite_count ? `(${g.favorite_count})` : '' }}
              </button>
            </div>
            <div class="new-group">
              <input v-model="newGroupName" placeholder="新收藏夹" @keyup.enter="createGroup" />
              <button class="btn btn-outline" @click="createGroup">创建</button>
            </div>
            <div v-if="favorites.length === 0" class="fav-empty">暂无收藏记录</div>
            <div v-else class="fav-list">
              <div v-for="r in favorites.slice(0, 8)" :key="r.id" class="fav-item">
                <div class="fav-main">
                  <router-link :to="`/records/${r.id}`" class="fav-title">{{ r.summary || r.job_position || '避雷记录' }}</router-link>
                  <div class="fav-meta">{{ r.state || '—' }} · 严重度 {{ r.severity || '?' }} · {{ r.favorite_group_name || '未分组' }}</div>
                  <select v-model="r.favorite_group_id" class="group-select" @change="moveFavorite(r)">
                    <option :value="null">未分组</option>
                    <option v-for="g in favoriteGroups" :key="g.id" :value="g.id">{{ g.name }}</option>
                  </select>
                </div>
                <button class="fav-remove" @click="removeFavorite(r)">移除</button>
              </div>
            </div>
            <router-link to="/table" class="btn btn-outline" style="width:100%;text-align:center;text-decoration:none;display:block;margin-top:12px">
              继续浏览记录 →
            </router-link>
          </div>

          <div class="panel">
            <div class="panel-title">通知中心</div>
            <div v-if="notifications.length === 0" class="fav-empty">暂无通知</div>
            <div v-else class="notice-list">
              <div v-for="n in notifications.slice(0, 6)" :key="n.id" class="notice-item" :class="{ unread: !n.is_read }">
                <router-link v-if="n.target_type === 'record'" :to="`/records/${n.target_id}`" class="notice-title">{{ n.title }}</router-link>
                <a v-else-if="n.link_url && n.link_url.startsWith('http')" :href="n.link_url" target="_blank" rel="noopener" class="notice-title">{{ n.title }}</a>
                <router-link v-else-if="n.link_url" :to="n.link_url" class="notice-title">{{ n.title }}</router-link>
                <div v-else class="notice-title">{{ n.title }}</div>
                <div class="notice-body">{{ n.body }}</div>
                <div class="fav-meta">{{ formatDate(n.created_at) }}</div>
              </div>
            </div>
            <button v-if="notifications.length" class="btn btn-outline" style="width:100%;margin-top:12px" @click="markNotificationsRead">全部已读</button>
          </div>

          <div class="panel">
            <div class="panel-title">修改密码</div>
            <div class="form-group">
              <label>当前密码</label>
              <input v-model="pw.old_password" type="password" placeholder="输入当前密码" />
            </div>
            <div class="form-group">
              <label>新密码 <small>(至少 6 位)</small></label>
              <input v-model="pw.new_password" type="password" placeholder="输入新密码" />
            </div>
            <button class="btn btn-primary" :disabled="savingPw" @click="changePassword">
              {{ savingPw ? '修改中…' : '修改密码' }}
            </button>
            <span v-if="pwMsg" class="inline-msg" :class="pwMsgType">{{ pwMsg }}</span>
          </div>
        </div>
      </div>
    </template>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { authApi, recordsApi, forumApi } from '../api/index.js'
import { useAuthStore } from '../stores/auth.js'

const auth = useAuthStore()

const AVATARS = ['🐱','🐶','🦊','🐼','🐨','🐯','🦁','🐸','🐙','🦄','🐧','🦉','🐢','🐝','🦋','🌟','🔥','⚡','🌈','🎯','🛡️','👻','🤖','🎨']

const me = ref({})
const loading = ref(true)
const form = ref({ avatar: '🐱', email: '', bio: '' })

const savingProfile = ref(false)
const profileMsg = ref('')
const profileMsgType = ref('success')

const pw = ref({ old_password: '', new_password: '' })
const savingPw = ref(false)
const pwMsg = ref('')
const pwMsgType = ref('success')
const favorites = ref([])
const favoriteGroups = ref([])
const activeGroup = ref('')
const newGroupName = ref('')
const notifications = ref([])

function formatDate(iso) {
  if (!iso) return ''
  return new Date(iso).toLocaleDateString('zh-CN')
}

async function load() {
  loading.value = true
  try {
    me.value = await authApi.me()
    await loadFavoriteData()
    await loadNotifications()
    form.value = {
      avatar: me.value.avatar || '🐱',
      email: me.value.email || '',
      bio: me.value.bio || '',
    }
  } catch (e) {
    console.error(e)
  } finally {
    loading.value = false
  }
}

async function loadFavoriteData() {
  try {
    favoriteGroups.value = await authApi.favoriteGroups()
    const params = activeGroup.value ? { group_id: activeGroup.value } : undefined
    const fav = await authApi.favorites(params)
    favorites.value = fav.favorites || []
  } catch {
    favoriteGroups.value = []
    favorites.value = []
  }
}

async function setGroup(groupId) {
  activeGroup.value = groupId
  await loadFavoriteData()
}

async function createGroup() {
  const name = newGroupName.value.trim()
  if (!name) return
  await authApi.createFavoriteGroup({ name, sort_order: favoriteGroups.value.length + 1 })
  newGroupName.value = ''
  await loadFavoriteData()
}

async function moveFavorite(record) {
  await authApi.moveFavorite(record.favorite_id, { group_id: record.favorite_group_id || null })
  await loadFavoriteData()
}

async function removeFavorite(record) {
  try {
    await recordsApi.toggleFavorite(record.id)
    await loadFavoriteData()
  } catch (e) {
    console.error(e)
  }
}

async function loadNotifications() {
  try {
    const res = await forumApi.notifications()
    notifications.value = res.notifications || []
  } catch {
    notifications.value = []
  }
}

async function markNotificationsRead() {
  await forumApi.markNotificationsRead()
  await loadNotifications()
}

async function saveProfile() {
  savingProfile.value = true
  profileMsg.value = ''
  try {
    const updated = await authApi.updateMe({
      avatar: form.value.avatar,
      email: form.value.email || null,
      bio: form.value.bio,
    })
    me.value = { ...me.value, ...updated }
    auth.setUser({ ...auth.user, avatar: updated.avatar, email: updated.email })
    profileMsgType.value = 'success'
    profileMsg.value = '✓ 已保存'
  } catch (e) {
    profileMsgType.value = 'error'
    profileMsg.value = e.message
  } finally {
    savingProfile.value = false
    setTimeout(() => profileMsg.value = '', 3000)
  }
}

async function changePassword() {
  if (!pw.value.old_password || !pw.value.new_password) {
    pwMsgType.value = 'error'; pwMsg.value = '请填写完整'; return
  }
  if (pw.value.new_password.length < 6) {
    pwMsgType.value = 'error'; pwMsg.value = '新密码至少 6 位'; return
  }
  savingPw.value = true
  pwMsg.value = ''
  try {
    await authApi.changePassword(pw.value)
    pw.value = { old_password: '', new_password: '' }
    pwMsgType.value = 'success'
    pwMsg.value = '✓ 密码已修改'
  } catch (e) {
    pwMsgType.value = 'error'
    pwMsg.value = e.message
  } finally {
    savingPw.value = false
    setTimeout(() => pwMsg.value = '', 3000)
  }
}

onMounted(load)
</script>

<style scoped>
.profile-grid { display: grid; grid-template-columns: 1fr 320px; gap: 16px; }
.profile-side { display: flex; flex-direction: column; gap: 16px; }

.avatar-preview { display: flex; align-items: center; gap: 16px; margin-bottom: 20px; padding-bottom: 16px; border-bottom: 1px solid var(--border); }
.big-avatar { font-size: 52px; }
.pf-username { font-size: 20px; font-weight: 700; }
.pf-role { display: flex; align-items: center; gap: 10px; margin-top: 6px; }
.role-tag { font-size: 11px; padding: 2px 8px; border-radius: 99px; font-weight: 600; }
.role-tag.admin { background: var(--accent); color: #fff; }
.role-tag.user { background: var(--surface2); color: var(--muted); }
.pf-join { font-size: 12px; color: var(--muted); }

.emoji-picker { display: flex; flex-wrap: wrap; gap: 6px; }
.emoji-opt { font-size: 24px; padding: 4px; border-radius: 8px; cursor: pointer; border: 2px solid transparent; transition: all .15s; }
.emoji-opt:hover { background: var(--surface2); }
.emoji-opt.active { border-color: var(--accent); background: rgba(249,115,22,.12); }

.form-group textarea { width: 100%; resize: vertical; }
.form-group input { width: 100%; }

.mini-stats { display: flex; gap: 12px; }
.mini-stat { flex: 1; text-align: center; background: var(--surface2); border-radius: 8px; padding: 14px; }
.ms-num { font-family: 'Space Mono', monospace; font-size: 26px; font-weight: 700; color: var(--accent); }
.ms-label { font-size: 11px; color: var(--muted); margin-top: 2px; }
.fav-empty { color: var(--muted); font-size: 13px; padding: 12px 0; }
.fav-list { display: flex; flex-direction: column; gap: 8px; }
.fav-item { display: flex; gap: 8px; align-items: flex-start; border: 1px solid var(--border); border-radius: 8px; padding: 8px; }
.fav-main { flex: 1; min-width: 0; }
.fav-title { font-size: 12px; line-height: 1.5; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; }
.fav-title { color: var(--text); text-decoration: none; }
.fav-title:hover { color: var(--accent2); }
.fav-meta { color: var(--muted); font-size: 11px; margin-top: 4px; }
.fav-remove { background: transparent; border: 0; color: var(--red); cursor: pointer; font-size: 11px; font-family: inherit; }
.group-tabs { display: flex; gap: 6px; flex-wrap: wrap; margin-bottom: 10px; }
.group-tabs button { border: 1px solid var(--border); background: transparent; color: var(--muted); border-radius: 6px; padding: 4px 8px; cursor: pointer; font-size: 11px; font-family: inherit; }
.group-tabs button.active { color: var(--accent); border-color: var(--accent); background: rgba(249,115,22,.1); }
.new-group { display: flex; gap: 6px; margin-bottom: 10px; }
.new-group input { min-width: 0; flex: 1; }
.group-select { margin-top: 6px; width: 100%; font-size: 11px; padding: 5px 8px; }
.notice-list { display: flex; flex-direction: column; gap: 8px; }
.notice-item { border: 1px solid var(--border); border-radius: 8px; padding: 8px; }
.notice-item.unread { border-color: var(--accent2); background: rgba(59,130,246,.08); }
.notice-title { color: var(--text); text-decoration: none; font-size: 12px; font-weight: 700; }
.notice-body { color: var(--muted); font-size: 12px; line-height: 1.5; margin-top: 4px; }

.inline-msg { margin-left: 12px; font-size: 13px; }
.inline-msg.success { color: var(--accent3); }
.inline-msg.error { color: var(--red); }

.empty { text-align: center; padding: 60px; color: var(--muted); }

@media (max-width: 768px) {
  .profile-grid { grid-template-columns: 1fr; }
}
</style>
