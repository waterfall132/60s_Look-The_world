<template>
  <div class="page">
    <div class="auth-card">
      <h2>登录</h2>
      <div class="sub">登录后即可发帖、回复、点赞</div>
      <div class="form-group">
        <label>用户名</label>
        <input v-model="username" @keyup.enter="doLogin" placeholder="输入用户名" />
      </div>
      <div class="form-group">
        <label>密码</label>
        <input v-model="password" type="password" @keyup.enter="doLogin" placeholder="输入密码" />
      </div>
      <button class="btn btn-primary" style="width:100%" :disabled="loading" @click="doLogin">
        {{ loading ? '登录中…' : '登录' }}
      </button>
      <div v-if="error" class="form-error">{{ error }}</div>
      <div class="form-foot">
        还没有账号？<router-link to="/register">立即注册</router-link>
        <span style="margin:0 8px;color:var(--border)">|</span>
        <router-link to="/forgot-password">忘记密码？</router-link>
      </div>
      <div class="admin-hint">管理员默认账号：admin / admin123</div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import { useAuthStore } from '../stores/auth.js'

const auth = useAuthStore()
const router = useRouter()
const route = useRoute()
const username = ref('')
const password = ref('')
const loading = ref(false)
const error = ref('')

async function doLogin() {
  if (!username.value || !password.value) { error.value = '请填写用户名和密码'; return }
  loading.value = true
  error.value = ''
  try {
    await auth.login(username.value, password.value)
    const redirect = route.query.redirect || '/forum'
    router.push(redirect)
  } catch (e) {
    error.value = e.message
  } finally {
    loading.value = false
  }
}
</script>

<style scoped>
.admin-hint { margin-top: 16px; padding: 8px 12px; background: var(--surface2); border-radius: 6px; font-size: 11px; color: var(--muted); text-align: center; }
</style>
