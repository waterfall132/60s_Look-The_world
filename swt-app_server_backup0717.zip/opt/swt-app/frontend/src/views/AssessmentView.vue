<template>
  <div class="page">
    <div class="assessment-head">
      <div>
        <div class="page-title">雇主地点评估</div>
        <div class="sub">输入雇主地址，评估生活便利、SSN 办理、交通和避雷风险。</div>
      </div>
      <div class="quota-card">
        <div>会员月剩余：{{ quota.monthly_remaining ?? '不限' }}</div>
        <div>付费次数：{{ quota.credits ?? 0 }}</div>
      </div>
    </div>

    <div v-if="!auth.isLoggedIn" class="vip-banner">
      <span class="vb-icon">👑</span>
      <div>
        <div class="vb-title">付费/VIP 功能</div>
        <div class="vb-desc">登录后，会员可按月使用；非会员需购买或由管理员发放评估次数。</div>
      </div>
      <router-link to="/login" class="btn btn-primary" style="text-decoration:none">登录</router-link>
    </div>

    <div class="assessment-grid">
      <div class="panel">
        <div class="panel-title">评估信息</div>
        <div class="form-group">
          <label>雇主名称</label>
          <input v-model="form.employer_name" placeholder="例如：Dairy Queen / Water Park" />
        </div>
        <div class="form-group">
          <label>雇主地址或地点</label>
          <input v-model="form.address" placeholder="街道地址、城市州，或景点名称" />
        </div>
        <div class="form-row">
          <div class="form-group">
            <label>城市</label>
            <input v-model="form.city" placeholder="可选" />
          </div>
          <div class="form-group">
            <label>州缩写</label>
            <input v-model="form.state" placeholder="TN" maxlength="2" style="text-transform:uppercase" />
          </div>
        </div>
        <div class="form-group">
          <label>住宿地址</label>
          <input v-model="form.housing_address" placeholder="可选，后续可用于通勤增强分析" />
        </div>
        <div class="form-row">
          <div class="form-group">
            <label>时薪</label>
            <input v-model.number="form.hourly_wage" type="number" min="0" step="0.25" placeholder="例如 15" />
          </div>
          <div class="form-group">
            <label>每周工时</label>
            <input v-model.number="form.hours_per_week" type="number" min="0" step="1" placeholder="例如 35" />
          </div>
        </div>
        <label class="check-row">
          <input v-model="form.has_car" type="checkbox" />
          <span>我有车或确定有人长期接送</span>
        </label>
        <button class="btn btn-primary" :disabled="loading || !auth.isLoggedIn" @click="runAssessment">
          {{ loading ? '评估中…' : '开始评估' }}
        </button>
        <div v-if="error" class="form-error">{{ error }}</div>
      </div>

      <div v-if="result" class="panel result-panel">
        <div class="score-block">
          <div class="score">{{ result.score.overall }}</div>
          <div>
            <div class="decision">{{ result.score.decision }}</div>
            <div class="sub">{{ result.summary.headline }}</div>
          </div>
        </div>
        <div class="score-grid">
          <div v-for="(v, k) in result.score.parts" :key="k" class="score-item">
            <span>{{ partLabel(k) }}</span><b>{{ v }}</b>
          </div>
        </div>
        <div class="section">
          <div class="section-title">指导建议</div>
          <p>{{ result.summary.advice }}</p>
        </div>
        <div class="two-col">
          <div>
            <div class="section-title">优点</div>
            <ul><li v-for="x in result.summary.positives" :key="x">{{ x }}</li></ul>
          </div>
          <div>
            <div class="section-title">风险</div>
            <ul><li v-for="x in result.summary.warnings" :key="x">{{ x }}</li></ul>
          </div>
        </div>
      </div>
    </div>

    <div v-if="result" class="report-grid">
      <div class="panel">
        <div class="panel-title">最近 SSA Office</div>
        <div v-for="o in result.ssa_offices" :key="o.name" class="poi-row">
          <div>
            <b>{{ o.name }}</b>
            <div class="muted">{{ o.address }}</div>
          </div>
          <span>{{ o.distance_miles }} mi</span>
        </div>
      </div>

      <div class="panel">
        <div class="panel-title">周边设施</div>
        <div v-if="!result.provider.poi_ok" class="muted">OSM 周边搜索暂不可用，已使用本地数据完成部分评估。</div>
        <template v-for="key in poiOrder" :key="key">
          <div v-if="result.nearby.categories[key]?.length" class="poi-section">
            <div class="section-title">{{ poiLabel(key) }}</div>
            <div v-for="p in result.nearby.categories[key].slice(0, 4)" :key="p.name + p.distance_miles" class="poi-row">
              <span>{{ p.name }}</span>
              <span>{{ p.distance_miles }} mi</span>
            </div>
          </div>
        </template>
      </div>

      <div class="panel">
        <div class="panel-title">避雷风险</div>
        <div class="risk-grid">
          <div><span>所在州</span><b>{{ result.risk.state || '—' }}</b></div>
          <div><span>记录数</span><b>{{ result.risk.total }}</b></div>
          <div><span>高严重度</span><b>{{ result.risk.high_severity }}</b></div>
          <div><span>已核验</span><b>{{ result.risk.verified }}</b></div>
        </div>
        <router-link :to="{ path: '/table', query: { state: result.risk.state } }" class="btn btn-outline" style="display:block;text-align:center;text-decoration:none;margin-top:12px">
          查看该州避雷记录
        </router-link>
      </div>
    </div>
  </div>
</template>

<script setup>
import { onMounted, reactive, ref } from 'vue'
import { assessmentApi } from '../api/index.js'
import { useAuthStore } from '../stores/auth.js'

const auth = useAuthStore()
const quota = ref({})
const loading = ref(false)
const error = ref('')
const result = ref(null)
const form = reactive({
  employer_name: '',
  address: '',
  city: '',
  state: '',
  housing_address: '',
  has_car: false,
  hourly_wage: null,
  hours_per_week: null,
})

const poiOrder = ['grocery', 'bank', 'convenience', 'pharmacy', 'medical', 'transit']
const partNames = {
  life: '生活便利',
  ssn: 'SSN 办理',
  transport: '交通',
  risk: '避雷风险',
  wage_hours: '工资工时',
}
const poiNames = {
  grocery: '超市/商场',
  bank: '银行/ATM',
  convenience: '便利店',
  pharmacy: '药店',
  medical: '医疗',
  transit: '公共交通',
}

function partLabel(k) { return partNames[k] || k }
function poiLabel(k) { return poiNames[k] || k }

async function loadQuota() {
  if (!auth.isLoggedIn) return
  quota.value = await assessmentApi.quota()
}

async function runAssessment() {
  error.value = ''
  result.value = null
  loading.value = true
  try {
    result.value = await assessmentApi.employer({
      ...form,
      state: (form.state || '').toUpperCase(),
    })
    quota.value = result.value.quota
  } catch (e) {
    error.value = e.message
  } finally {
    loading.value = false
  }
}

onMounted(loadQuota)
</script>

<style scoped>
.assessment-head { display: flex; justify-content: space-between; gap: 16px; align-items: flex-start; margin-bottom: 16px; }
.sub, .muted { color: var(--muted); font-size: 13px; line-height: 1.6; }
.quota-card { border: 1px solid var(--border); border-radius: 8px; padding: 10px 12px; color: var(--muted); font-size: 12px; min-width: 180px; }
.assessment-grid { display: grid; grid-template-columns: 420px 1fr; gap: 16px; align-items: start; }
.form-row { display: grid; grid-template-columns: 1fr 110px; gap: 10px; }
.check-row { display: flex; align-items: center; gap: 8px; font-size: 13px; margin-bottom: 16px; }
.score-block { display: flex; gap: 16px; align-items: center; margin-bottom: 16px; }
.score { width: 88px; height: 88px; border-radius: 50%; background: var(--accent); color: #fff; display: flex; align-items: center; justify-content: center; font-family: 'Space Mono', monospace; font-size: 34px; font-weight: 700; }
.decision { font-size: 24px; font-weight: 800; margin-bottom: 6px; }
.score-grid { display: grid; grid-template-columns: repeat(5, 1fr); gap: 8px; margin-bottom: 16px; }
.score-item { background: var(--surface2); border-radius: 8px; padding: 10px; }
.score-item span { color: var(--muted); font-size: 11px; display: block; }
.score-item b { color: var(--accent); font-family: 'Space Mono', monospace; font-size: 20px; }
.section { border-top: 1px solid var(--border); padding-top: 14px; margin-top: 14px; }
.section-title { font-size: 12px; color: var(--text); font-weight: 700; margin-bottom: 8px; }
.two-col { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
ul { padding-left: 18px; color: var(--muted); font-size: 13px; line-height: 1.8; }
.report-grid { display: grid; grid-template-columns: 1fr 1fr 320px; gap: 16px; margin-top: 16px; align-items: start; }
.poi-row { display: flex; justify-content: space-between; gap: 12px; border-top: 1px solid var(--border); padding: 9px 0; font-size: 13px; }
.poi-row:first-child { border-top: 0; }
.poi-section { margin-top: 12px; }
.risk-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; }
.risk-grid div { background: var(--surface2); border-radius: 8px; padding: 10px; }
.risk-grid span { display: block; color: var(--muted); font-size: 11px; }
.risk-grid b { color: var(--accent); font-family: 'Space Mono', monospace; font-size: 20px; }
@media (max-width: 980px) {
  .assessment-head, .assessment-grid, .report-grid, .two-col { grid-template-columns: 1fr; display: grid; }
  .score-grid { grid-template-columns: repeat(2, 1fr); }
}
</style>
