<template>
  <div class="page">
    <div class="admin-header">
      <div>
        <h2 class="page-title" style="margin:0">⚙️ 后台管理</h2>
        <p style="font-size:12px;color:var(--muted);margin-top:4px">用户 · 板块 · 帖子 · 避雷数据 全面管理</p>
      </div>
    </div>

    <!-- Tabs -->
    <div class="admin-tabs">
      <button v-for="t in tabs" :key="t.key" :class="{ active: tab === t.key }" @click="switchTab(t.key)">
        {{ t.icon }} {{ t.label }}
      </button>
    </div>

    <!-- ═══════════ 概览 ═══════════ -->
    <div v-if="tab === 'overview'" class="tab-pane">
      <div class="stat-grid" style="grid-template-columns:repeat(8,1fr)">
        <div class="stat-card"><div class="stat-num">{{ ov.users ?? '—' }}</div><div class="stat-label">用户</div></div>
        <div class="stat-card"><div class="stat-num">{{ ov.posts ?? '—' }}</div><div class="stat-label">帖子</div></div>
        <div class="stat-card"><div class="stat-num">{{ ov.comments ?? '—' }}</div><div class="stat-label">回复</div></div>
        <div class="stat-card"><div class="stat-num">{{ ov.categories ?? '—' }}</div><div class="stat-label">板块</div></div>
        <div class="stat-card"><div class="stat-num">{{ ov.records ?? '—' }}</div><div class="stat-label">避雷记录</div></div>
        <div class="stat-card"><div class="stat-num">{{ ov.open_reports ?? '—' }}</div><div class="stat-label">待处理举报</div></div>
        <div class="stat-card"><div class="stat-num">{{ ov.open_record_feedback ?? '—' }}</div><div class="stat-label">数据反馈</div></div>
        <div class="stat-card"><div class="stat-num">{{ ov.active_announcements ?? '—' }}</div><div class="stat-label">有效通知</div></div>
      </div>
      <div class="panel">
        <div class="panel-title">快捷操作</div>
        <div style="display:flex;gap:10px;flex-wrap:wrap">
          <button class="btn btn-outline" @click="switchTab('users')">管理用户</button>
          <button class="btn btn-outline" @click="switchTab('categories')">管理板块</button>
          <button class="btn btn-outline" @click="switchTab('posts')">审核帖子</button>
          <button class="btn btn-outline" @click="switchTab('announcements')">发布通知</button>
          <button class="btn btn-outline" @click="switchTab('governance')">治理中心</button>
          <button class="btn btn-outline" @click="switchTab('records')">编辑避雷数据</button>
        </div>
      </div>
    </div>

    <!-- ═══════════ 通知管理 ═══════════ -->
    <div v-if="tab === 'announcements'" class="tab-pane">
      <div class="ann-grid">
        <div class="panel">
          <div class="panel-title">{{ announcementForm.id ? '编辑通知' : '新建通知' }}</div>
          <div class="form-group">
            <label>标题</label>
            <input v-model="announcementForm.title" placeholder="例如：系统维护通知" />
          </div>
          <div class="form-group">
            <label>内容</label>
            <textarea v-model="announcementForm.body" rows="5" placeholder="向所有用户展示的通知内容"></textarea>
          </div>
          <div class="form-grid">
            <div class="form-group">
              <label>级别</label>
              <select v-model="announcementForm.level">
                <option value="info">普通</option>
                <option value="success">成功</option>
                <option value="warning">警告</option>
                <option value="danger">重要</option>
              </select>
            </div>
            <div class="form-group">
              <label>链接</label>
              <input v-model="announcementForm.link_url" placeholder="/assessment 或 https://..." />
            </div>
            <div class="form-group">
              <label>开始时间</label>
              <input v-model="announcementForm.starts_at" type="datetime-local" />
            </div>
            <div class="form-group">
              <label>结束时间</label>
              <input v-model="announcementForm.ends_at" type="datetime-local" />
            </div>
          </div>
          <div class="ann-checks">
            <label class="reason-check"><input v-model="announcementForm.is_active" type="checkbox" /><span>启用</span></label>
            <label class="reason-check"><input v-model="announcementForm.is_pinned" type="checkbox" /><span>置顶</span></label>
          </div>
          <div class="modal-footer">
            <button class="btn btn-outline" @click="resetAnnouncementForm">清空</button>
            <button class="btn btn-primary" :disabled="announcementSaving" @click="saveAnnouncement">
              {{ announcementSaving ? '保存中…' : (announcementForm.id ? '更新通知' : '发布通知') }}
            </button>
          </div>
        </div>

        <div class="panel">
          <div class="panel-title">通知列表</div>
          <div class="filter-bar" style="margin-bottom:10px">
            <select v-model="announcementStatus" @change="loadAnnouncements">
              <option value="all">全部</option>
              <option value="active">启用中</option>
              <option value="inactive">已下线</option>
            </select>
            <span class="count-hint">{{ announcements.length }} 条</span>
          </div>
          <div v-if="!announcements.length" class="empty" style="padding:28px">暂无通知</div>
          <div v-else class="ann-list">
            <div v-for="a in announcements" :key="a.id" :class="['ann-card', a.level, { inactive: !a.is_active }]">
              <div class="ann-title">
                <span v-if="a.is_pinned" class="tag-pin">置顶</span>
                <b>{{ a.title }}</b>
              </div>
              <div class="ann-body">{{ a.body || '—' }}</div>
              <div class="ann-meta">
                {{ a.is_active ? '启用' : '下线' }} · {{ levelLabel(a.level) }} · 更新 {{ formatDate(a.updated_at) }}
              </div>
              <div class="row-actions">
                <button class="btn-mini" @click="editAnnouncement(a)">编辑</button>
                <button class="btn-mini" @click="toggleAnnouncement(a)">{{ a.is_active ? '下线' : '启用' }}</button>
                <button class="btn-mini del" @click="deleteAnnouncement(a)">删除</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- ═══════════ AI 配置 ═══════════ -->
    <div v-if="tab === 'ai'" class="tab-pane">
      <div class="panel ai-config-panel">
        <div class="panel-title">AI API 配置</div>
        <p class="config-desc">所有 AI 功能统一读取这里的配置。支持 OpenAI-compatible 的第三方服务商，API Key 只会以掩码展示。</p>

        <div class="form-grid">
          <div class="form-group">
            <label>启用 AI 功能</label>
            <label class="reason-check">
              <input v-model="aiForm.enabled" type="checkbox" />
              <span>启用第三阶段 AI 总结</span>
            </label>
          </div>
          <div class="form-group">
            <label>服务商</label>
            <select v-model="aiForm.provider" @change="applyProviderPreset">
              <option value="openai_compatible">OpenAI Compatible / 自定义</option>
              <option value="openai">OpenAI</option>
              <option value="deepseek">DeepSeek</option>
              <option value="moonshot">Moonshot</option>
              <option value="qwen">通义千问 DashScope Compatible</option>
            </select>
          </div>
          <div class="form-group full">
            <label>Base URL</label>
            <input v-model="aiForm.base_url" placeholder="https://api.openai.com/v1" />
          </div>
          <div class="form-group">
            <label>模型名</label>
            <input v-model="aiForm.model" placeholder="gpt-4o-mini / deepseek-chat" />
          </div>
          <div class="form-group">
            <label>Temperature</label>
            <input v-model.number="aiForm.temperature" type="number" min="0" max="2" step="0.1" />
          </div>
          <div class="form-group full">
            <label>API Key</label>
            <input v-model="aiForm.api_key" type="password" :placeholder="aiKeyPlaceholder" autocomplete="new-password" />
            <div class="hint">留空表示不修改当前 Key；当前状态：{{ aiConfig.has_api_key ? aiConfig.api_key_masked : '未配置' }}</div>
          </div>
          <div class="form-group full">
            <label class="reason-check">
              <input v-model="aiForm.clear_api_key" type="checkbox" />
              <span>清空当前 API Key</span>
            </label>
          </div>
        </div>

        <div class="modal-footer">
          <button class="btn btn-outline" @click="loadAIConfig">重新载入</button>
          <button class="btn btn-outline" :disabled="aiTesting" @click="testAIConfig">
            {{ aiTesting ? '测试中…' : '测试连接' }}
          </button>
          <button class="btn btn-primary" :disabled="aiSaving" @click="saveAIConfig">
            {{ aiSaving ? '保存中…' : '保存 AI 配置' }}
          </button>
        </div>

        <div v-if="aiTestResult" :class="['ai-test-result', aiTestResult.ok ? 'ok' : 'err']">
          <div><b>{{ aiTestResult.ok ? '测试成功' : '测试失败' }}</b></div>
          <div>模型：{{ aiTestResult.model || aiForm.model }}</div>
          <div>耗时：{{ aiTestResult.latency_ms ?? '—' }} ms</div>
          <div v-if="aiTestResult.content_preview">响应：{{ aiTestResult.content_preview }}</div>
          <div v-if="aiTestResult.error">错误：{{ aiTestResult.error }}</div>
        </div>
      </div>
    </div>

    <!-- ═══════════ 用户管理 ═══════════ -->
    <div v-if="tab === 'users'" class="tab-pane">
      <div class="filter-bar" style="margin-bottom:14px">
        <input v-model="userSearch" placeholder="🔍 搜索用户名…" style="width:220px" @input="onUserSearch" />
        <span class="count-hint">共 {{ userTotal }} 个用户</span>
      </div>
      <div class="table-wrap">
        <div v-if="usersLoading" class="empty">加载中…</div>
        <table v-else>
          <thead>
            <tr><th>用户</th><th>邮箱</th><th>角色</th><th>VIP</th><th>声望</th><th>评估次数</th><th>状态</th><th>发帖</th><th>注册时间</th><th style="width:250px">操作</th></tr>
          </thead>
          <tbody>
            <tr v-for="u in users" :key="u.id">
              <td><span style="font-size:16px">{{ u.avatar }}</span> <b>{{ u.username }}</b></td>
              <td style="font-size:11px;color:var(--muted)">{{ u.email || '—' }}</td>
              <td>
                <span :class="['role-tag', u.role === 'admin' ? 'admin' : 'user']">
                  {{ u.role === 'admin' ? '管理员' : '用户' }}
                </span>
              </td>
              <td>
                <span v-if="u.role==='admin' || u.is_vip" style="font-size:14px" title="VIP">👑</span>
                <span v-else style="color:var(--muted);font-size:11px">—</span>
              </td>
              <td style="font-family:'Space Mono',monospace;font-size:11px">{{ u.level }} / {{ u.reputation || 0 }}</td>
              <td style="font-family:'Space Mono',monospace;font-size:11px">
                {{ u.assessment_credits || 0 }} 次 / 月 {{ u.assessment_monthly_limit || 10 }}
              </td>
              <td>
                <span :class="['status-dot', u.is_active ? 'on' : 'off']"></span>
                {{ u.ban_until ? '已封禁' : (u.is_active ? '正常' : '已禁用') }}
              </td>
              <td style="font-family:'Space Mono',monospace">{{ u.post_count }}</td>
              <td style="font-size:11px;color:var(--muted)">{{ formatDate(u.created_at) }}</td>
              <td>
                <div class="row-actions">
                  <button v-if="u.role !== 'admin'" class="btn-mini" @click="setRole(u, 'admin')">设为管理员</button>
                  <button v-else class="btn-mini" @click="setRole(u, 'user')" :disabled="u.id === myId">降为用户</button>
                  <button v-if="u.role !== 'admin'" class="btn-mini" @click="toggleVip(u)">
                    {{ u.is_vip ? '取消VIP' : '设为VIP' }}
                  </button>
                  <button class="btn-mini" @click="toggleActive(u)" :disabled="u.id === myId">
                    {{ u.is_active ? '禁用' : '启用' }}
                  </button>
                  <button class="btn-mini" @click="openResetPw(u)">改密</button>
                  <button class="btn-mini" @click="editAssessmentQuota(u)">评估额度</button>
                  <button class="btn-mini del" @click="deleteUser(u)" :disabled="u.id === myId">删除</button>
                </div>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
      <div v-if="userPages > 1" class="pagination">
        <button class="btn btn-outline" :disabled="userPage<=1" @click="userPage--; loadUsers()">← 上一页</button>
        <span style="font-size:12px;color:var(--muted)">{{ userPage }} / {{ userPages }}</span>
        <button class="btn btn-outline" :disabled="userPage>=userPages" @click="userPage++; loadUsers()">下一页 →</button>
      </div>
    </div>

    <!-- ═══════════ 板块管理 ═══════════ -->
    <div v-if="tab === 'categories'" class="tab-pane">
      <div class="admin-header" style="margin-bottom:14px">
        <span class="count-hint">共 {{ categories.length }} 个板块</span>
        <button class="btn btn-primary" @click="openCatModal()">+ 新建板块</button>
      </div>
      <div class="table-wrap">
        <table>
          <thead><tr><th style="width:50px">图标</th><th>名称</th><th>slug</th><th>描述</th><th>帖子数</th><th>排序</th><th style="width:120px">操作</th></tr></thead>
          <tbody>
            <tr v-for="c in categories" :key="c.id">
              <td style="font-size:20px">{{ c.icon }}</td>
              <td><b>{{ c.name }}</b></td>
              <td style="font-family:'Space Mono',monospace;font-size:11px;color:var(--accent2)">{{ c.slug }}</td>
              <td style="font-size:11px;color:var(--muted);max-width:200px">{{ c.description || '—' }}</td>
              <td style="font-family:'Space Mono',monospace">{{ c.post_count }}</td>
              <td>{{ c.sort_order }}</td>
              <td>
                <div class="row-actions">
                  <button class="btn-mini" @click="openCatModal(c)">编辑</button>
                  <button class="btn-mini del" @click="deleteCategory(c)">删除</button>
                </div>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>

    <!-- ═══════════ 帖子审核 ═══════════ -->
    <div v-if="tab === 'posts'" class="tab-pane">
      <div class="filter-bar" style="margin-bottom:14px">
        <input v-model="postSearch" placeholder="🔍 搜索标题…" style="width:220px" @input="onPostSearch" />
        <span class="count-hint">共 {{ postTotal }} 个帖子</span>
      </div>
      <div class="table-wrap">
        <div v-if="postsLoading" class="empty">加载中…</div>
        <table v-else>
          <thead><tr><th>标题</th><th>板块</th><th>作者</th><th>浏览</th><th>回复</th><th>赞</th><th>状态</th><th style="width:180px">操作</th></tr></thead>
          <tbody>
            <tr v-for="p in posts" :key="p.id">
              <td>
                <a class="link-a" style="font-size:13px" @click="goPost(p.id)">{{ p.title }}</a>
              </td>
              <td style="font-size:11px;color:var(--accent2)">{{ p.category_name }}</td>
              <td style="font-size:12px">{{ p.author_avatar }} {{ p.author_name }}</td>
              <td style="font-family:'Space Mono',monospace;font-size:11px">{{ p.view_count }}</td>
              <td style="font-family:'Space Mono',monospace;font-size:11px">{{ p.comment_count }}</td>
              <td style="font-family:'Space Mono',monospace;font-size:11px">{{ p.like_count }}</td>
              <td>
                <span v-if="p.is_pinned" class="tag-pin">置顶</span>
                <span v-if="p.is_locked" class="tag-lock">锁定</span>
                <span v-if="!p.is_pinned && !p.is_locked" style="color:var(--muted);font-size:11px">—</span>
              </td>
              <td>
                <div class="row-actions">
                  <button class="btn-mini" @click="togglePin(p)">{{ p.is_pinned ? '取消置顶' : '置顶' }}</button>
                  <button class="btn-mini" @click="toggleLock(p)">{{ p.is_locked ? '解锁' : '锁定' }}</button>
                  <button class="btn-mini del" @click="deletePost(p)">删除</button>
                </div>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
      <div v-if="postPages > 1" class="pagination">
        <button class="btn btn-outline" :disabled="postPage<=1" @click="postPage--; loadPosts()">← 上一页</button>
        <span style="font-size:12px;color:var(--muted)">{{ postPage }} / {{ postPages }}</span>
        <button class="btn btn-outline" :disabled="postPage>=postPages" @click="postPage++; loadPosts()">下一页 →</button>
      </div>
    </div>

    <!-- ═══════════ 治理中心 ═══════════ -->
    <div v-if="tab === 'governance'" class="tab-pane">
      <div class="governance-grid">
        <div class="panel">
          <div class="panel-title">举报队列</div>
          <div class="filter-bar" style="margin-bottom:10px">
            <select v-model="reportStatus" @change="loadGovernance">
              <option value="open">待处理</option>
              <option value="resolved">已处理</option>
              <option value="dismissed">已驳回</option>
              <option value="all">全部</option>
            </select>
            <span class="count-hint">{{ reports.length }} 条</span>
          </div>
          <div v-if="!reports.length" class="empty" style="padding:28px">暂无举报</div>
          <div v-else class="mod-list">
            <div v-for="r in reports" :key="r.id" class="mod-card">
              <div><b>{{ r.target_type === 'post' ? '帖子' : '回复' }}</b> · {{ r.reason || '未填写原因' }}</div>
              <div class="mod-excerpt">{{ r.target_title }}：{{ r.target_excerpt }}</div>
              <div class="mod-meta">举报人 {{ r.reporter_name }} · {{ formatDate(r.created_at) }}</div>
              <div class="row-actions">
                <button class="btn-mini" @click="resolveReport(r, 'none', 'dismissed')">驳回</button>
                <button v-if="r.target_type==='post'" class="btn-mini" @click="resolveReport(r, 'hide_post')">隐藏帖</button>
                <button v-if="r.target_type==='post'" class="btn-mini del" @click="resolveReport(r, 'delete_post')">删帖</button>
                <button v-if="r.target_type==='comment'" class="btn-mini del" @click="resolveReport(r, 'delete_comment')">删回复</button>
              </div>
            </div>
          </div>
        </div>

        <div class="panel">
          <div class="panel-title">数据反馈</div>
          <div class="filter-bar" style="margin-bottom:10px">
            <select v-model="feedbackStatus" @change="loadGovernance">
              <option value="open">待处理</option>
              <option value="resolved">已处理</option>
              <option value="dismissed">已驳回</option>
              <option value="all">全部</option>
            </select>
            <span class="count-hint">{{ recordFeedbacks.length }} 条</span>
          </div>
          <div v-if="!recordFeedbacks.length" class="empty" style="padding:28px">暂无数据反馈</div>
          <div v-else class="mod-list">
            <div v-for="f in recordFeedbacks" :key="f.id" class="mod-card">
              <div><b>{{ f.reason || '数据反馈' }}</b> · {{ f.record_state || '—' }} · {{ f.record_job_position || '—' }}</div>
              <div class="mod-excerpt">{{ f.record_summary }}</div>
              <div class="mod-excerpt" v-if="f.detail">反馈：{{ f.detail }}</div>
              <div class="mod-meta">提交人 {{ f.username }} · {{ formatDate(f.created_at) }}</div>
              <div class="row-actions">
                <button class="btn-mini" @click="goRecordEdit(f.record_id)">编辑记录</button>
                <button class="btn-mini" @click="resolveRecordFeedback(f, 'dismissed')">驳回</button>
                <button class="btn-mini" @click="resolveRecordFeedback(f, 'resolved')">标记已处理</button>
              </div>
            </div>
          </div>
        </div>

        <div class="panel">
          <div class="panel-title">敏感词</div>
          <div class="filter-bar" style="margin-bottom:10px">
            <input v-model="sensitiveForm.word" placeholder="新增敏感词" />
            <button class="btn btn-primary" @click="addSensitiveWord">添加</button>
          </div>
          <div class="word-list">
            <div v-for="w in sensitiveWords" :key="w.id" class="word-chip">
              <span>{{ w.word }}</span>
              <button @click="toggleSensitiveWord(w)">{{ w.is_active ? '停用' : '启用' }}</button>
              <button @click="deleteSensitiveWord(w)">删除</button>
            </div>
          </div>
        </div>

        <div class="panel">
          <div class="panel-title">封禁记录</div>
          <div class="ban-form">
            <input v-model="banForm.user_id" placeholder="用户 ID" />
            <input v-model.number="banForm.days" type="number" min="1" placeholder="天数" />
            <input v-model="banForm.reason" placeholder="封禁原因" />
            <button class="btn btn-primary" @click="createBan">封禁</button>
          </div>
          <div v-if="!bans.length" class="empty" style="padding:28px">暂无封禁记录</div>
          <div v-else class="mod-list">
            <div v-for="b in bans" :key="b.id" class="mod-card">
              <div><b>{{ b.username }}</b> · {{ b.is_active ? '生效中' : '已解除' }}</div>
              <div class="mod-excerpt">{{ b.reason || '未填写原因' }}</div>
              <div class="mod-meta">至 {{ formatDate(b.ends_at) || '永久' }}</div>
              <button v-if="b.is_active" class="btn-mini" @click="liftBan(b)">解封</button>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- ═══════════ 避雷数据 (原有记录CRUD) ═══════════ -->
    <div v-if="tab === 'records'" class="tab-pane">
      <div class="admin-header" style="margin-bottom:14px">
        <div class="filter-bar">
          <input v-model="search" placeholder="🔍 搜索..." style="width:200px" @input="onSearch" />
          <select v-model="filterState" @change="loadRecords">
            <option value="">所有州</option>
            <option v-for="st in states" :key="st" :value="st">{{ st }}</option>
          </select>
          <select v-model="filterSev" @change="loadRecords">
            <option value="">所有严重度</option>
            <option v-for="s in [5,4,3,2,1]" :key="s" :value="s">严重度 {{ s }}</option>
          </select>
          <select v-model="filterReview" @change="loadRecords">
            <option value="">所有审核状态</option>
            <option value="pending">待审核</option>
            <option value="verified">已核验</option>
            <option value="needs_review">需复核</option>
            <option value="rejected">已驳回</option>
          </select>
        </div>
        <div class="header-actions">
          <button class="btn btn-primary" @click="openCreate">+ 新增记录</button>
          <button class="btn btn-danger" @click="confirmDeleteAll" v-if="total > 0">🗑️ 清空全部</button>
        </div>
      </div>
      <div class="count-hint" style="margin-bottom:8px">共 {{ total }} 条</div>
      <div class="table-wrap">
        <div v-if="loading" class="empty">加载中…</div>
        <div v-else-if="!records.length" class="empty">暂无记录</div>
        <table v-else>
          <thead>
            <tr><th style="width:40px">#</th><th style="min-width:140px">摘要</th><th>岗位</th><th>州</th><th>时薪</th><th>严重度</th><th>审核</th><th>来源</th><th style="width:120px">操作</th></tr>
          </thead>
          <tbody>
            <tr v-for="(r, i) in records" :key="r.id">
              <td style="color:var(--muted);font-size:11px;font-family:'Space Mono',monospace">{{ (page-1)*pageSize + i + 1 }}</td>
              <td><div style="font-size:11px;max-width:160px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" :title="r.summary">{{ r.summary || '—' }}</div></td>
              <td><span class="chip chip-blue">{{ r.job_position || '—' }}</span></td>
              <td style="color:var(--accent);font-weight:600">{{ r.state || '—' }}</td>
              <td style="font-family:'Space Mono',monospace;color:var(--accent3)">{{ r.hourly_wage ? '$'+r.hourly_wage : '—' }}</td>
              <td><span :class="'sev-badge sev-'+(r.severity||0)">{{ r.severity }}</span></td>
              <td>
                <select v-model="r.review_status" class="review-select" @change="reviewRecord(r)">
                  <option value="pending">待审核</option>
                  <option value="verified">已核验</option>
                  <option value="needs_review">需复核</option>
                  <option value="rejected">已驳回</option>
                </select>
              </td>
              <td><span :class="['chip', r.source_type==='comment'?'chip-green':'chip-blue']">{{ recordSourceLabel(r.source_type) }}</span></td>
              <td>
                <button class="btn-icon" title="编辑" @click="openEdit(r)">✏️</button>
                <button class="btn-icon" title="查看" @click="router.push(`/records/${r.id}`)">🔎</button>
                <button class="btn-icon btn-icon-del" title="删除" @click="deleteRecord(r.id, r.summary)">🗑️</button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
      <div v-if="pages > 1" class="pagination">
        <button class="btn btn-outline" :disabled="page <= 1" @click="changePage(-1)">← 上一页</button>
        <span style="font-size:12px;color:var(--muted)">{{ page }} / {{ pages }}</span>
        <button class="btn btn-outline" :disabled="page >= pages" @click="changePage(1)">下一页 →</button>
      </div>
    </div>

    <div v-if="tab === 'invites'" class="tab-pane">

  <div class="admin-header" style="margin-bottom:14px">
    <span class="count-hint">
      共 {{ invites.length }} 个邀请码
    </span>

    <button
      class="btn btn-primary"
      @click="openInviteModal"
    >
      + 新建邀请码
    </button>
  </div>

  <div class="table-wrap">
    <table>
      <thead>
        <tr>
          <th>邀请码</th>
          <th>VIP</th>
          <th>已使用</th>
          <th>最大次数</th>
          <th>剩余</th>
          <th>状态</th>
          <th>操作</th>
        </tr>
      </thead>

      <tbody>
        <tr
          v-for="i in invites"
          :key="i.id"
        >
          <td>
            <b>{{ i.code }}</b>
          </td>

          <td>
            {{ i.is_vip ? '👑' : '—' }}
          </td>

          <td>
            {{ i.used_count }}
          </td>

          <td>
            {{ i.max_uses }}
          </td>

          <td>
            {{ Math.max(0, i.max_uses - i.used_count) }}
          </td>

          <td>
            {{ i.is_active ? '启用' : '禁用' }}
          </td>

          <td>
            <div class="row-actions">

              <button
                class="btn-mini"
                @click="toggleInvite(i)"
              >
                {{ i.is_active ? '禁用' : '启用' }}
              </button>

              <button
                class="btn-mini del"
                @click="deleteInvite(i)"
              >
                删除
              </button>

            </div>
          </td>
        </tr>
      </tbody>

    </table>
  </div>

</div>





    <!-- ═══════════ Modals ═══════════ -->
    <!-- 记录编辑 -->
    <div v-if="modal.show" class="modal-overlay" @click.self="closeModal">
      <div class="modal">
        <div class="modal-header">
          <h3>{{ modal.isNew ? '新增避雷记录' : '编辑避雷记录' }}</h3>
          <button class="btn-close" @click="closeModal">✕</button>
        </div>
        <div class="modal-body">
          <div class="form-grid">
            <div class="form-group"><label>岗位名称</label><input v-model="form.job_position" placeholder="lifeguard..." /></div>
            <div class="form-group"><label>地点名称</label><input v-model="form.location_name" placeholder="Tennessee..." /></div>
            <div class="form-group"><label>城市</label><input v-model="form.city" placeholder="可选" /></div>
            <div class="form-group"><label>州缩写</label><input v-model="form.state" placeholder="TN" maxlength="2" style="text-transform:uppercase" /></div>
            <div class="form-group"><label>时薪 ($)</label><input v-model.number="form.hourly_wage" type="number" min="0" step="0.5" /></div>
            <div class="form-group"><label>小费情况</label><input v-model="form.tips" placeholder="无小费..." /></div>
            <div class="form-group"><label>每天工时 (h)</label><input v-model.number="form.hours_per_day" type="number" min="0" max="24" /></div>
            <div class="form-group"><label>每周工时 (h)</label><input v-model.number="form.hours_per_week" type="number" min="0" /></div>
            <div class="form-group"><label>严重度 (1-5)</label><select v-model.number="form.severity"><option v-for="s in [1,2,3,4,5]" :key="s" :value="s">{{ s }} - {{ sevLabel(s) }}</option></select></div>
            <div class="form-group"><label>置信度 (0-1)</label><input v-model.number="form.confidence" type="number" min="0" max="1" step="0.05" /></div>
            <div class="form-group"><label>雇主/公司</label><input v-model="form.employer" placeholder="可选" /></div>
            <div class="form-group"><label>来源类型</label><select v-model="form.source_type"><option value="post">笔记正文</option><option value="comment">评论</option></select></div>
            <div class="form-group full">
              <label>避雷理由（多选）</label>
              <div class="reason-grid">
                <label v-for="r in reasonOptions" :key="r" class="reason-check"><input type="checkbox" :value="r" v-model="form.avoidance_reasons" /><span>{{ r }}</span></label>
              </div>
            </div>
            <div class="form-group full"><label>避雷摘要</label><textarea v-model="form.summary" rows="3" style="width:100%;resize:vertical"></textarea></div>
            <div class="form-group full"><label>原帖链接</label><input v-model="form.note_url" placeholder="https://..." style="width:100%" /></div>
          </div>
        </div>
        <div class="modal-footer">
          <button class="btn btn-outline" @click="closeModal">取消</button>
          <button class="btn btn-primary" :disabled="saving" @click="saveRecord">{{ saving ? '保存中…' : (modal.isNew ? '创建' : '保存') }}</button>
        </div>
      </div>
    </div>

    <!-- 板块编辑 -->
    <div v-if="catModal.show" class="modal-overlay" @click.self="catModal.show=false">
      <div class="modal" style="max-width:480px">
        <div class="modal-header">
          <h3>{{ catModal.isNew ? '新建板块' : '编辑板块' }}</h3>
          <button class="btn-close" @click="catModal.show=false">✕</button>
        </div>
        <div class="modal-body">
          <div class="form-group" style="margin-bottom:14px"><label>图标 (emoji)</label><input v-model="catForm.icon" placeholder="💬" maxlength="4" /></div>
          <div class="form-group" style="margin-bottom:14px"><label>板块名称</label><input v-model="catForm.name" placeholder="例如：SWT避雷" /></div>
          <div class="form-group" style="margin-bottom:14px"><label>slug (英文唯一标识)</label><input v-model="catForm.slug" placeholder="swt-warning" style="font-family:monospace" /></div>
          <div class="form-group" style="margin-bottom:14px"><label>描述</label><textarea v-model="catForm.description" rows="2" style="width:100%"></textarea></div>
          <div class="form-group"><label>排序 (数字越小越靠前)</label><input v-model.number="catForm.sort_order" type="number" /></div>
        </div>
        <div class="modal-footer">
          <button class="btn btn-outline" @click="catModal.show=false">取消</button>
          <button class="btn btn-primary" :disabled="catSaving" @click="saveCat">{{ catSaving ? '保存中…' : '保存' }}</button>
        </div>
      </div>
    </div>

    <!-- 重置密码 -->
    <div v-if="pwModal.show" class="modal-overlay" @click.self="pwModal.show=false">
      <div class="modal" style="max-width:400px">
        <div class="modal-header">
          <h3>重置密码 - {{ pwModal.username }}</h3>
          <button class="btn-close" @click="pwModal.show=false">✕</button>
        </div>
        <div class="modal-body">
          <div class="form-group"><label>新密码 (至少 6 位)</label><input v-model="pwModal.newPw" type="password" placeholder="输入新密码" /></div>
        </div>
        <div class="modal-footer">
          <button class="btn btn-outline" @click="pwModal.show=false">取消</button>
          <button class="btn btn-primary" @click="doResetPw">确认重置</button>
        </div>
      </div>
    </div>

    <!-- 邀请码 -->
    <div v-if="inviteModal.show" class="modal-overlay" @click.self="inviteModal.show=false">
      <div class="modal" style="max-width:420px">
        <div class="modal-header">
          <h3>新建邀请码</h3>
          <button class="btn-close" @click="inviteModal.show=false">✕</button>
        </div>
        <div class="modal-body">
          <div class="form-group" style="margin-bottom:14px">
            <label>邀请码</label>
            <input v-model="inviteForm.code" placeholder="FOUNDING200" style="text-transform:uppercase" />
          </div>
          <div class="form-group" style="margin-bottom:14px">
            <label>最大使用次数</label>
            <input v-model.number="inviteForm.max_uses" type="number" min="1" />
          </div>
          <label class="reason-check">
            <input v-model="inviteForm.is_vip" type="checkbox" />
            <span>使用后开通 VIP</span>
          </label>
        </div>
        <div class="modal-footer">
          <button class="btn btn-outline" @click="inviteModal.show=false">取消</button>
          <button class="btn btn-primary" :disabled="inviteSaving" @click="saveInvite">
            {{ inviteSaving ? '创建中…' : '创建' }}
          </button>
        </div>
      </div>
    </div>

    <div v-if="toast.show" :class="['toast', toast.type]">{{ toast.msg }}</div>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { recordsApi, adminApi, forumApi } from '../api/index.js'
import { useAuthStore } from '../stores/auth.js'

const router = useRouter()
const auth = useAuthStore()
const myId = auth.user?.id

const tabs = [
  { key: 'overview', icon: '📊', label: '概览' },
  { key: 'ai', icon: '🤖', label: 'AI 配置' },
  { key: 'announcements', icon: '🔔', label: '通知' },
  { key: 'users', icon: '👥', label: '用户管理' },
  { key: 'categories', icon: '📁', label: '板块管理' },
  { key: 'posts', icon: '📝', label: '帖子审核' },
  { key: 'governance', icon: '🛡️', label: '治理' },
  { key: 'records', icon: '🗂️', label: '避雷数据' },
  { key: 'invites', icon: '🎟️', label: '邀请码' },
]
const tab = ref('overview')
const toast = ref({ show: false, msg: '', type: 'success' })
const invites = ref([])
const inviteSaving = ref(false)
const inviteModal = reactive({ show: false })
const inviteForm = reactive({
  code: '',
  max_uses: 1,
  is_vip: true,
})


async function loadInvites() {

  try {

    invites.value =
      await adminApi.inviteCodes()

  } catch (e) {

    showToast(
      e.message,
      'error'
    )

  }

}

async function toggleInvite(invite) {

  try {

    const r =
      await adminApi.updateInviteCode(
        invite.id,
        {
          is_active:
            !invite.is_active
        }
      )

    invite.is_active =
      r.is_active

    showToast('已更新')

  } catch (e) {

    showToast(
      e.message,
      'error'
    )

  }

}

function openInviteModal() {
  inviteForm.code = ''
  inviteForm.max_uses = 1
  inviteForm.is_vip = true
  inviteModal.show = true
}

async function saveInvite() {
  const code = inviteForm.code.trim().toUpperCase()
  if (!code) {
    showToast('请填写邀请码', 'error')
    return
  }

  if (!Number.isInteger(inviteForm.max_uses) || inviteForm.max_uses < 1) {
    showToast('最大使用次数至少为 1', 'error')
    return
  }

  inviteSaving.value = true
  try {
    await adminApi.createInviteCode({
      code,
      max_uses: inviteForm.max_uses,
      is_vip: inviteForm.is_vip,
    })
    inviteModal.show = false
    await loadInvites()
    showToast('已创建')
  } catch (e) {
    showToast(e.message, 'error')
  } finally {
    inviteSaving.value = false
  }
}


async function deleteInvite(invite) {

  if (
    !confirm(
      `删除邀请码 ${invite.code} ?`
    )
  ) return

  try {

    await adminApi.deleteInviteCode(
      invite.id
    )

    loadInvites()

    showToast('已删除')

  } catch (e) {

    showToast(
      e.message,
      'error'
    )

  }

}












function switchTab(k) {
  tab.value = k

  if (k === 'overview') loadOverview()
  else if (k === 'ai') loadAIConfig()
  else if (k === 'announcements') loadAnnouncements()
  else if (k === 'users') loadUsers()
  else if (k === 'categories') loadCategories()
  else if (k === 'posts') loadPosts()
  else if (k === 'governance') loadGovernance()
  else if (k === 'records') loadRecords()
  else if (k === 'invites') loadInvites()
}

function showToast(msg, type = 'success') {
  toast.value = { show: true, msg, type }
  setTimeout(() => { toast.value.show = false }, 3000)
}
function formatDate(iso) { return iso ? new Date(iso).toLocaleDateString('zh-CN') : '' }

// ═══════ 概览 ═══════
const ov = ref({})
async function loadOverview() {
  try { ov.value = await adminApi.overview() } catch (e) { showToast(e.message, 'error') }
}

// ═══════ AI 配置 ═══════
const aiConfig = ref({})
const aiSaving = ref(false)
const aiTesting = ref(false)
const aiTestResult = ref(null)
const aiForm = reactive({
  provider: 'openai_compatible',
  base_url: 'https://api.openai.com/v1',
  api_key: '',
  model: 'gpt-4o-mini',
  enabled: false,
  temperature: 0.2,
  clear_api_key: false,
})
const aiKeyPlaceholder = '留空则保留当前 API Key'
const providerPresets = {
  openai: { base_url: 'https://api.openai.com/v1', model: 'gpt-4o-mini' },
  deepseek: { base_url: 'https://api.deepseek.com/v1', model: 'deepseek-chat' },
  moonshot: { base_url: 'https://api.moonshot.cn/v1', model: 'moonshot-v1-8k' },
  qwen: { base_url: 'https://dashscope.aliyuncs.com/compatible-mode/v1', model: 'qwen-plus' },
  openai_compatible: { base_url: aiForm.base_url || 'https://api.openai.com/v1', model: aiForm.model || 'gpt-4o-mini' },
}

async function loadAIConfig() {
  try {
    aiTestResult.value = null
    const cfg = await adminApi.aiConfig()
    aiConfig.value = cfg
    Object.assign(aiForm, {
      provider: cfg.provider || 'openai_compatible',
      base_url: cfg.base_url || 'https://api.openai.com/v1',
      api_key: '',
      model: cfg.model || 'gpt-4o-mini',
      enabled: !!cfg.enabled,
      temperature: cfg.temperature ?? 0.2,
      clear_api_key: false,
    })
  } catch (e) { showToast(e.message, 'error') }
}

function applyProviderPreset() {
  const preset = providerPresets[aiForm.provider]
  if (!preset) return
  aiForm.base_url = preset.base_url
  aiForm.model = preset.model
}

async function saveAIConfig() {
  aiSaving.value = true
  try {
    const payload = { ...aiForm }
    if (!payload.api_key) payload.api_key = null
    const cfg = await adminApi.updateAiConfig(payload)
    aiConfig.value = cfg
    aiForm.api_key = ''
    aiForm.clear_api_key = false
    showToast('AI 配置已保存')
  } catch (e) { showToast(e.message, 'error') }
  finally { aiSaving.value = false }
}

async function testAIConfig() {
  aiTesting.value = true
  aiTestResult.value = null
  try {
    const payload = { ...aiForm }
    if (!payload.api_key) payload.api_key = null
    aiTestResult.value = await adminApi.testAiConfig(payload)
    showToast(aiTestResult.value.ok ? 'AI 测试成功' : 'AI 测试失败', aiTestResult.value.ok ? 'success' : 'error')
  } catch (e) {
    aiTestResult.value = { ok: false, error: e.message }
    showToast(e.message, 'error')
  } finally {
    aiTesting.value = false
  }
}

// ═══════ 通知管理 ═══════
const announcements = ref([])
const announcementStatus = ref('all')
const announcementSaving = ref(false)
const announcementForm = reactive(emptyAnnouncementForm())
const announcementLevels = {
  info: '普通',
  success: '成功',
  warning: '警告',
  danger: '重要',
}

function emptyAnnouncementForm() {
  return {
    id: '',
    title: '',
    body: '',
    level: 'info',
    link_url: '',
    is_active: true,
    is_pinned: false,
    starts_at: '',
    ends_at: '',
  }
}

function levelLabel(level) {
  return announcementLevels[level] || '普通'
}

async function loadAnnouncements() {
  try {
    announcements.value = await adminApi.announcements({ status: announcementStatus.value })
  } catch (e) { showToast(e.message, 'error') }
}

function resetAnnouncementForm() {
  Object.assign(announcementForm, emptyAnnouncementForm())
}

function editAnnouncement(item) {
  Object.assign(announcementForm, {
    id: item.id,
    title: item.title,
    body: item.body,
    level: item.level || 'info',
    link_url: item.link_url || '',
    is_active: !!item.is_active,
    is_pinned: !!item.is_pinned,
    starts_at: toLocalDateTime(item.starts_at),
    ends_at: toLocalDateTime(item.ends_at),
  })
}

function toLocalDateTime(iso) {
  if (!iso) return ''
  const d = new Date(iso)
  const pad = n => String(n).padStart(2, '0')
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`
}

function announcementPayload() {
  return {
    title: announcementForm.title,
    body: announcementForm.body,
    level: announcementForm.level,
    link_url: announcementForm.link_url,
    is_active: announcementForm.is_active,
    is_pinned: announcementForm.is_pinned,
    starts_at: announcementForm.starts_at || null,
    ends_at: announcementForm.ends_at || null,
  }
}

async function saveAnnouncement() {
  if (!announcementForm.title.trim()) { showToast('通知标题不能为空', 'error'); return }
  announcementSaving.value = true
  try {
    if (announcementForm.id) await adminApi.updateAnnouncement(announcementForm.id, announcementPayload())
    else await adminApi.createAnnouncement(announcementPayload())
    resetAnnouncementForm()
    await loadAnnouncements()
    showToast('通知已保存')
  } catch (e) { showToast(e.message, 'error') }
  finally { announcementSaving.value = false }
}

async function toggleAnnouncement(item) {
  try {
    await adminApi.updateAnnouncement(item.id, { ...item, is_active: !item.is_active })
    await loadAnnouncements()
    showToast(item.is_active ? '通知已下线' : '通知已启用')
  } catch (e) { showToast(e.message, 'error') }
}

async function deleteAnnouncement(item) {
  if (!confirm(`删除通知「${item.title}」？`)) return
  try {
    await adminApi.deleteAnnouncement(item.id)
    await loadAnnouncements()
    showToast('通知已删除')
  } catch (e) { showToast(e.message, 'error') }
}

// ═══════ 用户管理 ═══════
const users = ref([])
const usersLoading = ref(false)
const userSearch = ref('')
const userPage = ref(1)
const userPages = ref(1)
const userTotal = ref(0)
let userTimer = null

async function loadUsers() {
  usersLoading.value = true
  try {
    const res = await adminApi.users({ search: userSearch.value || undefined, page: userPage.value, page_size: 20 })
    users.value = res.users
    userPages.value = res.pages
    userTotal.value = res.total
  } catch (e) { showToast(e.message, 'error') }
  finally { usersLoading.value = false }
}
function onUserSearch() { clearTimeout(userTimer); userTimer = setTimeout(() => { userPage.value = 1; loadUsers() }, 400) }

async function setRole(u, role) {
  try { await adminApi.updateUser(u.id, { role }); u.role = role; showToast(`已${role === 'admin' ? '设为管理员' : '降为用户'}`) }
  catch (e) { showToast(e.message, 'error') }
}
async function toggleVip(u) {
  try {
    const r = await adminApi.toggleVip(u.id);
    u.is_vip = r.is_vip;
    showToast(r.message || (u.is_vip ? '已开通 VIP' : '已取消 VIP'))
  }
  catch (e) { showToast(e.message, 'error') }
}

async function toggleActive(u) {
  try { const r = await adminApi.updateUser(u.id, { is_active: !u.is_active }); u.is_active = r.is_active; showToast(u.is_active ? '已启用' : '已禁用') }
  catch (e) { showToast(e.message, 'error') }
}
async function editAssessmentQuota(u) {
  const credits = prompt(`设置 ${u.username} 的付费评估次数`, String(u.assessment_credits || 0))
  if (credits === null) return
  const monthly = prompt(`设置 ${u.username} 的会员每月评估额度`, String(u.assessment_monthly_limit || 10))
  if (monthly === null) return
  try {
    const updated = await adminApi.updateUser(u.id, {
      assessment_credits: Number(credits) || 0,
      assessment_monthly_limit: Number(monthly) || 0,
    })
    u.assessment_credits = updated.assessment_credits
    u.assessment_monthly_limit = updated.assessment_monthly_limit
    showToast('评估额度已更新')
  } catch (e) { showToast(e.message, 'error') }
}
async function deleteUser(u) {
  if (!confirm(`确认删除用户「${u.username}」？其所有帖子和回复将一并删除！`)) return
  try { await adminApi.deleteUser(u.id); loadUsers(); showToast('已删除') }
  catch (e) { showToast(e.message, 'error') }
}

const pwModal = reactive({ show: false, userId: '', username: '', newPw: '' })
function openResetPw(u) { pwModal.show = true; pwModal.userId = u.id; pwModal.username = u.username; pwModal.newPw = '' }
async function doResetPw() {
  if (pwModal.newPw.length < 6) { showToast('密码至少 6 位', 'error'); return }
  try { await adminApi.resetPassword(pwModal.userId, { new_password: pwModal.newPw }); pwModal.show = false; showToast('密码已重置') }
  catch (e) { showToast(e.message, 'error') }
}

// ═══════ 板块管理 ═══════
const categories = ref([])
async function loadCategories() {
  try { categories.value = await forumApi.categories() } catch (e) { showToast(e.message, 'error') }
}
const catModal = reactive({ show: false, isNew: true, id: '' })
const catForm = reactive({ icon: '💬', name: '', slug: '', description: '', sort_order: 0 })
function openCatModal(c) {
  if (c) {
    catModal.isNew = false; catModal.id = c.id
    Object.assign(catForm, { icon: c.icon, name: c.name, slug: c.slug, description: c.description || '', sort_order: c.sort_order })
  } else {
    catModal.isNew = true; catModal.id = ''
    Object.assign(catForm, { icon: '💬', name: '', slug: '', description: '', sort_order: categories.value.length + 1 })
  }
  catModal.show = true
}
const catSaving = ref(false)
async function saveCat() {
  if (!catForm.name.trim() || !catForm.slug.trim()) { showToast('名称和 slug 必填', 'error'); return }
  catSaving.value = true
  try {
    if (catModal.isNew) { await adminApi.createCategory({ ...catForm }); showToast('板块已创建') }
    else { await adminApi.updateCategory(catModal.id, { ...catForm }); showToast('板块已更新') }
    catModal.show = false
    loadCategories()
  } catch (e) { showToast(e.message, 'error') }
  finally { catSaving.value = false }
}
async function deleteCategory(c) {
  if (!confirm(`确认删除板块「${c.name}」？该板块下 ${c.post_count} 个帖子将一并删除！`)) return
  try { await adminApi.deleteCategory(c.id); loadCategories(); showToast('板块已删除') }
  catch (e) { showToast(e.message, 'error') }
}

// ═══════ 帖子审核 ═══════
const posts = ref([])
const postsLoading = ref(false)
const postSearch = ref('')
const postPage = ref(1)
const postPages = ref(1)
const postTotal = ref(0)
let postTimer = null

async function loadPosts() {
  postsLoading.value = true
  try {
    const res = await adminApi.posts({ search: postSearch.value || undefined, page: postPage.value, page_size: 20 })
    posts.value = res.posts
    postPages.value = res.pages
    postTotal.value = res.total
  } catch (e) { showToast(e.message, 'error') }
  finally { postsLoading.value = false }
}
function onPostSearch() { clearTimeout(postTimer); postTimer = setTimeout(() => { postPage.value = 1; loadPosts() }, 400) }
function goPost(id) { router.push(`/forum/post/${id}`) }
async function togglePin(p) {
  try { const r = await adminApi.moderatePost(p.id, { is_pinned: !p.is_pinned }); p.is_pinned = r.is_pinned; showToast(p.is_pinned ? '已置顶' : '已取消置顶') }
  catch (e) { showToast(e.message, 'error') }
}
async function toggleLock(p) {
  try { const r = await adminApi.moderatePost(p.id, { is_locked: !p.is_locked }); p.is_locked = r.is_locked; showToast(p.is_locked ? '已锁定' : '已解锁') }
  catch (e) { showToast(e.message, 'error') }
}
async function deletePost(p) {
  if (!confirm(`确认删除帖子「${p.title}」？`)) return
  try { await adminApi.deletePost(p.id); loadPosts(); showToast('帖子已删除') }
  catch (e) { showToast(e.message, 'error') }
}

// ═══════ 治理中心 ═══════
const reports = ref([])
const recordFeedbacks = ref([])
const reportStatus = ref('open')
const feedbackStatus = ref('open')
const sensitiveWords = ref([])
const bans = ref([])
const sensitiveForm = reactive({ word: '' })
const banForm = reactive({ user_id: '', days: 7, reason: '' })

async function loadGovernance() {
  try {
    const [rs, feedbacks, words, bs] = await Promise.all([
      adminApi.reports({ status: reportStatus.value }),
      adminApi.recordFeedback({ status: feedbackStatus.value }),
      adminApi.sensitiveWords(),
      adminApi.bans(),
    ])
    reports.value = rs
    recordFeedbacks.value = feedbacks
    sensitiveWords.value = words
    bans.value = bs
  } catch (e) {
    showToast(e.message, 'error')
  }
}

async function resolveReport(r, action, status = 'resolved') {
  try {
    await adminApi.moderateReport(r.id, { action, status })
    await loadGovernance()
    showToast('举报已处理')
  } catch (e) { showToast(e.message, 'error') }
}

async function resolveRecordFeedback(item, status) {
  try {
    await adminApi.moderateRecordFeedback(item.id, { status })
    await loadGovernance()
    showToast(status === 'resolved' ? '反馈已处理' : '反馈已驳回')
  } catch (e) { showToast(e.message, 'error') }
}

async function goRecordEdit(recordId) {
  switchTab('records')
  await loadRecords()
  const found = records.value.find(x => x.id === recordId)
  if (found) openEdit(found)
  else showToast('已切换到避雷数据，请搜索该记录处理')
}

async function addSensitiveWord() {
  if (!sensitiveForm.word.trim()) return
  try {
    await adminApi.createSensitiveWord({ word: sensitiveForm.word.trim(), action: 'block', is_active: true })
    sensitiveForm.word = ''
    await loadGovernance()
    showToast('已添加敏感词')
  } catch (e) { showToast(e.message, 'error') }
}

async function toggleSensitiveWord(w) {
  try {
    await adminApi.updateSensitiveWord(w.id, { word: w.word, action: w.action || 'block', is_active: !w.is_active })
    await loadGovernance()
  } catch (e) { showToast(e.message, 'error') }
}

async function deleteSensitiveWord(w) {
  if (!confirm(`删除敏感词「${w.word}」？`)) return
  try {
    await adminApi.deleteSensitiveWord(w.id)
    await loadGovernance()
  } catch (e) { showToast(e.message, 'error') }
}

async function createBan() {
  if (!banForm.user_id.trim()) { showToast('请填写用户 ID', 'error'); return }
  try {
    await adminApi.createBan({ ...banForm, days: Number(banForm.days) || 7 })
    Object.assign(banForm, { user_id: '', days: 7, reason: '' })
    await loadGovernance()
    showToast('已封禁')
  } catch (e) { showToast(e.message, 'error') }
}

async function liftBan(b) {
  try {
    await adminApi.liftBan(b.id)
    await loadGovernance()
    showToast('已解封')
  } catch (e) { showToast(e.message, 'error') }
}

// ═══════ 避雷数据 (records CRUD) ═══════
const records = ref([])
const loading = ref(false)
const saving = ref(false)
const total = ref(0)
const page = ref(1)
const pages = ref(1)
const pageSize = 20
const search = ref('')
const filterState = ref('')
const filterSev = ref('')
const filterReview = ref('')
const states = ref([])
const modal = reactive({ show: false, isNew: true })
const form = reactive(emptyForm())
const reasonOptions = [
  '暴晒/户外高温', '工时过长', '休息不足', '岗位不符/被调岗',
  '小费低/收入不符', '管理/雇主问题', 'SSN/换岗流程困难',
  '被解雇/强制辞退', '住宿问题', '英语要求高', '工时被削减',
  '雇主歧视', '小费被盗/提前拿走'
]
const sevLabels = { 1: '轻微吐槽', 2: '小坑', 3: '一般问题', 4: '严重', 5: '极度严重' }
const sevLabel = (s) => sevLabels[s] || ''
const recordSourceLabel = (type) => type === 'comment' ? '评论' : type === 'user' ? '用户上报' : '帖子'
function emptyForm() {
  return {
    id: null, valuable: true, source_type: 'post',
    job_position: '', location_name: '', city: '', state: '',
    hourly_wage: null, tips: '', hours_per_day: null, hours_per_week: null,
    avoidance_reasons: [], severity: 3, confidence: 0.8,
    employer: '', summary: '', note_url: ''
  }
}
let searchTimer = null
function onSearch() { clearTimeout(searchTimer); searchTimer = setTimeout(() => { page.value = 1; loadRecords() }, 400) }
async function loadRecords() {
  loading.value = true
  try {
    const res = await recordsApi.list({
      page: page.value, page_size: pageSize,
      search: search.value || undefined,
      state: filterState.value || undefined,
      severity: filterSev.value || undefined,
      review_status: filterReview.value || undefined,
      include_unverified: true,
      valuable_only: false
    })
    records.value = res.records
    total.value = res.total
    pages.value = res.pages
    const s = new Set(res.records.filter(r => r.state).map(r => r.state))
    if (states.value.length === 0) states.value = [...s].sort()
  } catch (e) { showToast(e.message, 'error') }
  finally { loading.value = false }
}
function changePage(d) { page.value += d; loadRecords() }
function openCreate() { Object.assign(form, emptyForm()); modal.isNew = true; modal.show = true }
function openEdit(r) {
  Object.assign(form, { ...r, avoidance_reasons: [...(r.avoidance_reasons || [])], hourly_wage: r.hourly_wage ?? null, hours_per_day: r.hours_per_day ?? null, hours_per_week: r.hours_per_week ?? null })
  modal.isNew = false; modal.show = true
}
function closeModal() { modal.show = false }
async function saveRecord() {
  saving.value = true
  try {
    const payload = { ...form }
    if (!payload.hourly_wage) payload.hourly_wage = null
    if (!payload.hours_per_day) payload.hours_per_day = null
    if (!payload.hours_per_week) payload.hours_per_week = null
    if (modal.isNew) { await recordsApi.create(payload); showToast('创建成功') }
    else { await recordsApi.update(form.id, payload); showToast('更新成功') }
    closeModal(); loadRecords()
  } catch (e) { showToast('保存失败: ' + e.message, 'error') }
  finally { saving.value = false }
}
async function deleteRecord(id, summary) {
  if (!confirm(`确认删除？\n${summary || id}`)) return
  try { await recordsApi.delete(id); showToast('已删除'); loadRecords() }
  catch (e) { showToast(e.message, 'error') }
}
async function reviewRecord(record) {
  try {
    await recordsApi.review(record.id, {
      review_status: record.review_status,
      review_note: record.review_note || '',
    })
    showToast('审核状态已更新')
  } catch (e) {
    showToast(e.message, 'error')
  }
}
async function confirmDeleteAll() {
  if (!confirm(`⚠️ 确认清空全部 ${total.value} 条记录？此操作不可撤销！`)) return
  try { await recordsApi.deleteAll(); showToast('已清空全部数据'); loadRecords() }
  catch (e) { showToast(e.message, 'error') }
}

onMounted(loadOverview)
</script>

<style scoped>
.admin-header { display: flex; justify-content: space-between; align-items: center; }
.header-actions { display: flex; gap: 8px; }
.filter-bar { display: flex; gap: 8px; flex-wrap: wrap; align-items: center; }
.count-hint { color: var(--muted); font-size: 12px; font-family: 'Space Mono', monospace; }

.admin-tabs { display: flex; gap: 4px; margin-bottom: 20px; border-bottom: 1px solid var(--border); flex-wrap: wrap; }
.admin-tabs button {
  background: transparent; border: none; color: var(--muted); padding: 10px 16px;
  cursor: pointer; font-size: 14px; font-family: inherit; border-bottom: 2px solid transparent;
  transition: all .2s;
}
.admin-tabs button:hover { color: var(--text); }
.admin-tabs button.active { color: var(--accent); border-bottom-color: var(--accent); font-weight: 600; }

.tab-pane { animation: fadeIn .2s ease; }
.ai-config-panel { max-width: 760px; }
.config-desc, .hint { color: var(--muted); font-size: 12px; line-height: 1.6; margin-bottom: 14px; }
.hint { margin-top: 6px; margin-bottom: 0; }
.ai-test-result { margin-top: 14px; border-radius: 8px; padding: 12px; font-size: 12px; line-height: 1.7; border: 1px solid var(--border); }
.ai-test-result.ok { border-color: var(--accent3); color: var(--accent3); background: rgba(16,185,129,.08); }
.ai-test-result.err { border-color: var(--red); color: var(--red); background: rgba(239,68,68,.08); }
.ann-grid { display: grid; grid-template-columns: minmax(360px, 520px) 1fr; gap: 14px; align-items: start; }
.ann-checks { display: flex; gap: 16px; margin: 10px 0; }
.ann-list { display: flex; flex-direction: column; gap: 10px; max-height: 620px; overflow: auto; }
.ann-card { border: 1px solid var(--border); border-radius: 8px; padding: 12px; background: var(--surface); }
.ann-card.warning { border-color: rgba(245,158,11,.45); }
.ann-card.danger { border-color: rgba(239,68,68,.5); }
.ann-card.success { border-color: rgba(16,185,129,.45); }
.ann-card.inactive { opacity: .58; }
.ann-title { display: flex; align-items: center; gap: 8px; font-size: 14px; margin-bottom: 6px; }
.ann-body { color: var(--muted); font-size: 12px; line-height: 1.6; white-space: pre-wrap; margin-bottom: 8px; }
.ann-meta { color: var(--muted); font-size: 11px; margin-bottom: 8px; }
@keyframes fadeIn { from { opacity: 0; transform: translateY(6px); } to { opacity: 1; transform: none; } }

.table-wrap { overflow: auto; max-height: calc(100vh - 320px); border-radius: 8px; border: 1px solid var(--border); }
.governance-grid { display: grid; grid-template-columns: 1.4fr 1fr 1fr; gap: 14px; align-items: start; }
.mod-list { display: flex; flex-direction: column; gap: 8px; max-height: 520px; overflow: auto; }
.mod-card { border: 1px solid var(--border); background: var(--surface); border-radius: 8px; padding: 10px; font-size: 13px; }
.mod-excerpt { color: var(--muted); margin: 6px 0; line-height: 1.5; }
.mod-meta { color: var(--muted); font-size: 11px; margin-bottom: 8px; }
.word-list { display: flex; gap: 6px; flex-wrap: wrap; }
.word-chip { display: flex; align-items: center; gap: 6px; border: 1px solid var(--border); border-radius: 7px; padding: 5px 8px; font-size: 12px; }
.word-chip button { border: 0; background: transparent; color: var(--accent2); cursor: pointer; font-family: inherit; font-size: 11px; }
.ban-form { display: grid; gap: 8px; margin-bottom: 12px; }
.review-select { font-size: 11px; padding: 4px 6px; min-width: 82px; }
.empty { text-align: center; padding: 60px; color: var(--muted); }
.pagination { display: flex; gap: 12px; align-items: center; justify-content: center; margin-top: 16px; }

.role-tag { font-size: 11px; padding: 2px 8px; border-radius: 99px; font-weight: 600; }
.role-tag.admin { background: var(--accent); color: #fff; }
.role-tag.user { background: var(--surface2); color: var(--muted); }

.status-dot { display: inline-block; width: 7px; height: 7px; border-radius: 50%; margin-right: 4px; }
.status-dot.on { background: var(--accent3); }
.status-dot.off { background: var(--red); }

.row-actions { display: flex; gap: 4px; flex-wrap: wrap; }
.btn-mini {
  background: var(--surface2); border: 1px solid var(--border); color: var(--text);
  padding: 3px 8px; border-radius: 5px; font-size: 11px; cursor: pointer; font-family: inherit;
  white-space: nowrap; transition: all .15s;
}
.btn-mini:hover:not(:disabled) { border-color: var(--accent2); }
.btn-mini.del { color: var(--red); }
.btn-mini.del:hover:not(:disabled) { border-color: var(--red); background: rgba(239,68,68,.1); }
.btn-mini:disabled { opacity: .4; cursor: not-allowed; }

.tag-pin { font-size: 10px; background: var(--accent); color: #fff; padding: 1px 6px; border-radius: 4px; margin-right: 4px; }
.tag-lock { font-size: 10px; background: var(--surface2); color: var(--muted); border: 1px solid var(--border); padding: 1px 6px; border-radius: 4px; }

.btn-icon { background: none; border: none; cursor: pointer; padding: 4px 6px; border-radius: 4px; font-size: 14px; transition: background .2s; }
.btn-icon:hover { background: rgba(255,255,255,.1); }
.btn-icon-del:hover { background: rgba(239,68,68,.15); }

.modal-overlay { position: fixed; inset: 0; background: rgba(0,0,0,.7); z-index: 2000; display: flex; align-items: center; justify-content: center; padding: 20px; }
.modal { background: var(--surface); border: 1px solid var(--border); border-radius: 12px; width: 100%; max-width: 760px; max-height: 90vh; display: flex; flex-direction: column; box-shadow: 0 24px 64px rgba(0,0,0,.6); }
.modal-header { display: flex; justify-content: space-between; align-items: center; padding: 18px 24px; border-bottom: 1px solid var(--border); }
.modal-header h3 { font-size: 16px; font-weight: 700; }
.btn-close { background: none; border: none; color: var(--muted); cursor: pointer; font-size: 18px; padding: 2px 6px; }
.btn-close:hover { color: var(--text); }
.modal-body { padding: 20px 24px; overflow-y: auto; flex: 1; }
.modal-footer { padding: 16px 24px; border-top: 1px solid var(--border); display: flex; justify-content: flex-end; gap: 8px; }

.form-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
.form-group { display: flex; flex-direction: column; gap: 6px; }
.form-group.full { grid-column: 1 / -1; }
.form-group label { font-size: 11px; font-weight: 600; color: var(--muted); text-transform: uppercase; letter-spacing: .5px; }
.form-group input, .form-group select, .form-group textarea { width: 100%; }

.reason-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 8px; background: var(--surface2); border: 1px solid var(--border); border-radius: 6px; padding: 12px; }
.reason-check { display: flex; align-items: center; gap: 6px; font-size: 12px; cursor: pointer; }
.reason-check input { accent-color: var(--accent); }

@media (max-width: 768px) {
  .form-grid { grid-template-columns: 1fr; }
  .reason-grid { grid-template-columns: 1fr 1fr; }
  .stat-grid { grid-template-columns: repeat(2,1fr) !important; }
  .governance-grid { grid-template-columns: 1fr; }
  .ann-grid { grid-template-columns: 1fr; }
}
</style>
