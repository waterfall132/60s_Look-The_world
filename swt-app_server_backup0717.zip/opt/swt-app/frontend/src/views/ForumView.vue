<template>
  <div class="page">
    <div class="forum-head">
      <div>
        <div class="page-title" style="margin-bottom:4px">💬 社区论坛</div>
        <div class="forum-sub">分享经历 · 寻找搭子 · 交流面签</div>
      </div>
      <div class="head-actions">
        <button v-if="auth.isLoggedIn" class="btn btn-outline" @click="openNotifications">通知 {{ unread ? `(${unread})` : '' }}</button>
        <button v-if="auth.isLoggedIn" class="btn btn-primary" @click="showNewPost = true">✏️ 发帖</button>
        <router-link v-else to="/login" class="btn btn-primary" style="text-decoration:none">登录后发帖</router-link>
      </div>
    </div>

    <div class="forum-layout">
      <!-- 板块侧栏 -->
      <aside class="cat-sidebar">
        <div class="panel">
          <div class="panel-title">板块</div>
          <div class="cat-list">
            <div class="cat-item" :class="{ active: activeCat === null }" @click="selectCat(null)">
              <span class="cat-icon">📋</span>
              <span class="cat-name">全部</span>
            </div>
            <div v-for="c in categories" :key="c.id" class="cat-item"
                 :class="{ active: activeCat === c.slug }" @click="selectCat(c.slug)">
              <span class="cat-icon">{{ c.icon }}</span>
              <span class="cat-name">{{ c.name }}</span>
              <span class="cat-count">{{ c.post_count }}</span>
            </div>
          </div>
        </div>
      </aside>

      <!-- 帖子列表 -->
      <div class="post-main">
        <div class="post-toolbar">
          <div class="forum-controls">
            <input v-model="search" class="forum-search" placeholder="搜索标题、正文或作者" @input="onSearch" />
            <div class="sort-tabs">
              <button :class="{ active: sort==='latest_reply' }" @click="setSort('latest_reply')">最新回复</button>
              <button :class="{ active: sort==='latest' }" @click="setSort('latest')">最新发布</button>
              <button :class="{ active: sort==='hot' }" @click="setSort('hot')">热门</button>
            </div>
          </div>
          <div class="post-count" v-if="!loading">
            {{ total }} 个帖子
            <span v-if="activeTag" class="tag-filter">#{{ activeTag }}</span>
            <button v-if="search || activeCat || activeTag" class="clear-filter" @click="clearFilters">清空筛选</button>
          </div>
        </div>

        <div v-if="loading" class="empty">加载中…</div>
        <div v-else-if="posts.length === 0" class="empty">
          还没有帖子，来发第一帖吧！
        </div>

        <div v-else class="post-list">
          <div v-for="p in posts" :key="p.id" class="post-card" @click="openPost(p.id)">
            <div class="post-avatar">{{ p.author_avatar }}</div>
            <div class="post-body">
              <div class="post-card-title">
                <span v-if="p.is_pinned" class="pin-tag">置顶</span>
                <span v-if="p.is_locked" class="lock-tag">🔒</span>
                {{ p.title }}
              </div>
              <div class="post-meta">
                <span class="cat-badge">{{ catIcon(p.category_slug) }} {{ p.category_name }}</span>
                <span>{{ p.author_name }}</span>
                <span>{{ p.author_level }} · {{ p.author_reputation || 0 }} 声望</span>
                <span>{{ timeAgo(p.created_at) }}</span>
                <span v-if="p.last_activity_at">最后活动 {{ timeAgo(p.last_activity_at) }}</span>
              </div>
              <div v-if="p.tags?.length" class="tag-row" @click.stop>
                <button v-for="tag in p.tags" :key="tag" class="tag-chip" @click="selectTag(tag)">#{{ tag }}</button>
              </div>
            </div>
            <div class="post-stats">
              <div class="pstat">👁 {{ p.view_count }}</div>
              <div class="pstat">💬 {{ p.comment_count }}</div>
              <div class="pstat" :class="{ liked: p.liked_by_me }">♥ {{ p.like_count }}</div>
            </div>
          </div>
        </div>

        <!-- 分页 -->
        <div v-if="pages > 1" class="pager">
          <button class="btn btn-outline" :disabled="page<=1" @click="changePage(page-1)">上一页</button>
          <span class="pager-info">{{ page }} / {{ pages }}</span>
          <button class="btn btn-outline" :disabled="page>=pages" @click="changePage(page+1)">下一页</button>
        </div>
      </div>
    </div>

    <!-- 发帖弹窗 -->
    <div v-if="showNewPost" class="modal-mask" @click.self="showNewPost = false">
      <div class="modal">
        <div class="modal-title">发布新帖</div>
        <div class="form-group">
          <label>板块</label>
          <select v-model="newPost.category_id">
            <option v-for="c in categories" :key="c.id" :value="c.id">{{ c.icon }} {{ c.name }}</option>
          </select>
        </div>
        <div class="form-group">
          <label>标题</label>
          <input v-model="newPost.title" placeholder="一句话说清楚" />
        </div>
        <div class="form-group">
          <label>内容</label>
          <textarea v-model="newPost.body" rows="8" placeholder="支持 Markdown，可粘贴图片链接到下方"></textarea>
        </div>
        <div class="form-group">
          <label>标签（逗号分隔，最多 5 个）</label>
          <input v-model="tagInput" placeholder="面签, lifeguard, 住宿" />
        </div>
        <div class="form-group">
          <label>图片 URL（每行一个，最多 6 张）</label>
          <textarea v-model="imageInput" rows="3" placeholder="https://..."></textarea>
        </div>
        <div v-if="drafts.length" class="draft-list">
          <button v-for="d in drafts" :key="d.id" class="draft-chip" @click="loadDraft(d)">
            草稿：{{ d.title || '无标题' }}
          </button>
        </div>
        <div v-if="postError" class="form-error">{{ postError }}</div>
        <div class="modal-actions">
          <button class="btn btn-outline" @click="showNewPost = false">取消</button>
          <button class="btn btn-outline" :disabled="posting" @click="saveDraft">保存草稿</button>
          <button class="btn btn-primary" :disabled="posting" @click="submitPost">{{ posting ? '发布中…' : '发布' }}</button>
        </div>
      </div>
    </div>

    <div v-if="showNotifications" class="modal-mask" @click.self="showNotifications = false">
      <div class="modal">
        <div class="modal-title">通知</div>
        <div v-if="notifications.length === 0" class="empty" style="padding:24px">暂无通知</div>
        <div v-else class="notice-list">
          <div v-for="n in notifications" :key="n.id" class="notice-item" :class="{ unread: !n.is_read }" @click="openNotice(n)">
            <div class="notice-title">{{ n.title }}</div>
            <div class="notice-body">{{ n.body }}</div>
            <div class="notice-time">{{ timeAgo(n.created_at) }}</div>
          </div>
        </div>
        <div class="modal-actions">
          <button class="btn btn-outline" @click="markRead">全部已读</button>
          <button class="btn btn-primary" @click="showNotifications = false">关闭</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { forumApi } from '../api/index.js'
import { useAuthStore } from '../stores/auth.js'

const auth = useAuthStore()
const router = useRouter()

const categories = ref([])
const posts = ref([])
const activeCat = ref(null)
const activeTag = ref('')
const sort = ref('latest_reply')
const search = ref('')
const page = ref(1)
const pages = ref(1)
const total = ref(0)
const loading = ref(true)

const showNewPost = ref(false)
const showNotifications = ref(false)
const unread = ref(0)
const notifications = ref([])
const drafts = ref([])
const newPost = ref({ category_id: '', title: '', body: '', tags: [], image_urls: [] })
const draftId = ref('')
const tagInput = ref('')
const imageInput = ref('')
const posting = ref(false)
const postError = ref('')
let searchTimer = null

function catIcon(slug) {
  const c = categories.value.find(x => x.slug === slug)
  return c ? c.icon : '💬'
}

function timeAgo(iso) {
  if (!iso) return ''
  const d = new Date(iso)
  const diff = (Date.now() - d.getTime()) / 1000
  if (diff < 60) return '刚刚'
  if (diff < 3600) return `${Math.floor(diff/60)} 分钟前`
  if (diff < 86400) return `${Math.floor(diff/3600)} 小时前`
  if (diff < 2592000) return `${Math.floor(diff/86400)} 天前`
  return d.toLocaleDateString('zh-CN')
}

async function loadCategories() {
  categories.value = await forumApi.categories()
  if (categories.value.length && !newPost.value.category_id) {
    newPost.value.category_id = categories.value[0].id
  }
}

async function loadPosts() {
  loading.value = true
  try {
    const params = { page: page.value, page_size: 20, sort: sort.value }
    if (activeCat.value) params.category_slug = activeCat.value
    if (activeTag.value) params.tag = activeTag.value
    if (search.value.trim()) params.search = search.value.trim()
    const res = await forumApi.posts(params)
    posts.value = res.posts
    pages.value = res.pages
    total.value = res.total
  } catch (e) {
    console.error(e)
  } finally {
    loading.value = false
  }
}

function selectCat(slug) { activeCat.value = slug; page.value = 1; loadPosts() }
function selectTag(tag) { activeTag.value = tag; page.value = 1; loadPosts() }
function setSort(s) { sort.value = s; page.value = 1; loadPosts() }
function changePage(p) { page.value = p; loadPosts(); window.scrollTo(0,0) }
function openPost(id) { router.push(`/forum/post/${id}`) }
function onSearch() {
  clearTimeout(searchTimer)
  searchTimer = setTimeout(() => { page.value = 1; loadPosts() }, 300)
}
function clearFilters() {
  search.value = ''
  activeCat.value = null
  activeTag.value = ''
  page.value = 1
  loadPosts()
}

function postPayload() {
  return {
    ...newPost.value,
    tags: tagInput.value.split(/[,，\s]+/).map(x => x.trim()).filter(Boolean),
    image_urls: imageInput.value.split(/\n+/).map(x => x.trim()).filter(Boolean),
  }
}

async function submitPost() {
  if (!newPost.value.title.trim()) { postError.value = '标题不能为空'; return }
  posting.value = true
  postError.value = ''
  try {
    const p = await forumApi.createPost(postPayload())
    if (draftId.value) {
      try { await forumApi.deleteDraft(draftId.value) } catch {}
    }
    showNewPost.value = false
    resetComposer()
    router.push(`/forum/post/${p.id}`)
  } catch (e) {
    postError.value = e.message
  } finally {
    posting.value = false
  }
}

function resetComposer() {
  newPost.value = { category_id: categories.value[0]?.id || '', title: '', body: '', tags: [], image_urls: [] }
  tagInput.value = ''
  imageInput.value = ''
  draftId.value = ''
}

async function saveDraft() {
  posting.value = true
  try {
    const payload = postPayload()
    if (draftId.value) await forumApi.updateDraft(draftId.value, payload)
    else {
      const d = await forumApi.createDraft(payload)
      draftId.value = d.id
    }
    await loadDrafts()
    postError.value = '草稿已保存'
  } catch (e) {
    postError.value = e.message
  } finally {
    posting.value = false
  }
}

function loadDraft(d) {
  draftId.value = d.id
  newPost.value = { category_id: d.category_id || categories.value[0]?.id || '', title: d.title, body: d.body, tags: d.tags || [], image_urls: d.image_urls || [] }
  tagInput.value = (d.tags || []).join(', ')
  imageInput.value = (d.image_urls || []).join('\n')
}

async function loadDrafts() {
  if (!auth.isLoggedIn) return
  drafts.value = await forumApi.drafts()
}

async function loadNotifications() {
  if (!auth.isLoggedIn) return
  const res = await forumApi.notifications()
  notifications.value = res.notifications
  unread.value = res.unread
}

async function openNotifications() {
  await loadNotifications()
  showNotifications.value = true
}

async function markRead() {
  await forumApi.markNotificationsRead()
  await loadNotifications()
}

function openNotice(n) {
  if (n.link_url) {
    if (n.link_url.startsWith('http')) window.open(n.link_url, '_blank', 'noopener')
    else router.push(n.link_url)
    showNotifications.value = false
    return
  }
  if (n.target_type === 'post' && n.target_id) router.push(`/forum/post/${n.target_id}`)
  else if (n.target_type === 'record' && n.target_id) router.push(`/records/${n.target_id}`)
  showNotifications.value = false
}

onMounted(async () => {
  await loadCategories()
  await loadDrafts()
  await loadNotifications()
  await loadPosts()
})
</script>

<style scoped>
.forum-head { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
.head-actions { display: flex; gap: 8px; flex-wrap: wrap; justify-content: flex-end; }
.forum-sub { color: var(--muted); font-size: 13px; }
.forum-layout { display: grid; grid-template-columns: 220px 1fr; gap: 16px; }
.cat-sidebar { position: sticky; top: 72px; align-self: start; }
.cat-list { display: flex; flex-direction: column; gap: 2px; }
.cat-item { display: flex; align-items: center; gap: 8px; padding: 9px 10px; border-radius: 7px; cursor: pointer; transition: all .15s; }
.cat-item:hover { background: var(--surface2); }
.cat-item.active { background: rgba(249,115,22,.12); }
.cat-item.active .cat-name { color: var(--accent); font-weight: 600; }
.cat-icon { font-size: 16px; }
.cat-name { flex: 1; font-size: 13px; }
.cat-count { font-size: 11px; color: var(--muted); font-family: 'Space Mono', monospace; }

.post-toolbar { display: flex; justify-content: space-between; align-items: center; gap: 12px; margin-bottom: 12px; }
.forum-controls { display: flex; align-items: center; gap: 8px; min-width: 0; }
.forum-search { width: 260px; max-width: 100%; }
.sort-tabs { display: flex; gap: 4px; }
.sort-tabs button { background: transparent; border: 1px solid var(--border); color: var(--muted); padding: 5px 14px; border-radius: 6px; cursor: pointer; font-size: 13px; font-family: inherit; }
.sort-tabs button.active { background: var(--accent); color: #fff; border-color: var(--accent); }
.post-count { font-size: 12px; color: var(--muted); }
.clear-filter { margin-left: 8px; background: transparent; border: 0; color: var(--accent2); cursor: pointer; font-family: inherit; font-size: 12px; }

.post-list { display: flex; flex-direction: column; gap: 8px; }
.post-card { display: flex; gap: 12px; padding: 14px; background: var(--surface); border: 1px solid var(--border); border-radius: 10px; cursor: pointer; transition: all .15s; }
.post-card:hover { border-color: var(--accent2); transform: translateY(-1px); }
.post-avatar { font-size: 26px; flex-shrink: 0; }
.post-body { flex: 1; min-width: 0; }
.post-card-title { font-size: 15px; font-weight: 600; margin-bottom: 6px; display: flex; align-items: center; gap: 6px; }
.pin-tag { font-size: 10px; background: var(--accent); color: #fff; padding: 1px 6px; border-radius: 4px; font-weight: 700; }
.lock-tag { font-size: 12px; }
.post-meta { display: flex; gap: 12px; font-size: 12px; color: var(--muted); flex-wrap: wrap; }
.cat-badge { color: var(--accent2); }
.tag-row { display: flex; gap: 6px; flex-wrap: wrap; margin-top: 8px; }
.tag-chip, .draft-chip { border: 1px solid var(--border); background: var(--surface2); color: var(--accent2); border-radius: 6px; padding: 3px 8px; font-size: 11px; cursor: pointer; font-family: inherit; }
.tag-filter { color: var(--accent2); margin-left: 8px; }
.draft-list { display: flex; flex-wrap: wrap; gap: 6px; margin: 8px 0; }
.post-stats { display: flex; flex-direction: column; gap: 4px; align-items: flex-end; font-size: 12px; color: var(--muted); flex-shrink: 0; }
.pstat.liked { color: var(--red); }

.empty { text-align: center; padding: 60px 20px; color: var(--muted); font-size: 14px; }
.pager { display: flex; justify-content: center; align-items: center; gap: 16px; margin-top: 20px; }
.pager-info { font-size: 13px; color: var(--muted); font-family: 'Space Mono', monospace; }

.modal-mask { position: fixed; inset: 0; background: rgba(0,0,0,.6); display: flex; align-items: center; justify-content: center; z-index: 2000; padding: 16px; }
.modal { background: var(--surface); border: 1px solid var(--border); border-radius: 14px; padding: 24px; width: 100%; max-width: 540px; max-height: 90vh; overflow-y: auto; }
.modal-title { font-size: 18px; font-weight: 700; margin-bottom: 20px; }
.modal-actions { display: flex; justify-content: flex-end; gap: 10px; margin-top: 20px; }
.modal textarea { width: 100%; resize: vertical; }
.modal select { width: 100%; }
.notice-list { display: flex; flex-direction: column; gap: 8px; max-height: 50vh; overflow: auto; }
.notice-item { border: 1px solid var(--border); border-radius: 8px; padding: 10px; cursor: pointer; }
.notice-item.unread { border-color: var(--accent2); background: rgba(59,130,246,.08); }
.notice-title { font-weight: 700; font-size: 13px; }
.notice-body, .notice-time { color: var(--muted); font-size: 12px; margin-top: 4px; }

@media (max-width: 768px) {
  .forum-layout { grid-template-columns: 1fr; }
  .cat-sidebar { position: static; }
  .cat-list { flex-direction: row; flex-wrap: wrap; }
  .cat-item { flex: 0 0 auto; }
  .forum-head { align-items: flex-start; gap: 12px; }
  .post-toolbar { align-items: stretch; flex-direction: column; }
  .forum-controls { flex-direction: column; align-items: stretch; }
  .forum-search { width: 100%; }
  .sort-tabs button { flex: 1; }
  .post-card { align-items: flex-start; }
  .post-card-title { font-size: 14px; line-height: 1.4; }
  .post-stats { align-items: flex-start; font-size: 11px; }
}
</style>
