﻿<template>
  <div class="page visa-page">
    <div class="visa-hero">
      <div>
        <div class="eyebrow">J-1 Visa Interview</div>
        <h1>美签面签助手</h1>
        <p>面签题库绑定当前 SWT 平台账号，登录后可跨设备同步。题库数据保存到平台数据库，不依赖当前浏览器。</p>
      </div>
      <div class="hero-stats">
        <div><b>{{ stats.total }}</b><span>总题数</span></div>
        <div><b>{{ stats.intern }}</b><span>Intern</span></div>
        <div><b>{{ stats.trainee }}</b><span>Trainee</span></div>
        <div><b>{{ stats.both }}</b><span>通用</span></div>
      </div>
    </div>

    <div v-if="error" class="inline-error">{{ error }}</div>

    <div class="visa-tabs">
      <button :class="['tab-btn', { active: activeTab === 'manage' }]" @click="activeTab = 'manage'">题库管理</button>
      <button :class="['tab-btn', { active: activeTab === 'quiz' }]" @click="activeTab = 'quiz'">随机练习</button>
    </div>

    <div v-if="loading" class="panel empty-box">加载题库中…</div>

    <template v-else>
      <section v-if="activeTab === 'manage'" class="visa-grid">
        <div class="panel visa-panel">
          <div class="panel-title">添加题目</div>
          <div class="form-group">
            <label>问题 / 多种问法</label>
            <textarea v-model="form.question" rows="4" placeholder="Why do you want to go to America?"></textarea>
          </div>
          <div class="form-group">
            <label>参考答案</label>
            <textarea v-model="form.answer" rows="6" placeholder="I am going to..."></textarea>
          </div>
          <div class="form-row">
            <div class="form-group">
              <label>适用项目</label>
              <select v-model="form.category">
                <option value="both">通用</option>
                <option value="intern">Intern</option>
                <option value="trainee">Trainee</option>
              </select>
            </div>
            <div class="form-group">
              <label>标签</label>
              <input v-model="form.tag" placeholder="目的、薪资、回国计划…" />
            </div>
          </div>
          <button class="btn btn-primary" :disabled="saving" @click="addCard">{{ saving ? '保存中…' : '保存题目' }}</button>
        </div>

        <div class="panel visa-panel">
          <div class="panel-title">默认模板与数据</div>
          <div class="template-list">
            <button v-for="tpl in templates" :key="tpl.id" class="template-card" @click="importTemplate(tpl)">
              <b>{{ tpl.name }}</b>
              <span>{{ tpl.description }}</span>
              <em>{{ tpl.card_count }} 题 · 点击导入并替换当前题库</em>
            </button>
          </div>
          <div class="data-actions">
            <button class="btn btn-outline" @click="exportCards">导出 JSON</button>
            <label class="btn btn-outline file-btn">
              导入 JSON
              <input type="file" accept="application/json" @change="importCards" />
            </label>
            <button class="btn btn-danger" @click="clearCards">清空题库</button>
          </div>
          <p class="hint">导入模板、导入 JSON 和清空题库都会替换当前账号的数据库题库。</p>
        </div>
      </section>

      <section v-if="activeTab === 'manage'" class="panel list-panel">
        <div class="toolbar">
          <input v-model="search" placeholder="搜索问题、答案或标签…" />
          <select v-model="filterCategory">
            <option value="all">全部类别</option>
            <option value="both">通用</option>
            <option value="intern">Intern</option>
            <option value="trainee">Trainee</option>
          </select>
        </div>

        <div v-if="filteredCards.length === 0" class="empty-box">暂无匹配题目。可以添加新题目或导入默认模板。</div>
        <div v-else class="card-list">
          <article v-for="card in filteredCards" :key="card.id" class="qa-card">
            <template v-if="editingId === card.id">
              <textarea v-model="editForm.question" rows="3"></textarea>
              <textarea v-model="editForm.answer" rows="5"></textarea>
              <div class="form-row compact">
                <select v-model="editForm.category">
                  <option value="both">通用</option>
                  <option value="intern">Intern</option>
                  <option value="trainee">Trainee</option>
                </select>
                <input v-model="editForm.tag" placeholder="标签" />
              </div>
              <div class="card-actions">
                <button class="btn btn-primary" :disabled="saving" @click="saveEdit(card.id)">保存</button>
                <button class="btn btn-outline" @click="editingId = ''">取消</button>
              </div>
            </template>
            <template v-else>
              <div class="qa-head">
                <h3>{{ card.question }}</h3>
                <div class="card-actions">
                  <button class="btn btn-outline" @click="startEdit(card)">编辑</button>
                  <button class="btn btn-danger" @click="deleteCard(card.id)">删除</button>
                </div>
              </div>
              <p>{{ card.answer }}</p>
              <div class="meta-row">
                <span :class="['visa-pill', card.category]">{{ categoryLabel(card.category) }}</span>
                <span v-if="card.tag" class="tag"># {{ card.tag }}</span>
              </div>
            </template>
          </article>
        </div>
      </section>

      <section v-if="activeTab === 'quiz'" class="panel quiz-panel">
        <template v-if="!quizStarted">
          <div class="panel-title">练习设置</div>
          <div class="quiz-setup">
            <div class="form-group">
              <label>练习范围</label>
              <select v-model="quizCategory">
                <option value="all">全部</option>
                <option value="both">通用</option>
                <option value="intern">Intern</option>
                <option value="trainee">Trainee</option>
              </select>
            </div>
            <div class="form-group">
              <label>抽取题数：{{ effectiveQuizCount }}</label>
              <input v-model.number="quizCount" type="range" min="1" :max="maxQuizCount" />
              <span class="hint">当前范围共 {{ quizPool.length }} 题</span>
            </div>
            <button class="btn btn-primary" @click="startQuiz">随机抽题，开始练习</button>
          </div>
        </template>

        <template v-else>
          <div class="quiz-top">
            <div class="progress-dots">
              <span v-for="(_, i) in quizCards" :key="i" :class="{ done: i < quizIndex, current: i === quizIndex }"></span>
            </div>
            <button class="btn btn-outline" @click="resetQuiz">重新设置</button>
          </div>

          <article class="practice-card">
            <div class="meta-row">
              <span>题目 {{ quizIndex + 1 }} / {{ quizCards.length }}</span>
              <span :class="['visa-pill', currentCard.category]">{{ categoryLabel(currentCard.category) }}</span>
              <span v-if="currentCard.tag" class="tag"># {{ currentCard.tag }}</span>
            </div>
            <h2>{{ currentCard.question }}</h2>
            <textarea v-model="userAnswer" rows="5" placeholder="先用英文写下或默想你的回答，再查看参考答案…"></textarea>
            <button class="btn btn-primary" @click="showAnswer = !showAnswer">{{ showAnswer ? '隐藏参考答案' : '显示参考答案' }}</button>
            <div v-if="showAnswer" class="answer-box">
              <b>参考答案</b>
              <p>{{ currentCard.answer }}</p>
            </div>
          </article>

          <div class="quiz-nav">
            <button class="btn btn-outline" :disabled="quizIndex === 0" @click="previousQuestion">上一题</button>
            <button class="btn btn-primary" @click="nextQuestion">{{ quizIndex === quizCards.length - 1 ? '完成练习' : '下一题' }}</button>
          </div>
        </template>
      </section>
    </template>
  </div>
</template>

<script setup>
import { computed, onMounted, reactive, ref } from 'vue'
import { visaCardsApi } from '../api/index.js'

const activeTab = ref('manage')
const cards = ref([])
const templates = ref([])
const loading = ref(true)
const saving = ref(false)
const error = ref('')
const search = ref('')
const filterCategory = ref('all')
const editingId = ref('')
const editForm = reactive({ question: '', answer: '', category: 'both', tag: '' })
const form = reactive({ question: '', answer: '', category: 'both', tag: '' })
const quizCategory = ref('all')
const quizCount = ref(5)
const quizStarted = ref(false)
const quizCards = ref([])
const quizIndex = ref(0)
const showAnswer = ref(false)
const userAnswer = ref('')

const stats = computed(() => ({
  total: cards.value.length,
  intern: cards.value.filter(card => card.category === 'intern').length,
  trainee: cards.value.filter(card => card.category === 'trainee').length,
  both: cards.value.filter(card => card.category === 'both').length,
}))

const filteredCards = computed(() => {
  const keyword = search.value.trim().toLowerCase()
  return cards.value.filter(card => {
    const matchCategory = filterCategory.value === 'all' || card.category === filterCategory.value
    const matchText = !keyword || [card.question, card.answer, card.tag].some(value => String(value || '').toLowerCase().includes(keyword))
    return matchCategory && matchText
  })
})

const quizPool = computed(() => cards.value.filter(card => quizCategory.value === 'all' || card.category === quizCategory.value || card.category === 'both'))
const maxQuizCount = computed(() => Math.max(1, quizPool.value.length))
const effectiveQuizCount = computed(() => Math.min(quizCount.value, maxQuizCount.value))
const currentCard = computed(() => quizCards.value[quizIndex.value] || {})

onMounted(loadData)

async function loadData() {
  loading.value = true
  error.value = ''
  try {
    const [templateData, cardData] = await Promise.all([
      visaCardsApi.templates(),
      visaCardsApi.list(),
    ])
    templates.value = templateData
    cards.value = cardData
  } catch (e) {
    error.value = e.message || '加载面签题库失败'
  } finally {
    loading.value = false
  }
}

function categoryLabel(category) {
  return { both: '通用', intern: 'Intern', trainee: 'Trainee' }[category] || category
}

function cleanPayload(card) {
  return {
    question: String(card.question || '').trim(),
    answer: String(card.answer || '').trim(),
    category: card.category || 'both',
    tag: String(card.tag || '').trim(),
  }
}

async function addCard() {
  const payload = cleanPayload(form)
  if (!payload.question || !payload.answer) {
    error.value = '问题和参考答案不能为空'
    return
  }
  saving.value = true
  error.value = ''
  try {
    const created = await visaCardsApi.create(payload)
    cards.value.unshift(created)
    Object.assign(form, { question: '', answer: '', category: 'both', tag: '' })
  } catch (e) {
    error.value = e.message
  } finally {
    saving.value = false
  }
}

function startEdit(card) {
  editingId.value = card.id
  Object.assign(editForm, card)
}

async function saveEdit(id) {
  const payload = cleanPayload(editForm)
  if (!payload.question || !payload.answer) {
    error.value = '问题和参考答案不能为空'
    return
  }
  saving.value = true
  error.value = ''
  try {
    const updated = await visaCardsApi.update(id, payload)
    cards.value = cards.value.map(card => card.id === id ? updated : card)
    editingId.value = ''
  } catch (e) {
    error.value = e.message
  } finally {
    saving.value = false
  }
}

async function deleteCard(id) {
  if (!window.confirm('确定删除这道题目吗？')) return
  error.value = ''
  try {
    await visaCardsApi.delete(id)
    cards.value = cards.value.filter(card => card.id !== id)
  } catch (e) {
    error.value = e.message
  }
}

async function importTemplate(template) {
  if (!window.confirm(`导入「${template.name}」会替换当前账号的题库，是否继续？`)) return
  saving.value = true
  error.value = ''
  try {
    await visaCardsApi.importTemplate(template.id)
    await loadCardsOnly()
    activeTab.value = 'manage'
  } catch (e) {
    error.value = e.message
  } finally {
    saving.value = false
  }
}

async function loadCardsOnly() {
  cards.value = await visaCardsApi.list()
}

async function clearCards() {
  if (!window.confirm('确定清空当前账号的题库吗？')) return
  error.value = ''
  try {
    await visaCardsApi.replace([])
    cards.value = []
  } catch (e) {
    error.value = e.message
  }
}

function exportCards() {
  const exportData = cards.value.map(({ question, answer, category, tag }) => ({ question, answer, category, tag }))
  const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' })
  const url = URL.createObjectURL(blob)
  const link = document.createElement('a')
  link.href = url
  link.download = `visa-cards-${new Date().toISOString().slice(0, 10)}.json`
  link.click()
  URL.revokeObjectURL(url)
}

async function importCards(event) {
  const file = event.target.files?.[0]
  event.target.value = ''
  if (!file) return
  if (!window.confirm('导入 JSON 会替换当前账号的题库，是否继续？')) return
  saving.value = true
  error.value = ''
  try {
    const data = JSON.parse(await file.text())
    if (!Array.isArray(data)) throw new Error('JSON 顶层必须是数组')
    const payload = data.map(cleanPayload)
    await visaCardsApi.replace(payload)
    await loadCardsOnly()
  } catch (e) {
    error.value = `导入失败：${e.message}`
  } finally {
    saving.value = false
  }
}

function shuffle(items) {
  const result = [...items]
  for (let index = result.length - 1; index > 0; index -= 1) {
    const swapIndex = Math.floor(Math.random() * (index + 1))
    ;[result[index], result[swapIndex]] = [result[swapIndex], result[index]]
  }
  return result
}

function startQuiz() {
  if (!quizPool.value.length) {
    error.value = '当前范围暂无题目'
    return
  }
  error.value = ''
  quizCards.value = shuffle(quizPool.value).slice(0, effectiveQuizCount.value)
  quizIndex.value = 0
  showAnswer.value = false
  userAnswer.value = ''
  quizStarted.value = true
}

function resetQuiz() {
  quizStarted.value = false
  quizCards.value = []
  quizIndex.value = 0
  showAnswer.value = false
  userAnswer.value = ''
}

function previousQuestion() {
  if (quizIndex.value === 0) return
  quizIndex.value -= 1
  showAnswer.value = false
  userAnswer.value = ''
}

function nextQuestion() {
  if (quizIndex.value >= quizCards.value.length - 1) {
    resetQuiz()
    activeTab.value = 'manage'
    return
  }
  quizIndex.value += 1
  showAnswer.value = false
  userAnswer.value = ''
}
</script>

<style scoped>
.visa-page { max-width: 1180px; }
.visa-hero { display: grid; grid-template-columns: minmax(0, 1fr) 360px; gap: 18px; align-items: stretch; margin-bottom: 16px; }
.visa-hero > div:first-child, .hero-stats, .visa-panel, .list-panel, .quiz-panel { background: var(--surface); border: 1px solid var(--border); border-radius: 14px; box-shadow: 0 12px 40px rgba(0,0,0,.12); }
.visa-hero > div:first-child { padding: 24px; background: linear-gradient(135deg, rgba(249,115,22,.16), rgba(59,130,246,.08)), var(--surface); }
.eyebrow { color: var(--accent); font-size: 12px; text-transform: uppercase; letter-spacing: .12em; font-weight: 800; margin-bottom: 8px; }
h1 { font-size: 28px; margin-bottom: 10px; }
.visa-hero p, .hint { color: var(--muted); font-size: 13px; line-height: 1.8; }
.inline-error { margin-bottom: 12px; color: var(--red); background: rgba(239,68,68,.1); border: 1px solid rgba(239,68,68,.25); border-radius: 10px; padding: 10px 12px; font-size: 13px; }
.hero-stats { display: grid; grid-template-columns: repeat(2, 1fr); gap: 1px; overflow: hidden; background: var(--border); }
.hero-stats div { background: var(--surface); padding: 18px; display: flex; flex-direction: column; gap: 4px; }
.hero-stats b { color: var(--accent); font-size: 28px; font-family: 'Space Mono', monospace; }
.hero-stats span { color: var(--muted); font-size: 12px; }
.visa-tabs { display: flex; gap: 8px; margin-bottom: 16px; }
.tab-btn { border: 1px solid var(--border); background: var(--surface); color: var(--muted); border-radius: 999px; padding: 8px 18px; cursor: pointer; font-weight: 700; }
.tab-btn.active { color: #fff; background: var(--accent); border-color: var(--accent); }
.visa-grid { display: grid; grid-template-columns: minmax(0, 1.1fr) minmax(320px, .9fr); gap: 16px; margin-bottom: 16px; }
.visa-panel, .list-panel, .quiz-panel { padding: 18px; }
.form-row { display: grid; grid-template-columns: 160px 1fr; gap: 12px; }
.form-row.compact { grid-template-columns: 150px 1fr; margin-bottom: 10px; }
.template-list { display: grid; gap: 10px; margin-bottom: 14px; }
.template-card { text-align: left; background: var(--surface2); color: var(--text); border: 1px solid var(--border); border-radius: 10px; padding: 12px; cursor: pointer; display: flex; flex-direction: column; gap: 5px; }
.template-card:hover { border-color: var(--accent); }
.template-card span, .template-card em { color: var(--muted); font-size: 12px; font-style: normal; line-height: 1.6; }
.data-actions, .toolbar, .quiz-top, .quiz-nav, .card-actions, .meta-row { display: flex; gap: 8px; align-items: center; flex-wrap: wrap; }
.file-btn { position: relative; overflow: hidden; }
.file-btn input { position: absolute; inset: 0; opacity: 0; cursor: pointer; }
.toolbar { margin-bottom: 14px; }
.toolbar input { flex: 1; min-width: 220px; }
.card-list { display: grid; gap: 12px; }
.qa-card, .practice-card { background: var(--surface2); border: 1px solid var(--border); border-radius: 12px; padding: 16px; }
.qa-head { display: flex; justify-content: space-between; gap: 12px; align-items: flex-start; }
.qa-card h3 { font-size: 15px; line-height: 1.6; }
.qa-card p { color: var(--muted); line-height: 1.8; margin: 10px 0; white-space: pre-wrap; }
.qa-card textarea, .practice-card textarea { width: 100%; margin-bottom: 10px; }
.visa-pill { border-radius: 999px; padding: 3px 8px; font-size: 11px; font-weight: 800; border: 1px solid transparent; }
.visa-pill.both { color: #a855f7; background: rgba(168,85,247,.12); border-color: rgba(168,85,247,.25); }
.visa-pill.intern { color: var(--accent2); background: rgba(59,130,246,.12); border-color: rgba(59,130,246,.25); }
.visa-pill.trainee { color: var(--amber); background: rgba(245,158,11,.12); border-color: rgba(245,158,11,.25); }
.tag { color: var(--muted); font-size: 12px; }
.empty-box { padding: 36px 12px; text-align: center; color: var(--muted); border: 1px dashed var(--border); border-radius: 12px; }
.quiz-setup { max-width: 520px; }
.progress-dots { display: flex; gap: 6px; flex-wrap: wrap; flex: 1; }
.progress-dots span { width: 10px; height: 10px; border-radius: 999px; background: var(--border); }
.progress-dots span.done { background: var(--accent3); }
.progress-dots span.current { background: var(--accent); }
.practice-card { margin: 16px 0; }
.practice-card h2 { font-size: 22px; line-height: 1.6; margin: 12px 0; }
.answer-box { margin-top: 14px; padding: 14px; border-radius: 10px; border: 1px solid rgba(16,185,129,.35); background: rgba(16,185,129,.1); }
.answer-box p { margin-top: 8px; white-space: pre-wrap; line-height: 1.8; }
@media (max-width: 900px) { .visa-hero, .visa-grid, .form-row, .form-row.compact { grid-template-columns: 1fr; } .hero-stats { grid-template-columns: repeat(4, 1fr); } .qa-head { flex-direction: column; } }
@media (max-width: 560px) { .hero-stats { grid-template-columns: repeat(2, 1fr); } .data-actions .btn, .card-actions .btn, .quiz-nav .btn { flex: 1; } }
</style>
