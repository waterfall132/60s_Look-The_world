<template>
  <div class="page">
    <div class="page-title">📝 我的帖子</div>

    <div v-if="loading" class="empty">加载中…</div>
    <div v-else-if="posts.length === 0" class="empty">
      你还没有发过帖子
      <div style="margin-top:16px">
        <router-link to="/forum" class="btn btn-primary" style="text-decoration:none">去论坛发帖</router-link>
      </div>
    </div>

    <div v-else class="post-list">
      <div v-for="p in posts" :key="p.id" class="post-card">
        <div class="post-body" @click="openPost(p.id)">
          <div class="post-card-title">
            <span v-if="p.is_pinned" class="pin-tag">置顶</span>
            <span v-if="p.is_locked" class="lock-tag">🔒</span>
            {{ p.title }}
          </div>
          <div class="post-meta">
            <span class="cat-badge">{{ p.category_name }}</span>
            <span>{{ formatTime(p.created_at) }}</span>
            <span>👁 {{ p.view_count }}</span>
          </div>
        </div>
        <button class="btn btn-danger" @click.stop="removePost(p)">删除</button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { forumApi } from '../api/index.js'

const router = useRouter()
const posts = ref([])
const loading = ref(true)

function formatTime(iso) {
  if (!iso) return ''
  return new Date(iso).toLocaleDateString('zh-CN')
}

async function load() {
  loading.value = true
  try {
    posts.value = await forumApi.myPosts()
  } catch (e) {
    console.error(e)
  } finally {
    loading.value = false
  }
}

function openPost(id) { router.push(`/forum/post/${id}`) }

async function removePost(p) {
  if (!confirm(`确定删除「${p.title}」？`)) return
  try {
    await forumApi.deletePost(p.id)
    posts.value = posts.value.filter(x => x.id !== p.id)
  } catch (e) {
    alert(e.message)
  }
}

onMounted(load)
</script>

<style scoped>
.post-list { display: flex; flex-direction: column; gap: 8px; }
.post-card { display: flex; gap: 12px; align-items: center; padding: 14px; background: var(--surface); border: 1px solid var(--border); border-radius: 10px; }
.post-body { flex: 1; min-width: 0; cursor: pointer; }
.post-card-title { font-size: 15px; font-weight: 600; margin-bottom: 6px; display: flex; align-items: center; gap: 6px; }
.post-card:hover .post-card-title { color: var(--accent2); }
.pin-tag { font-size: 10px; background: var(--accent); color: #fff; padding: 1px 6px; border-radius: 4px; font-weight: 700; }
.lock-tag { font-size: 12px; }
.post-meta { display: flex; gap: 12px; font-size: 12px; color: var(--muted); flex-wrap: wrap; }
.cat-badge { color: var(--accent2); }
.empty { text-align: center; padding: 60px 20px; color: var(--muted); font-size: 14px; }
</style>
