<template>
  <div class="page">
    <div class="back-bar">
      <a class="back-link" @click="$router.back()">← 返回</a>
      <router-link to="/table" class="back-link">数据明细</router-link>
    </div>

    <div v-if="loading" class="empty">加载中…</div>
    <div v-else-if="!record" class="empty">记录不存在或已被删除</div>

    <template v-else>
      <div class="panel detail-panel">
        <div class="detail-head">
          <div>
            <div class="title-row">
              <span :class="'sev-badge sev-'+(record.severity || 0)">{{ record.severity || '?' }}</span>
              <h1>{{ record.job_position || record.location_name || '避雷记录' }}</h1>
            </div>
            <div class="meta-row">
              <span>{{ record.location_name || '未知地点' }}</span>
              <span>{{ record.state || '—' }}</span>
              <span>{{ sourceLabel(record.source_type) }}</span>
              <span :class="['review-chip', record.review_status]">{{ reviewLabel(record.review_status) }}</span>
            </div>
          </div>
          <div class="action-row">
            <button class="btn btn-outline" @click="toggleFavorite">
              {{ record.favorited ? '取消收藏' : '收藏记录' }}
            </button>
            <button class="btn btn-outline" @click="openFeedback">反馈/纠错</button>
          </div>
        </div>

        <div class="metric-grid">
          <div class="metric"><span>时薪</span><b>{{ record.hourly_wage ? '$' + record.hourly_wage : '—' }}</b></div>
          <div class="metric"><span>每日工时</span><b>{{ record.hours_per_day ? record.hours_per_day + 'h' : '—' }}</b></div>
          <div class="metric"><span>每周工时</span><b>{{ record.hours_per_week ? record.hours_per_week + 'h' : '—' }}</b></div>
          <div class="metric"><span>可信度</span><b>{{ Math.round((record.confidence || 0) * 100) }}%</b></div>
        </div>

        <div class="section">
          <div class="section-title">避雷原因</div>
          <span v-for="reason in (record.avoidance_reasons || [])" :key="reason" class="chip">{{ reason }}</span>
          <span v-if="!(record.avoidance_reasons || []).length" class="muted">暂无</span>
        </div>

        <div class="section">
          <div class="section-title">详细摘要</div>
          <p class="summary">{{ record.summary || '暂无摘要' }}</p>
        </div>

        <div class="detail-grid">
          <div><strong>雇主：</strong>{{ record.employer || '（VIP 可见）' }}</div>
          <div><strong>城市：</strong>{{ record.city || '—' }}</div>
          <div><strong>小费：</strong>{{ record.tips || '—' }}</div>
          <div><strong>更新时间：</strong>{{ formatTime(record.updated_at) }}</div>
        </div>

        <div v-if="record.review_note" class="review-note">
          <strong>审核备注：</strong>{{ record.review_note }}
        </div>

        <div class="source-row">
          <a v-if="record.note_url" :href="record.note_url" target="_blank" rel="noopener" class="btn btn-primary">查看原帖</a>
          <span v-else class="muted">原帖链接仅 VIP 可见或暂无链接</span>
        </div>
      </div>
    </template>

    <div v-if="feedbackModal" class="modal-overlay" @click="feedbackModal = false">
      <div class="feedback-modal" @click.stop>
        <h3>反馈/纠错</h3>
        <div class="form-group">
          <label>问题类型</label>
          <select v-model="feedback.reason">
            <option value="信息不准确">信息不准确</option>
            <option value="重复记录">重复记录</option>
            <option value="原帖链接失效">原帖链接失效</option>
            <option value="涉嫌隐私/侵权">涉嫌隐私/侵权</option>
            <option value="补充信息">补充信息</option>
          </select>
        </div>
        <div class="form-group">
          <label>说明</label>
          <textarea v-model="feedback.detail" rows="4" placeholder="请说明需要修正的内容"></textarea>
        </div>
        <div class="action-row">
          <button class="btn btn-outline" @click="feedbackModal = false">取消</button>
          <button class="btn btn-primary" :disabled="feedbackSaving" @click="submitFeedback">
            {{ feedbackSaving ? '提交中…' : '提交反馈' }}
          </button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { recordsApi } from '../api/index.js'
import { useAuthStore } from '../stores/auth.js'

const route = useRoute()
const router = useRouter()
const auth = useAuthStore()
const record = ref(null)
const loading = ref(true)
const feedbackModal = ref(false)
const feedbackSaving = ref(false)
const feedback = reactive({ reason: '信息不准确', detail: '' })

const REVIEW_LABELS = {
  pending: '待审核',
  verified: '已核验',
  needs_review: '需复核',
  rejected: '已驳回',
}

function reviewLabel(status) {
  return REVIEW_LABELS[status || 'pending'] || '待审核'
}

function sourceLabel(type) {
  if (type === 'comment') return '评论来源'
  if (type === 'user') return '用户上报'
  return '帖子来源'
}

function formatTime(iso) {
  return iso ? new Date(iso).toLocaleString('zh-CN') : '—'
}

async function load() {
  loading.value = true
  try {
    record.value = await recordsApi.get(route.params.id)
  } catch {
    record.value = null
  } finally {
    loading.value = false
  }
}

async function toggleFavorite() {
  if (!auth.isLoggedIn) {
    router.push({ path: '/login', query: { redirect: route.fullPath } })
    return
  }
  const res = await recordsApi.toggleFavorite(record.value.id)
  record.value.favorited = res.favorited
}

function openFeedback() {
  if (!auth.isLoggedIn) {
    router.push({ path: '/login', query: { redirect: route.fullPath } })
    return
  }
  feedback.reason = '信息不准确'
  feedback.detail = ''
  feedbackModal.value = true
}

async function submitFeedback() {
  feedbackSaving.value = true
  try {
    await recordsApi.feedback(record.value.id, { ...feedback })
    feedbackModal.value = false
    alert('反馈已提交')
  } catch (e) {
    alert(e.message)
  } finally {
    feedbackSaving.value = false
  }
}

onMounted(load)
</script>

<style scoped>
.back-bar { display: flex; gap: 12px; margin-bottom: 12px; }
.back-link { color: var(--accent2); cursor: pointer; font-size: 13px; text-decoration: none; }
.detail-panel { padding: 22px; }
.detail-head { display: flex; justify-content: space-between; gap: 16px; align-items: flex-start; }
.title-row { display: flex; gap: 10px; align-items: center; flex-wrap: wrap; }
.title-row h1 { font-size: 24px; line-height: 1.3; margin: 0; }
.meta-row, .action-row { display: flex; gap: 8px; flex-wrap: wrap; align-items: center; }
.meta-row { color: var(--muted); font-size: 13px; margin-top: 8px; }
.metric-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 10px; margin: 20px 0; }
.metric { background: var(--surface2); border-radius: 8px; padding: 12px; }
.metric span { color: var(--muted); font-size: 12px; display: block; margin-bottom: 6px; }
.metric b { font-family: 'Space Mono', monospace; color: var(--accent); }
.section { border-top: 1px solid var(--border); padding-top: 16px; margin-top: 16px; }
.section-title { font-weight: 700; font-size: 13px; margin-bottom: 10px; }
.summary { white-space: pre-wrap; line-height: 1.8; font-size: 14px; }
.detail-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-top: 18px; font-size: 14px; }
.review-note { margin-top: 16px; padding: 10px 12px; background: var(--surface2); border-radius: 8px; font-size: 13px; }
.source-row { margin-top: 18px; }
.muted { color: var(--muted); font-size: 13px; }
.review-chip { border-radius: 99px; padding: 2px 8px; border: 1px solid var(--border); font-size: 11px; }
.review-chip.verified { color: var(--accent3); border-color: var(--accent3); }
.review-chip.needs_review { color: var(--amber); border-color: var(--amber); }
.review-chip.rejected { color: var(--red); border-color: var(--red); }
.modal-overlay { position: fixed; inset: 0; background: rgba(0,0,0,.6); display: flex; align-items: center; justify-content: center; z-index: 2000; padding: 16px; }
.feedback-modal { background: var(--surface); border: 1px solid var(--border); border-radius: 12px; padding: 20px; width: min(520px, 100%); }
.feedback-modal h3 { margin-bottom: 16px; }
.feedback-modal textarea { width: 100%; resize: vertical; }
@media (max-width: 768px) {
  .detail-head { flex-direction: column; }
  .metric-grid, .detail-grid { grid-template-columns: 1fr; }
}
</style>
