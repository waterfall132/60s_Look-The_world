<template>
  <div class="page">
    <div class="auth-card">
      <h2>找回密码</h2>
      <div class="sub">通过注册邮箱重置密码</div>

      <div class="form-group">
        <label>注册邮箱</label>
        <input v-model="email" type="email" placeholder="your@email.com" />
      </div>

      <div class="form-group">
        <label>邮箱验证码</label>
        <div class="code-row">
          <input v-model="code" placeholder="6 位验证码" maxlength="6" />
          <button class="btn btn-outline code-btn" :disabled="countdown > 0 || sending" @click="sendCode">
            {{ countdown > 0 ? `${countdown}s 后重发` : (sending ? '发送中…' : '获取验证码') }}
          </button>
        </div>
        <div v-if="devCode" class="dev-code">
          🛠 开发模式验证码：<b>{{ devCode }}</b>
        </div>
      </div>

      <div class="form-group">
        <label>新密码 <small>(至少 6 位)</small></label>
        <input v-model="newPassword" type="password" @keyup.enter="doReset" placeholder="设置新密码" />
      </div>

      <button class="btn btn-primary" style="width:100%" :disabled="loading" @click="doReset">
        {{ loading ? '重置中…' : '重置密码' }}
      </button>

      <div v-if="error" class="form-error">{{ error }}</div>
      <div v-if="success" class="form-success">{{ success }}</div>
      <div class="form-foot">
        想起来了？<router-link to="/login">返回登录</router-link>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onUnmounted } from 'vue'
import { useRouter } from 'vue-router'
import { authApi } from '../api/index.js'

const router = useRouter()
const email = ref('')
const code = ref('')
const newPassword = ref('')
const loading = ref(false)
const sending = ref(false)
const error = ref('')
const success = ref('')
const countdown = ref(0)
const devCode = ref('')
let timer = null

function isValidEmail(e) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e)
}

async function sendCode() {
  error.value = ''
  if (!isValidEmail(email.value)) { error.value = '请输入有效的邮箱地址'; return }
  sending.value = true
  try {
    const res = await authApi.sendCode({ email: email.value.trim(), purpose: 'reset_password' })
    if (res.dev_code) devCode.value = res.dev_code
    countdown.value = 60
    timer = setInterval(() => {
      countdown.value--
      if (countdown.value <= 0) clearInterval(timer)
    }, 1000)
  } catch (e) {
    error.value = e.message
  } finally {
    sending.value = false
  }
}

async function doReset() {
  error.value = ''
  success.value = ''
  if (!isValidEmail(email.value)) { error.value = '请输入有效的邮箱地址'; return }
  if (!code.value.trim()) { error.value = '请填写验证码'; return }
  if (newPassword.value.length < 6) { error.value = '新密码至少 6 位'; return }
  loading.value = true
  try {
    await authApi.forgotPassword({
      email: email.value.trim(),
      code: code.value.trim(),
      new_password: newPassword.value,
    })
    success.value = '密码已重置，正在跳转登录…'
    setTimeout(() => router.push('/login'), 1500)
  } catch (e) {
    error.value = e.message
  } finally {
    loading.value = false
  }
}

onUnmounted(() => { if (timer) clearInterval(timer) })
</script>

<style scoped>
.code-row { display: flex; gap: 8px; }
.code-row input { flex: 1; }
.code-btn { white-space: nowrap; flex-shrink: 0; padding: 7px 12px; font-size: 12px; }
.dev-code { margin-top: 8px; padding: 8px 10px; background: rgba(16,185,129,.08); border: 1px dashed rgba(16,185,129,.4); border-radius: 6px; font-size: 12px; color: var(--accent3); }
.dev-code b { font-family: 'Space Mono', monospace; font-size: 14px; letter-spacing: 1px; }
.form-success { color: var(--accent3); font-size: 13px; margin-top: 12px; }
</style>
