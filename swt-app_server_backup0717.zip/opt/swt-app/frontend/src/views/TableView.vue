<template>
  <div class="page">
    <div v-if="limited" class="vip-banner">
      <span class="vb-icon">👑</span>
      <div>
        <div class="vb-title">当前为受限视图</div>
        <div class="vb-desc">普通用户仅可查看第一页数据（摘要截断、无原帖链接）。成为 VIP 解锁完整避雷记录。</div>
      </div>
      <router-link v-if="!auth.isLoggedIn" to="/register" class="btn btn-primary" style="text-decoration:none">注册</router-link>
      <span v-else style="font-size:12px;color:var(--amber)">联系管理员开通 VIP</span>
    </div>
    <div class="reader-hint">
      <span>先按州、严重度或关键词筛选，再点任意记录查看完整详情；这里只展示已通过审核的数据。</span>
      <button class="btn btn-primary" @click="openSubmitModal">上报新数据</button>
    </div>
    <!-- Filters -->
    <div class="filter-bar">
      <input v-model="filters.search" placeholder="🔍 搜索岗位/地点/理由..." style="width:220px" @input="onFilter" />
      <select v-model="filters.severity" @change="onFilter">
        <option value="">所有严重度</option>
        <option value="5">⛔ 严重度 5</option>
        <option value="4">🔴 严重度 4</option>
        <option value="3">🟡 严重度 3</option>
        <option value="2">🔵 严重度 2</option>
      </select>
      <select v-model="filters.state" @change="onFilter">
        <option value="">所有州</option>
        <option v-for="st in states" :key="st" :value="st">{{ st }}</option>
      </select>
      <select v-model="filters.source_type" @change="onFilter">
        <option value="">来源：全部</option>
        <option value="post">笔记正文</option>
        <option value="comment">评论</option>
      </select>
      <select v-model="filters.reason" @change="onFilter">
        <option value="">所有理由</option>
        <option v-for="r in reasonOptions" :key="r">{{ r }}</option>
      </select>
      <select v-model="filters.sort" @change="onFilter">
        <option value="severity_desc">严重度优先</option>
        <option value="updated_desc">最近更新</option>
        <option value="created_desc">最新导入</option>
        <option value="wage_desc">时薪最高</option>
        <option value="hours_desc">工时最高</option>
        <option value="confidence_desc">可信度最高</option>
      </select>
      <span style="color:var(--muted);font-size:12px;margin-left:auto;font-family:'Space Mono',monospace">
        {{ pagination.total }} 条
      </span>
    </div>

    <!-- Table -->
    <div class="table-wrap">
      <div v-if="loading" class="loading">加载中…</div>
      <div v-else-if="!records.length" class="empty">暂无记录，请先导入数据</div>
      <table v-else>
        <thead>
          <tr>
            <th style="width:160px">避雷摘要</th>
            <th>岗位</th>
            <th>地点</th>
            <th>时薪</th>
            <th>工时/天</th>
            <th style="min-width:180px">避雷理由</th>
            <th>严重度</th>
            <th>置信</th>
            <th>来源</th>
            <th>原帖</th>
            <th>操作</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="r in records" :key="r.id" @click="openRecord(r.id)" class="clickable-row">
            <td data-label="避雷摘要" style="max-width:160px">
              <div style="font-size:11px;color:var(--muted);overflow:hidden;text-overflow:ellipsis;white-space:nowrap" :title="r.summary">
                {{ (r.summary || '—').slice(0, 38) }}…
              </div>
            </td>
            <td data-label="岗位"><span class="chip chip-blue">{{ r.job_position || '—' }}</span></td>
            <td data-label="地点" style="color:var(--accent);font-weight:600;white-space:nowrap">{{ r.location_name || r.state || '—' }}</td>
            <td data-label="时薪" style="font-family:'Space Mono',monospace;color:var(--accent3)">{{ r.hourly_wage ? '$'+r.hourly_wage : '—' }}</td>
            <td data-label="工时/天" style="font-family:'Space Mono',monospace;text-align:center">{{ r.hours_per_day ? r.hours_per_day+'h' : '—' }}</td>
            <td data-label="避雷理由">
              <span v-for="reason in (r.avoidance_reasons || [])" :key="reason" class="chip">{{ reason }}</span>
            </td>
            <td data-label="严重度" style="text-align:center"><span :class="'sev-badge sev-'+(r.severity||0)">{{ r.severity || '?' }}</span></td>
            <td data-label="置信" style="font-family:'Space Mono',monospace;font-size:11px" :style="{ color: confColor(r.confidence) }">
              {{ Math.round((r.confidence || 0) * 100) }}%
            </td>
            <td data-label="来源">
              <span :class="['chip', r.source_type === 'comment' ? 'chip-green' : 'chip-blue']">
                {{ sourceLabel(r.source_type) }}
              </span>
            </td>
            <td data-label="原帖">
              <a v-if="r.note_url" :href="r.note_url" target="_blank" class="link-a" @click.stop>查看↗</a>
              <span v-else>—</span>
            </td>
            <td data-label="操作">
              <button class="mini-action" :class="{ active: r.favorited }" @click.stop="toggleFavorite(r)">
                {{ r.favorited ? '已收藏' : '收藏' }}
              </button>
              <button class="mini-action" @click.stop="openRecord(r.id)">详情</button>
            </td>
          </tr>
        </tbody>
      </table>
    </div>

    <!-- Pagination -->
    <div v-if="pagination.pages > 1" class="pagination">
      <button class="btn btn-outline" :disabled="pagination.page <= 1" @click="changePage(-1)">← 上一页</button>
      <span style="font-size:12px;color:var(--muted)">{{ pagination.page }} / {{ pagination.pages }}</span>
      <button class="btn btn-outline" :disabled="pagination.page >= pagination.pages || pageBlocked" @click="changePage(1)">
        {{ pageBlocked ? '🔒 VIP 专享' : '下一页 →' }}
      </button>
    </div>

    <!-- 详情弹窗 -->
    <div v-if="detailRecord" class="modal-overlay" @click="closeDetail">
      <div class="modal-content" @click.stop>
        <button class="close-btn" @click="closeDetail">✕</button>
        <h2 style="margin:0 0 20px 0;color:var(--text)">📋 避雷详情</h2>
        <div class="detail-grid">
          <div class="detail-item">
            <strong>岗位：</strong>{{ detailRecord.job_position || '—' }}
          </div>
          <div class="detail-item">
            <strong>地点：</strong>{{ detailRecord.location_name || '—' }}
          </div>
          <div class="detail-item">
            <strong>州：</strong>{{ detailRecord.state || '—' }}
          </div>
          <div class="detail-item">
            <strong>城市：</strong>{{ detailRecord.city || '—' }}
          </div>
          <div class="detail-item">
            <strong>时薪：</strong>{{ detailRecord.hourly_wage ? `$${detailRecord.hourly_wage}` : '—' }}
          </div>
          <div class="detail-item">
            <strong>小费：</strong>{{ detailRecord.tips || '—' }}
          </div>
          <div class="detail-item">
            <strong>每日时长：</strong>{{ detailRecord.hours_per_day ? `${detailRecord.hours_per_day}h` : '—' }}
          </div>
          <div class="detail-item">
            <strong>每周时长：</strong>{{ detailRecord.hours_per_week ? `${detailRecord.hours_per_week}h` : '—' }}
          </div>
          <div class="detail-item">
            <strong>严重度：</strong>{{ '⭐'.repeat(detailRecord.severity || 3) }}
          </div>
          <div class="detail-item">
            <strong>可信度：</strong>{{ Math.round((detailRecord.confidence || 0.8) * 100) }}%
          </div>
          <div class="detail-item full-width">
            <strong>雇主：</strong>{{ detailRecord.employer || '（VIP 可见）' }}
          </div>
          <div class="detail-item full-width">
            <strong>避雷原因：</strong>
            <div style="margin-top:8px">
              <span v-for="reason in (detailRecord.avoidance_reasons || [])" :key="reason" class="chip">{{ reason }}</span>
            </div>
          </div>
          <div class="detail-item full-width">
            <strong>详细摘要：</strong>
            <p class="summary-full">{{ detailRecord.summary || '—' }}</p>
          </div>
          <div class="detail-item full-width" v-if="detailRecord.note_url">
            <strong>原帖链接：</strong>
            <a :href="detailRecord.note_url" target="_blank" class="link-a">{{ detailRecord.note_url }}</a>
          </div>
          <div class="detail-item full-width" v-else>
            <strong>原帖链接：</strong>（VIP 可见）
          </div>
        </div>
        <div class="detail-actions">
          <button class="btn btn-outline" @click="toggleFavorite(detailRecord)">
            {{ detailRecord.favorited ? '取消收藏' : '收藏记录' }}
          </button>
          <button class="btn btn-outline" @click="openFeedback(detailRecord)">反馈/纠错</button>
        </div>
      </div>
    </div>

    <div v-if="feedbackModal.show" class="modal-overlay" @click="closeFeedback">
      <div class="feedback-modal" @click.stop>
        <button class="close-btn" @click="closeFeedback">✕</button>
        <h3>反馈/纠错</h3>
        <p class="feedback-sub">{{ feedbackModal.record?.summary || feedbackModal.record?.job_position || '当前记录' }}</p>
        <div class="form-group">
          <label>问题类型</label>
          <select v-model="feedbackForm.reason">
            <option value="信息不准确">信息不准确</option>
            <option value="重复记录">重复记录</option>
            <option value="原帖链接失效">原帖链接失效</option>
            <option value="涉嫌隐私/侵权">涉嫌隐私/侵权</option>
            <option value="补充信息">补充信息</option>
          </select>
        </div>
        <div class="form-group">
          <label>说明</label>
          <textarea v-model="feedbackForm.detail" rows="4" placeholder="请说明哪里需要修正，或补充你知道的信息"></textarea>
        </div>
        <div class="detail-actions">
          <button class="btn btn-outline" @click="closeFeedback">取消</button>
          <button class="btn btn-primary" :disabled="feedbackSaving" @click="submitFeedback">
            {{ feedbackSaving ? '提交中…' : '提交反馈' }}
          </button>
        </div>
      </div>
    </div>

    <div v-if="submitModal.show" class="modal-overlay" @click="closeSubmitModal">
      <div class="submit-modal" @click.stop>
        <button class="close-btn" @click="closeSubmitModal">✕</button>
        <h3>上报避雷数据</h3>
        <p class="feedback-sub">用户上报内容会先进入管理员审核，审核通过后才会发布到数据明细页面。</p>
        <div class="submit-grid">
          <div class="form-group"><label>岗位</label><input v-model="submitForm.job_position" placeholder="lifeguard / server..." /></div>
          <div class="form-group"><label>雇主</label><input v-model="submitForm.employer" placeholder="雇主或公司名称" /></div>
          <div class="form-group"><label>地点</label><input v-model="submitForm.location_name" placeholder="工作地点" /></div>
          <div class="form-group"><label>城市</label><input v-model="submitForm.city" placeholder="可选" /></div>
          <div class="form-group"><label>州缩写</label><input v-model="submitForm.state" maxlength="2" placeholder="TN" style="text-transform:uppercase" /></div>
          <div class="form-group"><label>时薪</label><input v-model.number="submitForm.hourly_wage" type="number" min="0" step="0.25" /></div>
          <div class="form-group"><label>每周工时</label><input v-model.number="submitForm.hours_per_week" type="number" min="0" /></div>
          <div class="form-group"><label>严重度</label><select v-model.number="submitForm.severity"><option v-for="s in [1,2,3,4,5]" :key="s" :value="s">{{ s }}</option></select></div>
          <div class="form-group full"><label>避雷理由</label><div class="reason-grid"><label v-for="r in reasonOptions" :key="r" class="reason-check"><input type="checkbox" :value="r" v-model="submitForm.avoidance_reasons" /><span>{{ r }}</span></label></div></div>
          <div class="form-group full"><label>经历摘要</label><textarea v-model="submitForm.summary" rows="4" placeholder="请尽量说明真实经历、时间、岗位、问题点"></textarea></div>
          <div class="form-group full"><label>来源链接/证据</label><input v-model="submitForm.note_url" placeholder="可选，原帖或相关链接" /></div>
        </div>
        <div class="detail-actions">
          <button class="btn btn-outline" @click="closeSubmitModal">取消</button>
          <button class="btn btn-primary" :disabled="submitSaving" @click="submitRecord">
            {{ submitSaving ? '提交中…' : '提交审核' }}
          </button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { useAuthStore } from '../stores/auth.js'
import { ref, reactive, onMounted, computed } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { recordsApi } from '../api/index.js'

const auth = useAuthStore()
const router = useRouter()
const route = useRoute()
const records = ref([])
const limited = ref(false)
const loading = ref(false)
const states = ref([])
const pagination = reactive({ page: 1, pages: 1, total: 0 })
const filters = reactive({ search: '', severity: '', state: '', source_type: '', reason: '', sort: 'severity_desc' })
const detailRecord = ref(null)
const feedbackSaving = ref(false)
const feedbackModal = reactive({ show: false, record: null })
const feedbackForm = reactive({ reason: '信息不准确', detail: '' })
const submitSaving = ref(false)
const submitModal = reactive({ show: false })
const submitForm = reactive(emptySubmitForm())

const reasonOptions = [
  '暴晒/户外高温', '工时过长', '休息不足', '岗位不符/被调岗',
  '小费低/收入不符', '管理/雇主问题', 'SSN/换岗流程困难',
  '被解雇/强制辞退', '住宿问题', '英语要求高', '工时被削减',
  '雇主歧视', '小费被盗/提前拿走'
]

const pageBlocked = computed(() => limited.value && pagination.page >= 1)

const confColor = (c) => (c >= .8 ? '#10b981' : c >= .6 ? '#f59e0b' : '#ef4444')
const sourceLabel = (type) => type === 'comment' ? '评论' : type === 'user' ? '用户上报' : '帖子'

function emptySubmitForm() {
  return {
    valuable: true,
    source_type: 'user',
    job_position: '',
    employer: '',
    location_name: '',
    city: '',
    state: '',
    hourly_wage: null,
    tips: '',
    hours_per_day: null,
    hours_per_week: null,
    avoidance_reasons: [],
    severity: 3,
    confidence: 0.5,
    summary: '',
    note_url: '',
  }
}

let searchTimer = null
function onFilter() {
  clearTimeout(searchTimer)
  searchTimer = setTimeout(() => { pagination.page = 1; load() }, 300)
}

async function load() {
  loading.value = true
  try {
    persistFilters()
    const res = await recordsApi.list({
      page: pagination.page,
      page_size: 25,
      search: filters.search || undefined,
      severity: filters.severity || undefined,
      state: filters.state || undefined,
      source_type: filters.source_type || undefined,
      reason: filters.reason || undefined,
      sort: filters.sort || 'severity_desc',
    })
    records.value = res.records
    limited.value = !!res.limited
    pagination.pages = res.pages
    pagination.total = res.total

    // Build state list from data
    if (!states.value.length) {
      const allStates = new Set()
      res.records.forEach(r => r.state && allStates.add(r.state))
      states.value = [...allStates].sort()
    }
  } catch (e) {
    if (e.response?.status === 403) {
      alert('⚠️ 仅 VIP 用户可查看更多数据，请升级账户')
    } else {
      console.error(e)
    }
  } finally {
    loading.value = false
  }
}

function changePage(delta) {
  pagination.page = Math.max(1, Math.min(pagination.pages, pagination.page + delta))
  load()
}

function openRecord(id) {
  router.push(`/records/${id}`)
}

function showDetail(record) {
  detailRecord.value = record
}

function closeDetail() {
  detailRecord.value = null
}

async function toggleFavorite(record) {
  if (!auth.isLoggedIn) {
    router.push('/login')
    return
  }
  try {
    const res = await recordsApi.toggleFavorite(record.id)
    record.favorited = res.favorited
    const inList = records.value.find(x => x.id === record.id)
    if (inList) inList.favorited = res.favorited
  } catch (e) {
    alert(e.message)
  }
}

function openFeedback(record) {
  if (!auth.isLoggedIn) {
    router.push('/login')
    return
  }
  feedbackModal.record = record
  feedbackForm.reason = '信息不准确'
  feedbackForm.detail = ''
  feedbackModal.show = true
}

function closeFeedback() {
  feedbackModal.show = false
  feedbackModal.record = null
}

async function submitFeedback() {
  if (!feedbackForm.reason && !feedbackForm.detail.trim()) return
  feedbackSaving.value = true
  try {
    await recordsApi.feedback(feedbackModal.record.id, {
      reason: feedbackForm.reason,
      detail: feedbackForm.detail,
    })
    closeFeedback()
    alert('反馈已提交，管理员会在后台处理')
  } catch (e) {
    alert(e.message)
  } finally {
    feedbackSaving.value = false
  }
}

function openSubmitModal() {
  if (!auth.isLoggedIn) {
    router.push({ path: '/login', query: { redirect: '/table' } })
    return
  }
  Object.assign(submitForm, emptySubmitForm())
  submitModal.show = true
}

function closeSubmitModal() {
  submitModal.show = false
}

async function submitRecord() {
  if (!submitForm.summary.trim() && !submitForm.employer.trim() && !submitForm.job_position.trim()) {
    alert('请至少填写岗位、雇主或经历摘要')
    return
  }
  submitSaving.value = true
  try {
    const payload = { ...submitForm, state: (submitForm.state || '').toUpperCase() }
    await recordsApi.submit(payload)
    closeSubmitModal()
    alert('已提交，管理员审核通过后会展示在数据明细页面')
  } catch (e) {
    alert(e.message)
  } finally {
    submitSaving.value = false
  }
}

onMounted(load)

function applySavedFilters() {
  const saved = JSON.parse(localStorage.getItem('swt_table_filters') || '{}')
  const source = Object.keys(route.query).length ? route.query : saved
  Object.assign(filters, {
    search: source.search || '',
    severity: source.severity || '',
    state: source.state || '',
    source_type: source.source_type || '',
    reason: source.reason || '',
    sort: source.sort || 'severity_desc',
  })
  pagination.page = Number(source.page || 1)
}

function persistFilters() {
  const query = {}
  for (const [key, value] of Object.entries(filters)) {
    if (value) query[key] = value
  }
  if (pagination.page > 1) query.page = String(pagination.page)
  localStorage.setItem('swt_table_filters', JSON.stringify({ ...query }))
  router.replace({ path: '/table', query })
}

applySavedFilters()
</script>

<style scoped>
.filter-bar { display: flex; gap: 8px; margin-bottom: 14px; flex-wrap: wrap; align-items: center; }
.reader-hint {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  flex-wrap: wrap;
  margin-bottom: 12px;
  padding: 10px 12px;
  border: 1px solid var(--border);
  border-radius: 8px;
  background: var(--surface);
  color: var(--muted);
  font-size: 13px;
  line-height: 1.6;
}
.table-wrap { overflow: auto; max-height: calc(100vh - 280px); border-radius: 8px; border: 1px solid var(--border); }
.loading, .empty { text-align: center; padding: 60px; color: var(--muted); }
.pagination { display: flex; gap: 12px; align-items: center; justify-content: center; margin-top: 16px; }

.clickable-row {
  cursor: pointer;
  transition: background-color 0.15s;
}

.clickable-row:hover {
  background-color: rgba(59, 130, 246, 0.05);
}

.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.6);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
  backdrop-filter: blur(2px);
}

.modal-content {
  background: var(--bg);
  border-radius: 12px;
  padding: 28px;
  max-width: 750px;
  max-height: 85vh;
  overflow-y: auto;
  position: relative;
  box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
  border: 1px solid var(--border);
}

.close-btn {
  position: absolute;
  top: 16px;
  right: 16px;
  background: none;
  border: none;
  font-size: 24px;
  cursor: pointer;
  color: var(--muted);
  width: 32px;
  height: 32px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 6px;
  transition: all 0.2s;
}

.close-btn:hover {
  background: var(--border);
  color: var(--text);
}

.detail-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 16px;
}

.detail-item {
  padding: 10px 0;
  border-bottom: 1px solid var(--border);
  font-size: 14px;
}

.detail-item.full-width {
  grid-column: 1 / -1;
}

.detail-item strong {
  color: var(--text);
  margin-right: 8px;
  font-weight: 600;
}

.summary-full {
  margin-top: 10px;
  line-height: 1.7;
  color: var(--text);
  white-space: pre-wrap;
  font-size: 13px;
}
.detail-actions { display: flex; justify-content: flex-end; gap: 10px; margin-top: 18px; flex-wrap: wrap; }
.mini-action {
  border: 1px solid var(--border);
  background: transparent;
  color: var(--accent2);
  border-radius: 6px;
  padding: 4px 8px;
  font-size: 11px;
  cursor: pointer;
  font-family: inherit;
}
.mini-action.active { color: var(--amber); border-color: var(--amber); background: rgba(245,158,11,.1); }
.feedback-modal {
  background: var(--bg);
  border: 1px solid var(--border);
  border-radius: 12px;
  padding: 24px;
  width: min(520px, calc(100vw - 24px));
  position: relative;
}
.feedback-modal h3 { margin-bottom: 8px; }
.feedback-sub { color: var(--muted); font-size: 13px; line-height: 1.6; margin-bottom: 16px; }
.feedback-modal textarea { width: 100%; resize: vertical; }
.submit-modal {
  background: var(--bg);
  border: 1px solid var(--border);
  border-radius: 12px;
  padding: 24px;
  width: min(780px, calc(100vw - 24px));
  max-height: 88vh;
  overflow: auto;
  position: relative;
}
.submit-modal h3 { margin-bottom: 8px; }
.submit-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
.submit-grid .full { grid-column: 1 / -1; }
.reason-grid { display: flex; flex-wrap: wrap; gap: 6px; }
.reason-check { display: flex; gap: 5px; align-items: center; font-size: 12px; color: var(--muted); }

@media (max-width: 768px) {
  .filter-bar {
    align-items: stretch;
    flex-direction: column;
  }

  .filter-bar input,
  .filter-bar select {
    width: 100% !important;
  }

  .table-wrap {
    border: 0;
    max-height: none;
    overflow: visible;
  }

  table,
  thead,
  tbody,
  tr,
  td {
    display: block;
    width: 100%;
  }

  thead {
    display: none;
  }

  tbody {
    display: flex;
    flex-direction: column;
    gap: 12px;
  }

  tr.clickable-row {
    border: 1px solid var(--border);
    border-radius: 8px;
    background: var(--surface);
    padding: 10px 12px;
  }

  tr.clickable-row:hover {
    background: var(--surface);
  }

  td {
    border: 0 !important;
    display: grid;
    grid-template-columns: 76px 1fr;
    gap: 10px;
    align-items: start;
    padding: 7px 0 !important;
    white-space: normal !important;
    text-align: left !important;
  }

  td::before {
    content: attr(data-label);
    color: var(--muted);
    font-size: 12px;
  }

  td:first-child div {
    white-space: normal !important;
    overflow: visible !important;
  }

  .modal-content {
    width: calc(100vw - 24px);
    padding: 20px;
  }

  .detail-grid {
    grid-template-columns: 1fr;
  }
}
</style>
