<template>
  <div class="page">
    <div v-if="loading" class="empty">加载中…</div>
    <template v-else-if="post">
      <div class="back-bar">
        <a class="back-link" @click="$router.push('/forum')">← 返回论坛</a>
      </div>

      <div class="panel post-detail">
        <div class="pd-header">
          <div class="pd-title">
            <span v-if="post.is_pinned" class="pin-tag">置顶</span>
            <span v-if="post.is_locked" class="lock-tag">🔒 已锁定</span>
            {{ post.title }}
          </div>
          <div class="pd-actions" v-if="canEdit">
            <button class="btn btn-outline" @click="startEdit">编辑</button>
            <button class="btn btn-danger" @click="removePost">删除</button>
          </div>
          <div class="pd-actions" v-else-if="auth.isLoggedIn">
            <button class="btn btn-outline" @click="reportTarget('post', post.id)">举报</button>
          </div>
        </div>

        <div class="pd-meta">
          <span class="pd-avatar">{{ post.author_avatar }}</span>
          <span class="pd-author">{{ post.author_name }}</span>
          <span>{{ post.author_level }} · {{ post.author_reputation || 0 }} 声望</span>
          <span class="cat-badge">{{ post.category_name }}</span>
          <span>{{ formatTime(post.created_at) }}</span>
          <span>👁 {{ post.view_count }} 浏览</span>
        </div>

        <div v-if="post.tags?.length" class="tag-row">
          <span v-for="tag in post.tags" :key="tag" class="tag-chip">#{{ tag }}</span>
        </div>

        <div v-if="!editing">
          <div class="pd-body rich-body" v-html="renderMarkdown(post.body || '（无正文）')"></div>
          <div v-if="post.image_urls?.length" class="image-grid">
            <a v-for="url in post.image_urls" :key="url" :href="url" target="_blank" rel="noopener">
              <img :src="url" alt="" />
            </a>
          </div>
        </div>
        <div v-else class="pd-edit">
          <input v-model="editForm.title" placeholder="标题" style="width:100%;margin-bottom:10px" />
          <textarea v-model="editForm.body" rows="8" style="width:100%"></textarea>
          <input v-model="editTags" placeholder="标签，逗号分隔" style="width:100%;margin-top:10px" />
          <textarea v-model="editImages" rows="3" placeholder="图片 URL，每行一个" style="width:100%;margin-top:10px"></textarea>
          <div class="modal-actions">
            <button class="btn btn-outline" @click="editing = false">取消</button>
            <button class="btn btn-primary" @click="saveEdit">保存</button>
          </div>
        </div>

        <div class="pd-foot">
          <button class="like-btn" :class="{ liked: post.liked_by_me }" @click="toggleLike">
            ♥ {{ post.like_count }} {{ post.liked_by_me ? '已赞' : '点赞' }}
          </button>
        </div>
      </div>

      <!-- 回复区 -->
      <div class="panel" style="margin-top:16px">
        <div class="panel-title">💬 回复 ({{ comments.length }})</div>

        <div v-if="comments.length === 0" class="empty" style="padding:30px">还没有回复</div>
        <div v-else class="comment-list">
          <div v-for="c in comments" :key="c.id" class="comment">
            <span class="c-avatar">{{ c.author_avatar }}</span>
            <div class="c-body">
              <div class="c-head">
                <span class="c-author">{{ c.author_name }}</span>
                <span class="c-time">{{ formatTime(c.created_at) }}</span>
                <button v-if="auth.isLoggedIn" class="c-del" @click="reportTarget('comment', c.id)">举报</button>
                <button v-if="canDeleteComment(c)" class="c-del" @click="removeComment(c.id)">删除</button>
              </div>
              <div class="c-text rich-body" v-html="renderMarkdown(c.body)"></div>
            </div>
          </div>
        </div>

        <!-- 回复输入 -->
        <div v-if="post.is_locked" class="locked-hint">🔒 该帖已锁定，无法回复</div>
        <div v-else-if="auth.isLoggedIn" class="comment-input">
          <textarea v-model="newComment" rows="3" placeholder="写下你的回复…"></textarea>
          <button class="btn btn-primary" :disabled="commenting" @click="submitComment">
            {{ commenting ? '发送中…' : '发送回复' }}
          </button>
        </div>
        <div v-else class="login-hint">
          <router-link to="/login">登录</router-link> 后参与讨论
        </div>
      </div>
    </template>
    <div v-else class="empty">帖子不存在或已被删除</div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { forumApi } from '../api/index.js'
import { useAuthStore } from '../stores/auth.js'

const auth = useAuthStore()
const route = useRoute()
const router = useRouter()
const postId = route.params.id

const post = ref(null)
const comments = ref([])
const loading = ref(true)
const newComment = ref('')
const commenting = ref(false)

const editing = ref(false)
const editForm = ref({ title: '', body: '' })
const editTags = ref('')
const editImages = ref('')

const canEdit = computed(() =>
  auth.isLoggedIn && post.value && (post.value.author_id === auth.user.id || auth.isAdmin))

function canDeleteComment(c) {
  return auth.isLoggedIn && (c.author_id === auth.user.id || auth.isAdmin)
}

function formatTime(iso) {
  if (!iso) return ''
  return new Date(iso).toLocaleString('zh-CN', { month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit' })
}

function escapeHtml(text) {
  return String(text || '').replace(/[&<>"']/g, ch => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[ch]))
}

function renderMarkdown(text) {
  let html = escapeHtml(text)
  html = html.replace(/^### (.*)$/gm, '<h3>$1</h3>')
    .replace(/^## (.*)$/gm, '<h2>$1</h2>')
    .replace(/^# (.*)$/gm, '<h1>$1</h1>')
    .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
    .replace(/\*(.*?)\*/g, '<em>$1</em>')
    .replace(/!\[(.*?)\]\((https?:\/\/[^\s)]+)\)/g, '<img class="inline-img" src="$2" alt="$1" />')
    .replace(/\[(.*?)\]\((https?:\/\/[^\s)]+)\)/g, '<a href="$2" target="_blank" rel="noopener">$1</a>')
    .replace(/\n/g, '<br>')
  return html
}

async function load() {
  loading.value = true
  try {
    post.value = await forumApi.post(postId)
    comments.value = await forumApi.comments(postId)
  } catch (e) {
    post.value = null
  } finally {
    loading.value = false
  }
}

async function toggleLike() {
  if (!auth.isLoggedIn) { router.push('/login'); return }
  try {
    const res = await forumApi.toggleLike(postId)
    post.value.liked_by_me = res.liked
    post.value.like_count = res.like_count
  } catch (e) { alert(e.message) }
}

async function submitComment() {
  if (!newComment.value.trim()) return
  commenting.value = true
  try {
    const c = await forumApi.createComment(postId, { body: newComment.value })
    comments.value.push(c)
    newComment.value = ''
    post.value.comment_count++
  } catch (e) { alert(e.message) }
  finally { commenting.value = false }
}

async function removeComment(id) {
  if (!confirm('确定删除这条回复？')) return
  try {
    await forumApi.deleteComment(id)
    comments.value = comments.value.filter(c => c.id !== id)
  } catch (e) { alert(e.message) }
}

function startEdit() {
  editForm.value = { title: post.value.title, body: post.value.body }
  editTags.value = (post.value.tags || []).join(', ')
  editImages.value = (post.value.image_urls || []).join('\n')
  editing.value = true
}

async function saveEdit() {
  try {
    const updated = await forumApi.updatePost(postId, {
      ...editForm.value,
      tags: editTags.value.split(/[,，\s]+/).map(x => x.trim()).filter(Boolean),
      image_urls: editImages.value.split(/\n+/).map(x => x.trim()).filter(Boolean),
    })
    post.value.title = updated.title
    post.value.body = updated.body
    post.value.tags = updated.tags
    post.value.image_urls = updated.image_urls
    editing.value = false
  } catch (e) { alert(e.message) }
}

async function reportTarget(target_type, target_id) {
  const reason = prompt('请选择/填写举报原因', '垃圾广告')
  if (!reason) return
  try {
    await forumApi.report({ target_type, target_id, reason })
    alert('举报已提交，管理员会在后台处理')
  } catch (e) { alert(e.message) }
}

async function removePost() {
  if (!confirm('确定删除这篇帖子？')) return
  try {
    await forumApi.deletePost(postId)
    router.push('/forum')
  } catch (e) { alert(e.message) }
}

onMounted(load)
</script>

<style scoped>
.back-bar { margin-bottom: 12px; }
.back-link { color: var(--accent2); cursor: pointer; font-size: 13px; text-decoration: none; }
.back-link:hover { text-decoration: underline; }

.post-detail { padding: 24px; }
.pd-header { display: flex; justify-content: space-between; align-items: flex-start; gap: 12px; }
.pd-title { font-size: 22px; font-weight: 700; display: flex; align-items: center; gap: 8px; flex-wrap: wrap; }
.pin-tag { font-size: 11px; background: var(--accent); color: #fff; padding: 2px 8px; border-radius: 4px; font-weight: 700; }
.lock-tag { font-size: 12px; color: var(--muted); }
.pd-actions { display: flex; gap: 8px; flex-shrink: 0; }
.pd-meta { display: flex; align-items: center; gap: 12px; font-size: 13px; color: var(--muted); margin: 14px 0; flex-wrap: wrap; }
.pd-avatar { font-size: 22px; }
.pd-author { font-weight: 600; color: var(--text); }
.cat-badge { color: var(--accent2); }
.pd-body { font-size: 15px; line-height: 1.8; white-space: pre-wrap; word-break: break-word; padding: 16px 0; border-top: 1px solid var(--border); }
.rich-body :deep(a) { color: var(--accent2); }
.rich-body :deep(h1), .rich-body :deep(h2), .rich-body :deep(h3) { margin: 10px 0; line-height: 1.35; }
.rich-body :deep(.inline-img) { max-width: 100%; border-radius: 8px; margin: 8px 0; }
.tag-row { display: flex; gap: 6px; flex-wrap: wrap; margin: 8px 0 12px; }
.tag-chip { border: 1px solid var(--border); background: var(--surface2); color: var(--accent2); border-radius: 6px; padding: 3px 8px; font-size: 11px; }
.image-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(160px, 1fr)); gap: 8px; margin: 10px 0 16px; }
.image-grid img { width: 100%; aspect-ratio: 4/3; object-fit: cover; border-radius: 8px; border: 1px solid var(--border); }
.pd-foot { padding-top: 16px; border-top: 1px solid var(--border); }
.like-btn { background: transparent; border: 1px solid var(--border); color: var(--muted); padding: 8px 20px; border-radius: 99px; cursor: pointer; font-size: 14px; font-family: inherit; transition: all .2s; }
.like-btn:hover { border-color: var(--red); color: var(--red); }
.like-btn.liked { background: rgba(239,68,68,.12); border-color: var(--red); color: var(--red); }

.comment-list { display: flex; flex-direction: column; gap: 16px; margin-bottom: 20px; }
.comment { display: flex; gap: 12px; }
.c-avatar { font-size: 24px; flex-shrink: 0; }
.c-body { flex: 1; }
.c-head { display: flex; align-items: center; gap: 10px; margin-bottom: 4px; }
.c-author { font-weight: 600; font-size: 13px; }
.c-time { font-size: 11px; color: var(--muted); }
.c-del { background: transparent; border: none; color: var(--muted); font-size: 11px; cursor: pointer; margin-left: auto; }
.c-del:hover { color: var(--red); }
.c-text { font-size: 14px; line-height: 1.6; white-space: pre-wrap; word-break: break-word; }

.comment-input { display: flex; flex-direction: column; gap: 10px; }
.comment-input textarea { width: 100%; resize: vertical; }
.comment-input .btn { align-self: flex-end; }
.locked-hint, .login-hint { text-align: center; padding: 16px; color: var(--muted); font-size: 13px; }
.login-hint a { color: var(--accent2); text-decoration: none; }
.modal-actions { display: flex; justify-content: flex-end; gap: 10px; margin-top: 12px; }
.empty { text-align: center; padding: 60px 20px; color: var(--muted); }
</style>
