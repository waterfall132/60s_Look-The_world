﻿import { createApp } from 'vue'
import { createRouter, createWebHistory } from 'vue-router'
import { createPinia } from 'pinia'
import App from './App.vue'
import MapView from './views/MapView.vue'
import TableView from './views/TableView.vue'
import AnalysisView from './views/AnalysisView.vue'
import AssessmentView from './views/AssessmentView.vue'
import VisaCardsView from './views/VisaCardsView.vue'
import AdminView from './views/AdminView.vue'
import ImportView from './views/ImportView.vue'
import LoginView from './views/LoginView.vue'
import RegisterView from './views/RegisterView.vue'
import ForgotPasswordView from './views/ForgotPasswordView.vue'
import ForumView from './views/ForumView.vue'
import PostDetailView from './views/PostDetailView.vue'
import RecordDetailView from './views/RecordDetailView.vue'
import ProfileView from './views/ProfileView.vue'
import MyPostsView from './views/MyPostsView.vue'
import { useAuthStore } from './stores/auth.js'

const router = createRouter({
  history: createWebHistory(),
  routes: [
    { path: '/', redirect: '/map' },
    { path: '/map', component: MapView, meta: { title: '避雷地图' } },
    { path: '/table', component: TableView, meta: { title: '数据明细' } },
    { path: '/records/:id', component: RecordDetailView, meta: { title: '避雷详情' } },
    { path: '/analysis', component: AnalysisView, meta: { title: '统计分析' } },
    { path: '/assessment', component: AssessmentView, meta: { title: '雇主地点评估' } },
    { path: '/visa-cards', component: VisaCardsView, meta: { title: '美签面签助手', requiresAuth: true } },
    { path: '/forum', component: ForumView, meta: { title: '论坛' } },
    { path: '/forum/post/:id', component: PostDetailView, meta: { title: '帖子详情' } },
    { path: '/profile', component: ProfileView, meta: { title: '个人中心', requiresAuth: true } },
    { path: '/my-posts', component: MyPostsView, meta: { title: '我的帖子', requiresAuth: true } },
    // 认证
    { path: '/login', component: LoginView, meta: { title: '登录', guestOnly: true } },
    { path: '/register', component: RegisterView, meta: { title: '注册', guestOnly: true } },
    { path: '/forgot-password', component: ForgotPasswordView, meta: { title: '找回密码', guestOnly: true } },
    // 管理员专属
    { path: '/admin', component: AdminView, meta: { title: '后台管理', requiresAdmin: true } },
    { path: '/import', component: ImportView, meta: { title: '导入导出', requiresAdmin: true } },
  ]
})

const pinia = createPinia()
const app = createApp(App)
app.use(pinia)
app.use(router)

// 路由守卫：管理员页面拦截 + 已登录用户不进登录/注册页
router.beforeEach((to, from, next) => {
  const auth = useAuthStore()
  if (to.meta.requiresAdmin && !auth.isAdmin) {
    next({ path: '/login', query: { redirect: to.fullPath } })
  } else if (to.meta.requiresAuth && !auth.isLoggedIn) {
    next({ path: '/login', query: { redirect: to.fullPath } })
  } else if (to.meta.guestOnly && auth.isLoggedIn) {
    next('/forum')
  } else {
    next()
  }
})

app.mount('#app')


