"""应用层安全防护中间件。

这些措施用于降低爬虫、撞库、扫描器和普通滥用请求的影响。
大流量 DDoS 仍应在 CDN/WAF/反向代理层处理。
"""

import os
import time
from collections import defaultdict, deque
from typing import Callable

from fastapi import Request
from fastapi.responses import JSONResponse, PlainTextResponse


def _bool_env(name: str, default: bool = False) -> bool:
    value = os.getenv(name)
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


def _csv_env(name: str, default: str = "") -> list[str]:
    return [x.strip() for x in os.getenv(name, default).split(",") if x.strip()]


SECURITY_ENABLED = _bool_env("SECURITY_ENABLED", True)
TRUST_PROXY_HEADERS = _bool_env("TRUST_PROXY_HEADERS", False)

MAX_BODY_BYTES = int(os.getenv("MAX_BODY_BYTES", str(20 * 1024 * 1024)))
RATE_LIMIT_WINDOW_SECONDS = int(os.getenv("RATE_LIMIT_WINDOW_SECONDS", "60"))
PUBLIC_RATE_LIMIT = int(os.getenv("PUBLIC_RATE_LIMIT_PER_MIN", "180"))
AUTH_RATE_LIMIT = int(os.getenv("AUTH_RATE_LIMIT_PER_MIN", "20"))
WRITE_RATE_LIMIT = int(os.getenv("WRITE_RATE_LIMIT_PER_MIN", "60"))
ADMIN_RATE_LIMIT = int(os.getenv("ADMIN_RATE_LIMIT_PER_MIN", "120"))

BLOCKED_USER_AGENT_PARTS = [
    x.lower()
    for x in _csv_env(
        "BLOCKED_USER_AGENTS",
        "sqlmap,nikto,nmap,masscan,zgrab,acunetix,nessus,dirbuster,gobuster,hydra,jaeles,ffuf",
    )
]

SUSPICIOUS_PATH_PARTS = [
    "/.env",
    "/.git",
    "/wp-admin",
    "/wp-login",
    "/phpmyadmin",
    "/xmlrpc.php",
    "/vendor/phpunit",
    "/cgi-bin",
    "/boaform",
    "/actuator",
    "/solr/",
    "/manager/html",
]

_hits: dict[str, deque[float]] = defaultdict(deque)


def get_client_ip(request: Request) -> str:
    if TRUST_PROXY_HEADERS:
        forwarded_for = request.headers.get("x-forwarded-for")
        if forwarded_for:
            return forwarded_for.split(",")[0].strip()
        real_ip = request.headers.get("x-real-ip")
        if real_ip:
            return real_ip.strip()
    return request.client.host if request.client else "unknown"


def _limit_for_request(request: Request) -> int:
    path = request.url.path
    method = request.method.upper()
    if path.startswith("/api/auth/"):
        return AUTH_RATE_LIMIT
    if path.startswith("/api/admin/"):
        return ADMIN_RATE_LIMIT
    if method in {"POST", "PUT", "PATCH", "DELETE"}:
        return WRITE_RATE_LIMIT
    return PUBLIC_RATE_LIMIT


def _rate_limited(request: Request, ip: str) -> bool:
    limit = _limit_for_request(request)
    now = time.monotonic()
    key = f"{ip}:{request.method}:{request.url.path}"
    bucket = _hits[key]
    cutoff = now - RATE_LIMIT_WINDOW_SECONDS
    while bucket and bucket[0] < cutoff:
        bucket.popleft()
    if len(bucket) >= limit:
        return True
    bucket.append(now)
    return False


def _is_suspicious_request(request: Request) -> bool:
    path = request.url.path.lower()
    if any(part in path for part in SUSPICIOUS_PATH_PARTS):
        return True
    ua = (request.headers.get("user-agent") or "").lower()
    return bool(ua and any(part in ua for part in BLOCKED_USER_AGENT_PARTS))


def _security_headers(response):
    response.headers.setdefault("X-Content-Type-Options", "nosniff")
    response.headers.setdefault("X-Frame-Options", "DENY")
    response.headers.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
    response.headers.setdefault("Permissions-Policy", "geolocation=(), camera=(), microphone=()")
    response.headers.setdefault("X-Robots-Tag", "noarchive")
    response.headers.setdefault(
        "Content-Security-Policy",
        "default-src 'self'; "
        "script-src 'self' https://*.paypal.com https://*.paypalobjects.com; "
        "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; "
        "font-src 'self' https://fonts.gstatic.com; "
        "img-src 'self' data: https:; "
        "connect-src 'self' https://*.paypal.com https://*.paypalobjects.com; "
        "frame-src https://*.paypal.com https://*.paypalobjects.com; "
        "child-src https://*.paypal.com https://*.paypalobjects.com; "
        "frame-ancestors 'none'; "
        "base-uri 'self'; "
        "form-action 'self' https://*.paypal.com",
    )
    return response


async def security_middleware(request: Request, call_next: Callable):
    if not SECURITY_ENABLED:
        return await call_next(request)

    if _is_suspicious_request(request):
        return _security_headers(JSONResponse({"detail": "Not found"}, status_code=404))

    content_length = request.headers.get("content-length")
    if content_length:
        try:
            if int(content_length) > MAX_BODY_BYTES:
                return _security_headers(JSONResponse({"detail": "请求体过大"}, status_code=413))
        except ValueError:
            return _security_headers(JSONResponse({"detail": "Content-Length 无效"}, status_code=400))

    ip = get_client_ip(request)
    if _rate_limited(request, ip):
        return _security_headers(JSONResponse({"detail": "请求过于频繁，请稍后再试"}, status_code=429))

    response = await call_next(request)
    return _security_headers(response)


def robots_txt():
    return PlainTextResponse(
        "User-agent: *\n"
        "Disallow: /api/\n"
        "Disallow: /admin\n"
        "Disallow: /import\n"
        "Crawl-delay: 10\n",
        media_type="text/plain",
    )
