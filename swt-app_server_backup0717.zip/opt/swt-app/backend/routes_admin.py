"""管理员路由。"""

from datetime import datetime, timedelta
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel
from sqlalchemy import func
from sqlalchemy.orm import Session

from ai_service import get_or_create_ai_config, test_ai_config
from auth import hash_password, require_admin
from database import (
    AIConfig,
    Announcement,
    AnnouncementRead,
    BanRecord,
    Category,
    Comment,
    InviteCode,
    Notification,
    Post,
    PostLike,
    RecordFeedback,
    RecordModel,
    Report,
    SensitiveWord,
    SiteSetting,
    User,
    UserActivityLog,
    gen_id,
    get_db,
)
from translation_service import run_translation_batch, scan_translations

router = APIRouter(prefix="/api/admin", tags=["admin"])


class UserUpdateReq(BaseModel):
    role: Optional[str] = None
    is_active: Optional[bool] = None
    is_vip: Optional[bool] = None
    assessment_credits: Optional[int] = None
    assessment_monthly_limit: Optional[int] = None
    bio: Optional[str] = None


class AdminResetPwReq(BaseModel):
    new_password: str


class AnnouncementReq(BaseModel):
    title: str
    body: str = ""
    level: str = "info"
    link_url: str = ""
    is_active: bool = True
    is_pinned: bool = False
    starts_at: Optional[datetime] = None
    ends_at: Optional[datetime] = None


class AIConfigReq(BaseModel):
    provider: str = "openai_compatible"
    base_url: str = "https://api.openai.com/v1"
    api_key: Optional[str] = None
    model: str = "gpt-4o-mini"
    enabled: bool = False
    temperature: float = 0.2
    clear_api_key: bool = False


class CategoryReq(BaseModel):
    name: str
    slug: str
    description: str = ""
    icon: str = "💬"
    sort_order: int = 0


class CategoryUpdateReq(BaseModel):
    name: Optional[str] = None
    slug: Optional[str] = None
    description: Optional[str] = None
    icon: Optional[str] = None
    sort_order: Optional[int] = None


class PostModerateReq(BaseModel):
    is_pinned: Optional[bool] = None
    is_locked: Optional[bool] = None
    status: Optional[str] = None


class ReportModerateReq(BaseModel):
    status: str = "resolved"
    action: str = "none"


class SensitiveWordReq(BaseModel):
    word: str
    action: str = "block"
    is_active: bool = True


class BanReq(BaseModel):
    user_id: str
    reason: str = ""
    days: Optional[int] = 7


class RecordFeedbackModerateReq(BaseModel):
    status: str = "resolved"


class InviteCodeReq(BaseModel):
    code: str
    max_uses: int = 1
    is_vip: bool = True


class InviteCodeUpdateReq(BaseModel):
    max_uses: Optional[int] = None
    is_active: Optional[bool] = None
    is_vip: Optional[bool] = None


class TranslationRunReq(BaseModel):
    locale: str = "en"
    limit: int = 20
    retry_failed: bool = False


class PayPalConfigReq(BaseModel):
    paypal_env: str = "sandbox"
    paypal_client_id: str = ""
    paypal_secret: Optional[str] = None
    paypal_webhook_id: str = ""
    vip_price_usd: str = "39.99"
    vip_days: int = 365
    clear_secret: bool = False


class VipContactReq(BaseModel):
    vip_contact: str


DEFAULT_VIP_CONTACT = "请联系管理员开通 VIP：\n微信：请在后台配置\n邮箱：admin@swt.local"


@router.get("/overview")
def overview(admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    return {
        "users": db.query(func.count(User.id)).scalar(),
        "categories": db.query(func.count(Category.id)).scalar(),
        "posts": db.query(func.count(Post.id)).scalar(),
        "comments": db.query(func.count(Comment.id)).scalar(),
        "records": db.query(func.count(RecordModel.id)).scalar(),
        "open_reports": db.query(func.count(Report.id)).filter(Report.status == "open").scalar(),
        "open_record_feedback": db.query(func.count(RecordFeedback.id)).filter(RecordFeedback.status == "open").scalar(),
        "active_announcements": db.query(func.count(Announcement.id)).filter(Announcement.is_active == True).scalar(),
    }


def get_or_create_site_setting(db: Session, key: str, default: str = "") -> SiteSetting:
    setting = db.query(SiteSetting).filter(SiteSetting.key == key).first()
    if not setting:
        setting = SiteSetting(key=key, value=default, updated_at=datetime.utcnow())
        db.add(setting)
        db.commit()
        db.refresh(setting)
    return setting


def site_setting_value(db: Session, key: str, default: str = "") -> str:
    setting = db.query(SiteSetting).filter(SiteSetting.key == key).first()
    return setting.value if setting and setting.value is not None else default


def set_site_setting(db: Session, key: str, value: str) -> SiteSetting:
    setting = get_or_create_site_setting(db, key, "")
    setting.value = value
    setting.updated_at = datetime.utcnow()
    return setting


def mask_secret(value: str) -> str:
    if not value:
        return ""
    if len(value) <= 8:
        return "****"
    return f"{value[:4]}...{value[-4:]}"


@router.get("/site-settings")
def get_site_settings(admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    vip_contact = get_or_create_site_setting(db, "vip_contact", DEFAULT_VIP_CONTACT)
    paypal_secret = site_setting_value(db, "paypal_secret", "")
    return {
        "vip_contact": vip_contact.value or DEFAULT_VIP_CONTACT,
        "vip_contact_updated_at": vip_contact.updated_at.isoformat() + "Z" if vip_contact.updated_at else None,
        "paypal": {
            "paypal_env": site_setting_value(db, "paypal_env", "sandbox"),
            "paypal_client_id": site_setting_value(db, "paypal_client_id", ""),
            "paypal_webhook_id": site_setting_value(db, "paypal_webhook_id", ""),
            "vip_price_usd": site_setting_value(db, "vip_price_usd", "39.99"),
            "vip_days": int(site_setting_value(db, "vip_days", "365") or 365),
            "has_secret": bool(paypal_secret),
            "secret_masked": mask_secret(paypal_secret),
        },
    }


@router.put("/site-settings/vip-contact")
def update_vip_contact(req: VipContactReq, admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    value = (req.vip_contact or "").strip()
    if not value:
        raise HTTPException(400, "VIP 联系方式不能为空")
    if len(value) > 2000:
        raise HTTPException(400, "VIP 联系方式不能超过 2000 字")
    setting = get_or_create_site_setting(db, "vip_contact", DEFAULT_VIP_CONTACT)
    setting.value = value
    setting.updated_at = datetime.utcnow()
    db.commit()
    db.refresh(setting)
    return {"vip_contact": setting.value, "updated_at": setting.updated_at.isoformat() + "Z" if setting.updated_at else None}


@router.put("/site-settings/paypal")
def update_paypal_settings(req: PayPalConfigReq, admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    env = (req.paypal_env or "sandbox").strip().lower()
    if env not in ("sandbox", "live"):
        raise HTTPException(400, "PayPal 环境只能是 sandbox 或 live")
    client_id = (req.paypal_client_id or "").strip()
    webhook_id = (req.paypal_webhook_id or "").strip()
    price = (req.vip_price_usd or "39.99").strip()
    try:
        price_value = float(price)
    except ValueError:
        raise HTTPException(400, "VIP 价格格式不正确")
    if price_value <= 0:
        raise HTTPException(400, "VIP 价格必须大于 0")
    if req.vip_days <= 0:
        raise HTTPException(400, "VIP 天数必须大于 0")

    set_site_setting(db, "paypal_env", env)
    set_site_setting(db, "paypal_client_id", client_id)
    set_site_setting(db, "paypal_webhook_id", webhook_id)
    set_site_setting(db, "vip_price_usd", f"{price_value:.2f}")
    set_site_setting(db, "vip_days", str(req.vip_days))
    if req.clear_secret:
        set_site_setting(db, "paypal_secret", "")
    elif req.paypal_secret is not None and req.paypal_secret.strip():
        set_site_setting(db, "paypal_secret", req.paypal_secret.strip())
    db.commit()
    paypal_secret = site_setting_value(db, "paypal_secret", "")
    return {
        "paypal_env": env,
        "paypal_client_id": client_id,
        "paypal_webhook_id": webhook_id,
        "vip_price_usd": f"{price_value:.2f}",
        "vip_days": req.vip_days,
        "has_secret": bool(paypal_secret),
        "secret_masked": mask_secret(paypal_secret),
    }


@router.get("/ai-config")
def get_ai_config(admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    return get_or_create_ai_config(db).to_dict()


@router.put("/ai-config")
def update_ai_config(req: AIConfigReq, admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    config = get_or_create_ai_config(db)
    provider = req.provider.strip() or "openai_compatible"
    base_url = req.base_url.strip().rstrip("/")
    model = req.model.strip()
    if not base_url:
        raise HTTPException(400, "Base URL 不能为空")
    if not model:
        raise HTTPException(400, "模型名不能为空")
    if req.temperature < 0 or req.temperature > 2:
        raise HTTPException(400, "temperature 需要在 0-2 之间")
    config.provider = provider
    config.base_url = base_url
    config.model = model
    config.enabled = req.enabled
    config.temperature = req.temperature
    if req.clear_api_key:
        config.api_key = ""
    elif req.api_key is not None and req.api_key.strip():
        config.api_key = req.api_key.strip()
    db.commit()
    db.refresh(config)
    return config.to_dict()


@router.post("/ai-config/test")
def test_current_ai_config(req: AIConfigReq, admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    saved = get_or_create_ai_config(db)
    base_url = req.base_url.strip().rstrip("/")
    model = req.model.strip()
    api_key = (req.api_key or "").strip() or (saved.api_key or "")
    if req.clear_api_key:
        api_key = ""
    if not base_url:
        raise HTTPException(400, "Base URL 不能为空")
    if not model:
        raise HTTPException(400, "模型名不能为空")
    if not api_key:
        raise HTTPException(400, "请先填写或保留 API Key")
    if req.temperature < 0 or req.temperature > 2:
        raise HTTPException(400, "temperature 需要在 0-2 之间")
    result = test_ai_config(base_url=base_url, api_key=api_key, model=model, temperature=req.temperature)
    result.update({"provider": req.provider, "base_url": base_url, "model": model})
    return result


@router.get("/translations/status")
def translation_status(locale: str = "en", admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    return scan_translations(db, locale)


@router.post("/translations/run")
def translation_run(req: TranslationRunReq, admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    try:
        return run_translation_batch(
            db,
            locale=req.locale,
            limit=req.limit,
            retry_failed=req.retry_failed,
        )
    except RuntimeError as exc:
        raise HTTPException(400, str(exc))


def validate_announcement_req(req: AnnouncementReq):
    title = req.title.strip()[:200]
    if not title:
        raise HTTPException(400, "通知标题不能为空")
    if req.level not in ("info", "success", "warning", "danger"):
        raise HTTPException(400, "通知级别无效")
    if req.starts_at and req.ends_at and req.ends_at <= req.starts_at:
        raise HTTPException(400, "结束时间必须晚于开始时间")
    return title


@router.get("/announcements")
def admin_list_announcements(status: str = "all", admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    q = db.query(Announcement)
    if status == "active":
        q = q.filter(Announcement.is_active == True)
    elif status == "inactive":
        q = q.filter(Announcement.is_active == False)
    return [x.to_dict() for x in q.order_by(Announcement.is_pinned.desc(), Announcement.updated_at.desc()).all()]


@router.post("/announcements", status_code=201)
def admin_create_announcement(req: AnnouncementReq, admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    title = validate_announcement_req(req)
    item = Announcement(
        id=gen_id(),
        title=title,
        body=req.body.strip()[:5000],
        level=req.level,
        link_url=req.link_url.strip()[:1000],
        is_active=req.is_active,
        is_pinned=req.is_pinned,
        starts_at=req.starts_at,
        ends_at=req.ends_at,
        created_by=admin.id,
    )
    db.add(item)
    db.commit()
    db.refresh(item)
    return item.to_dict()


@router.put("/announcements/{announcement_id}")
def admin_update_announcement(announcement_id: str, req: AnnouncementReq, admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    item = db.query(Announcement).filter(Announcement.id == announcement_id).first()
    if not item:
        raise HTTPException(404, "通知不存在")
    title = validate_announcement_req(req)
    item.title = title
    item.body = req.body.strip()[:5000]
    item.level = req.level
    item.link_url = req.link_url.strip()[:1000]
    item.is_active = req.is_active
    item.is_pinned = req.is_pinned
    item.starts_at = req.starts_at
    item.ends_at = req.ends_at
    item.updated_at = datetime.utcnow()
    db.query(AnnouncementRead).filter(AnnouncementRead.announcement_id == announcement_id).delete(synchronize_session=False)
    db.commit()
    db.refresh(item)
    return item.to_dict()


@router.delete("/announcements/{announcement_id}")
def admin_delete_announcement(announcement_id: str, admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    item = db.query(Announcement).filter(Announcement.id == announcement_id).first()
    if not item:
        raise HTTPException(404, "通知不存在")
    db.query(AnnouncementRead).filter(AnnouncementRead.announcement_id == announcement_id).delete(synchronize_session=False)
    db.delete(item)
    db.commit()
    return {"deleted": announcement_id}


@router.get("/users")
def list_users(search: Optional[str] = None, page: int = Query(1, ge=1), page_size: int = Query(20, ge=1, le=100), admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    q = db.query(User)
    if search:
        q = q.filter(User.username.ilike(f"%{search}%"))
    total = q.count()
    users = q.order_by(User.created_at.desc()).offset((page - 1) * page_size).limit(page_size).all()
    online_threshold = datetime.utcnow() - timedelta(minutes=10)
    activity_threshold = datetime.utcnow() - timedelta(days=7)
    activity_counts = dict(
        db.query(UserActivityLog.user_id, func.count(UserActivityLog.id))
        .filter(UserActivityLog.created_at >= activity_threshold)
        .group_by(UserActivityLog.user_id)
        .all()
    )
    items = []
    for u in users:
        d = u.to_dict(include_email=True)
        d["post_count"] = db.query(func.count(Post.id)).filter(Post.author_id == u.id).scalar()
        d["is_online"] = bool(u.last_seen_at and u.last_seen_at >= online_threshold)
        d["recent_login_count"] = activity_counts.get(u.id, 0)
        items.append(d)
    online_total = db.query(func.count(User.id)).filter(User.is_active == True, User.last_seen_at >= online_threshold).scalar()
    return {
        "total": total,
        "page": page,
        "page_size": page_size,
        "pages": (total + page_size - 1) // page_size,
        "online_total": online_total,
        "users": items,
    }


@router.put("/users/{user_id}")
def update_user(user_id: str, req: UserUpdateReq, admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(404, "用户不存在")
    if user.id == admin.id and (req.role == "user" or req.is_active is False):
        raise HTTPException(400, "不能修改自己的管理员权限或禁用自己")
    if req.role is not None:
        if req.role not in ("user", "admin"):
            raise HTTPException(400, "角色只能是 user 或 admin")
        user.role = req.role
    if req.is_active is not None:
        user.is_active = req.is_active
    if req.is_vip is not None:
        user.is_vip = req.is_vip
    if req.assessment_credits is not None:
        user.assessment_credits = max(0, req.assessment_credits)
    if req.assessment_monthly_limit is not None:
        user.assessment_monthly_limit = max(0, req.assessment_monthly_limit)
    if req.bio is not None:
        user.bio = req.bio
    db.commit()
    db.refresh(user)
    return user.to_dict(include_email=True)


@router.post("/users/{user_id}/vip")
def toggle_vip(user_id: str, admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(404, "用户不存在")
    if user.role == "admin":
        raise HTTPException(400, "管理员天然是 VIP")
    user.is_vip = not bool(user.is_vip)
    db.commit()
    db.refresh(user)
    return {"is_vip": bool(user.is_vip)}


@router.put("/users/{user_id}/password")
def reset_password(user_id: str, req: AdminResetPwReq, admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(404, "用户不存在")
    if len(req.new_password) < 6:
        raise HTTPException(400, "密码至少 6 位")
    user_count_before = db.query(func.count(User.id)).scalar()
    user.password_hash = hash_password(req.new_password)
    db.commit()
    user_count_after = db.query(func.count(User.id)).scalar()
    if user_count_after != user_count_before:
        db.rollback()
        raise HTTPException(500, "Reset password changed user count; operation rejected")
    return {"message": "密码已重置", "user_id": user_id}


@router.delete("/users/{user_id}")
def delete_user(user_id: str, admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    if user_id == admin.id:
        raise HTTPException(400, "不能删除自己")
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(404, "用户不存在")
    db.delete(user)
    db.commit()
    return {"deleted": user_id}


@router.get("/posts")
def admin_list_posts(search: Optional[str] = None, category_id: Optional[str] = None, page: int = Query(1, ge=1), page_size: int = Query(20, ge=1, le=100), admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    q = db.query(Post)
    if category_id:
        q = q.filter(Post.category_id == category_id)
    if search:
        q = q.filter(Post.title.ilike(f"%{search}%"))
    total = q.count()
    posts = q.order_by(Post.last_activity_at.desc(), Post.created_at.desc()).offset((page - 1) * page_size).limit(page_size).all()
    items = []
    for p in posts:
        cc = db.query(func.count(Comment.id)).filter(Comment.post_id == p.id).scalar()
        lc = db.query(func.count(PostLike.id)).filter(PostLike.post_id == p.id).scalar()
        items.append(p.to_dict(comment_count=cc, like_count=lc))
    return {"total": total, "page": page, "page_size": page_size, "pages": (total + page_size - 1) // page_size, "posts": items}


@router.put("/posts/{post_id}/moderate")
def moderate_post(post_id: str, req: PostModerateReq, admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    post = db.query(Post).filter(Post.id == post_id).first()
    if not post:
        raise HTTPException(404, "帖子不存在")
    if req.is_pinned is not None:
        post.is_pinned = req.is_pinned
    if req.is_locked is not None:
        post.is_locked = req.is_locked
    if req.status is not None:
        if req.status not in ("published", "hidden"):
            raise HTTPException(400, "状态只能是 published 或 hidden")
        post.status = req.status
    db.commit()
    db.refresh(post)
    return post.to_dict()


@router.delete("/posts/{post_id}")
def admin_delete_post(post_id: str, admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    post = db.query(Post).filter(Post.id == post_id).first()
    if not post:
        raise HTTPException(404, "帖子不存在")
    db.delete(post)
    db.commit()
    return {"deleted": post_id}


@router.get("/reports")
def list_reports(status: str = "open", admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    q = db.query(Report)
    if status != "all":
        q = q.filter(Report.status == status)
    reports = q.order_by(Report.created_at.desc()).limit(100).all()
    items = []
    for r in reports:
        d = r.to_dict()
        if r.target_type == "post":
            p = db.query(Post).filter(Post.id == r.target_id).first()
            d["target_title"] = p.title if p else "已删除"
            d["target_excerpt"] = (p.body or "")[:120] if p else ""
            d["target_author_id"] = p.author_id if p else None
        else:
            c = db.query(Comment).filter(Comment.id == r.target_id).first()
            d["target_title"] = "回复"
            d["target_excerpt"] = (c.body or "")[:120] if c else "已删除"
            d["target_author_id"] = c.author_id if c else None
            d["post_id"] = c.post_id if c else None
        items.append(d)
    return items


@router.get("/record-feedback")
def list_record_feedback(status: str = "open", admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    q = db.query(RecordFeedback)
    if status != "all":
        q = q.filter(RecordFeedback.status == status)
    return [x.to_dict() for x in q.order_by(RecordFeedback.created_at.desc()).limit(100).all()]


@router.put("/record-feedback/{feedback_id}")
def moderate_record_feedback(feedback_id: str, req: RecordFeedbackModerateReq, admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    item = db.query(RecordFeedback).filter(RecordFeedback.id == feedback_id).first()
    if not item:
        raise HTTPException(404, "反馈不存在")
    if req.status not in ("resolved", "dismissed"):
        raise HTTPException(400, "状态只能是 resolved 或 dismissed")
    item.status = req.status
    item.resolved_at = datetime.utcnow()
    item.resolved_by = admin.id
    db.commit()
    db.refresh(item)
    return item.to_dict()


@router.put("/reports/{report_id}")
def moderate_report(report_id: str, req: ReportModerateReq, admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    report = db.query(Report).filter(Report.id == report_id).first()
    if not report:
        raise HTTPException(404, "举报不存在")
    if req.status not in ("resolved", "dismissed"):
        raise HTTPException(400, "处理状态错误")
    if req.action == "hide_post" and report.target_type == "post":
        post = db.query(Post).filter(Post.id == report.target_id).first()
        if post:
            post.status = "hidden"
    elif req.action == "delete_post" and report.target_type == "post":
        post = db.query(Post).filter(Post.id == report.target_id).first()
        if post:
            db.delete(post)
    elif req.action == "delete_comment" and report.target_type == "comment":
        comment = db.query(Comment).filter(Comment.id == report.target_id).first()
        if comment:
            db.delete(comment)
    report.status = req.status
    report.resolved_at = datetime.utcnow()
    report.resolved_by = admin.id
    db.commit()
    return report.to_dict()


@router.get("/sensitive-words")
def list_sensitive_words(admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    return [w.to_dict() for w in db.query(SensitiveWord).order_by(SensitiveWord.created_at.desc()).all()]


@router.post("/sensitive-words", status_code=201)
def create_sensitive_word(req: SensitiveWordReq, admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    word = req.word.strip()
    if not word:
        raise HTTPException(400, "敏感词不能为空")
    if db.query(SensitiveWord).filter(SensitiveWord.word == word).first():
        raise HTTPException(400, "敏感词已存在")
    item = SensitiveWord(id=gen_id(), word=word, action=req.action, is_active=req.is_active)
    db.add(item)
    db.commit()
    db.refresh(item)
    return item.to_dict()


@router.put("/sensitive-words/{word_id}")
def update_sensitive_word(word_id: str, req: SensitiveWordReq, admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    item = db.query(SensitiveWord).filter(SensitiveWord.id == word_id).first()
    if not item:
        raise HTTPException(404, "敏感词不存在")
    item.word = req.word.strip()
    item.action = req.action
    item.is_active = req.is_active
    db.commit()
    db.refresh(item)
    return item.to_dict()


@router.delete("/sensitive-words/{word_id}")
def delete_sensitive_word(word_id: str, admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    item = db.query(SensitiveWord).filter(SensitiveWord.id == word_id).first()
    if not item:
        raise HTTPException(404, "敏感词不存在")
    db.delete(item)
    db.commit()
    return {"deleted": word_id}


@router.get("/bans")
def list_bans(admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    return [b.to_dict() for b in db.query(BanRecord).order_by(BanRecord.starts_at.desc()).limit(100).all()]


@router.post("/bans", status_code=201)
def ban_user(req: BanReq, admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    user = db.query(User).filter(User.id == req.user_id).first()
    if not user:
        raise HTTPException(404, "用户不存在")
    if user.id == admin.id:
        raise HTTPException(400, "不能封禁自己")
    ends_at = None if req.days is None else datetime.utcnow() + timedelta(days=max(1, req.days))
    user.ban_until = ends_at
    user.ban_reason = req.reason.strip()
    ban = BanRecord(id=gen_id(), user_id=user.id, admin_id=admin.id, reason=user.ban_reason, ends_at=ends_at)
    db.add(ban)
    db.commit()
    db.refresh(ban)
    return ban.to_dict()


@router.post("/bans/{ban_id}/lift")
def lift_ban(ban_id: str, admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    ban = db.query(BanRecord).filter(BanRecord.id == ban_id).first()
    if not ban:
        raise HTTPException(404, "封禁记录不存在")
    ban.is_active = False
    user = db.query(User).filter(User.id == ban.user_id).first()
    if user:
        user.ban_until = None
        user.ban_reason = ""
    db.commit()
    return ban.to_dict()


@router.get("/invite-codes")
def list_invite_codes(admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    return [x.to_dict() for x in db.query(InviteCode).order_by(InviteCode.created_at.desc()).all()]


@router.post("/invite-codes")
def create_invite_code(req: InviteCodeReq, admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    code = req.code.strip().upper()
    if not code:
        raise HTTPException(400, "邀请码不能为空")
    if req.max_uses < 1:
        raise HTTPException(400, "最大次数至少为 1")
    if db.query(InviteCode).filter(InviteCode.code == code).first():
        raise HTTPException(400, "邀请码已存在")
    invite = InviteCode(id=gen_id(), code=code, max_uses=req.max_uses, is_vip=req.is_vip)
    db.add(invite)
    db.commit()
    db.refresh(invite)
    return invite.to_dict()


@router.delete("/invite-codes/{invite_id}")
def delete_invite_code(invite_id: str, admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    invite = db.query(InviteCode).filter(InviteCode.id == invite_id).first()
    if not invite:
        raise HTTPException(404, "邀请码不存在")
    db.delete(invite)
    db.commit()
    return {"deleted": invite_id}


@router.put("/invite-codes/{invite_id}")
def update_invite_code(invite_id: str, req: InviteCodeUpdateReq, admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    invite = db.query(InviteCode).filter(InviteCode.id == invite_id).first()
    if not invite:
        raise HTTPException(404, "邀请码不存在")
    if req.max_uses is not None:
        if req.max_uses < 1:
            raise HTTPException(400, "最大次数至少为 1")
        if req.max_uses < invite.used_count:
            raise HTTPException(400, "最大次数不能小于已使用次数")
        invite.max_uses = req.max_uses
    if req.is_active is not None:
        invite.is_active = req.is_active
    if req.is_vip is not None:
        invite.is_vip = req.is_vip
    db.commit()
    db.refresh(invite)
    return invite.to_dict()
