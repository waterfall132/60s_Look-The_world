﻿from datetime import datetime
from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.orm import Session

from auth import get_current_user
from database import User, VisaCard, get_db, gen_id

router = APIRouter(prefix="/api/visa-cards", tags=["visa-cards"])

VALID_CATEGORIES = {"both", "intern", "trainee"}

DEFAULT_TEMPLATES = [
    {
        "id": "j1-core",
        "name": "J-1 Intern / Trainee 核心题库",
        "description": "覆盖赴美目的、雇主、薪资、培训计划、回国计划等高频问题。",
        "cards": [
            {"question": "Why do you go to America? / What is your purpose?", "answer": "I am going to the United States to participate in the J-1 Intern/Trainee program. I will be training at [Company Name] in [City, State] as a [position]. This structured program will help me improve my professional skills and career prospects when I return to China.", "category": "both", "tag": "目的"},
            {"question": "What type of visa are you applying for? / What is a J-1 visa?", "answer": "I am applying for a J-1 exchange visitor visa. It is for cultural exchange and structured training, not immigration.", "category": "both", "tag": "签证类型"},
            {"question": "Where will you work or train? Who is your employer?", "answer": "I will be training at [Company Name], located in [City, State]. It is a [type of business]. My direct supervisor will be [Supervisor Name].", "category": "both", "tag": "雇主信息"},
            {"question": "How long will you stay in the United States?", "answer": "My program runs from [start date] to [end date]. After completing the program, I will return to China as planned.", "category": "both", "tag": "时长"},
            {"question": "Will you be paid? What is your salary or stipend?", "answer": "Yes. I will receive [amount] dollars per hour and work about [hours] hours per week. I also have personal funds for emergencies.", "category": "both", "tag": "薪资"},
            {"question": "Why did you choose this company or program?", "answer": "I chose this company because it provides a structured training plan and professional supervision. The skills I will learn match my career goals in China.", "category": "both", "tag": "选择原因"},
            {"question": "What will you do after the program? Do you plan to stay in the US?", "answer": "No, I will not stay in the United States. I will return to China and use this international experience to develop my career in [industry/company].", "category": "both", "tag": "回国计划"},
            {"question": "Who is your sponsor?", "answer": "My sponsor is [Sponsor Name], a U.S. Department of State designated J-1 sponsor. They oversee my program and monitor my welfare during my stay.", "category": "both", "tag": "赞助机构"},
            {"question": "What specific skills will you learn?", "answer": "My training includes [phase 1], [phase 2], and [phase 3]. I will learn practical skills, professional standards, and management knowledge under supervision.", "category": "trainee", "tag": "培训内容"},
            {"question": "Why not train in China? Why America specifically?", "answer": "American [industry] has mature standards and a diverse working environment. Experiencing these practices directly will give me a competitive advantage after I return to China.", "category": "both", "tag": "选择美国原因"},
            {"question": "What is your educational background?", "answer": "I studied [major] at [University]. My education gave me a strong foundation, and this program is a practical next step for my career development.", "category": "both", "tag": "教育背景"},
            {"question": "Do you have ties to your home country?", "answer": "Yes. My family and long-term career plans are in China. The experience in the U.S. is valuable because it will help me find better opportunities after returning home.", "category": "both", "tag": "回国意愿"},
        ],
    },
    {
        "id": "swt",
        "name": "SWT 暑期工旅面签题库",
        "description": "适用于 Summer Work Travel，强调学生身份、假期、雇主、住宿和按期回国。",
        "cards": [
            {"question": "Why do you want to go to the United States?", "answer": "I am participating in the J-1 Summer Work and Travel program. I want to practice my English, experience American culture, and make international friends.", "category": "both", "tag": "目的"},
            {"question": "Are you a student? Where are you studying?", "answer": "Yes. I am studying at [University Name] in [City]. My major is [Major].", "category": "both", "tag": "学校信息"},
            {"question": "What is your job in the US?", "answer": "I will be a [position] at [Company Name] in [City, State]. My duties include [brief job duties].", "category": "both", "tag": "工作内容"},
            {"question": "Where will you live in the US?", "answer": "I will live in [housing address or city]. The housing is arranged by my employer or sponsor and it is close to my workplace.", "category": "both", "tag": "住宿"},
            {"question": "When will you return to China?", "answer": "I will return to China on [date] before my next semester starts. I need to continue my study at my university.", "category": "both", "tag": "回国计划"},
            {"question": "Who pays for your trip?", "answer": "My parents support this program. I also have personal funds for living expenses and emergencies.", "category": "both", "tag": "资金"},
            {"question": "Have you contacted your employer?", "answer": "Yes. I have contacted my employer by email and confirmed my position, work dates, and basic arrangements.", "category": "both", "tag": "雇主信息"},
            {"question": "Do you plan to travel after your work program?", "answer": "If time allows, I may travel for a short time, but I will return to China before school starts.", "category": "both", "tag": "旅行计划"},
        ],
    },
]


class VisaCardReq(BaseModel):
    question: str
    answer: str
    category: str = "both"
    tag: str = ""
    sort_order: int = 0


class VisaCardUpdateReq(BaseModel):
    question: Optional[str] = None
    answer: Optional[str] = None
    category: Optional[str] = None
    tag: Optional[str] = None
    sort_order: Optional[int] = None


class VisaCardsReplaceReq(BaseModel):
    cards: List[VisaCardReq]


def clean_card(data: dict) -> dict:
    question = str(data.get("question") or "").strip()
    answer = str(data.get("answer") or "").strip()
    if not question or not answer:
        raise HTTPException(400, "问题和参考答案不能为空")
    category = str(data.get("category") or "both").strip()
    if category not in VALID_CATEGORIES:
        raise HTTPException(400, "题目类别无效")
    return {
        "question": question[:4000],
        "answer": answer[:8000],
        "category": category,
        "tag": str(data.get("tag") or "").strip()[:100],
        "sort_order": int(data.get("sort_order") or 0),
    }


def user_card_or_404(db: Session, user_id: str, card_id: str) -> VisaCard:
    card = db.query(VisaCard).filter(VisaCard.id == card_id, VisaCard.user_id == user_id).first()
    if not card:
        raise HTTPException(404, "题目不存在")
    return card


@router.get("/templates")
def list_templates(user: User = Depends(get_current_user)):
    return [
        {"id": t["id"], "name": t["name"], "description": t["description"], "card_count": len(t["cards"])}
        for t in DEFAULT_TEMPLATES
    ]


@router.get("")
def list_cards(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    cards = db.query(VisaCard).filter(VisaCard.user_id == user.id).order_by(VisaCard.created_at.desc()).all()
    return [card.to_dict() for card in cards]


@router.post("", status_code=201)
def create_card(req: VisaCardReq, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    data = clean_card(req.model_dump())
    card = VisaCard(id=gen_id(), user_id=user.id, **data)
    db.add(card)
    db.commit()
    db.refresh(card)
    return card.to_dict()


@router.put("/{card_id}")
def update_card(card_id: str, req: VisaCardUpdateReq, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    card = user_card_or_404(db, user.id, card_id)
    data = req.model_dump(exclude_unset=True)
    merged = {
        "question": card.question,
        "answer": card.answer,
        "category": card.category,
        "tag": card.tag,
        "sort_order": card.sort_order,
        **data,
    }
    cleaned = clean_card(merged)
    for key, value in cleaned.items():
        setattr(card, key, value)
    card.updated_at = datetime.utcnow()
    db.commit()
    db.refresh(card)
    return card.to_dict()


@router.delete("/{card_id}")
def delete_card(card_id: str, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    card = user_card_or_404(db, user.id, card_id)
    db.delete(card)
    db.commit()
    return {"deleted": card_id}


@router.post("/replace")
def replace_cards(req: VisaCardsReplaceReq, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    db.query(VisaCard).filter(VisaCard.user_id == user.id).delete(synchronize_session=False)
    created = []
    for index, raw_card in enumerate(req.cards):
        data = clean_card({**raw_card.model_dump(), "sort_order": index})
        card = VisaCard(id=gen_id(), user_id=user.id, **data)
        db.add(card)
        created.append(card)
    db.commit()
    return {"count": len(created)}


@router.post("/templates/{template_id}/import")
def import_template(template_id: str, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    template = next((item for item in DEFAULT_TEMPLATES if item["id"] == template_id), None)
    if not template:
        raise HTTPException(404, "模板不存在")
    db.query(VisaCard).filter(VisaCard.user_id == user.id).delete(synchronize_session=False)
    for index, raw_card in enumerate(template["cards"]):
        data = clean_card({**raw_card, "sort_order": index})
        db.add(VisaCard(id=gen_id(), user_id=user.id, **data))
    db.commit()
    return {"count": len(template["cards"]), "template": template["name"]}
