"""论坛路由 - 板块 / 帖子 / 回复 / 点赞 / 举报 / 通知 / 草稿"""

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel
from typing import Optional, List
from sqlalchemy.orm import Session
from sqlalchemy import func, or_
from datetime import datetime, timedelta

from database import (
    Category, Post, Comment, PostLike, Favorite, User, Report, Notification,
    Announcement, AnnouncementRead, Draft, SensitiveWord, get_db, gen_id
)
from translation_service import apply_translation, apply_translations, get_translations, normalize_locale
from auth import get_current_user, get_current_user_optional, require_admin

router = APIRouter(prefix="/api/forum", tags=["forum"])


# ── Schemas ───────────────────────────────────────────────
class PostReq(BaseModel):
    category_id: str
    title: str
    body: str = ""
    tags: List[str] = []
    image_urls: List[str] = []


class PostUpdateReq(BaseModel):
    title: Optional[str] = None
    body: Optional[str] = None
    category_id: Optional[str] = None
    tags: Optional[List[str]] = None
    image_urls: Optional[List[str]] = None


class CommentReq(BaseModel):
    body: str


class ReportReq(BaseModel):
    target_type: str
    target_id: str
    reason: str = ""
    detail: str = ""


class DraftReq(BaseModel):
    category_id: Optional[str] = None
    title: str = ""
    body: str = ""
    tags: List[str] = []
    image_urls: List[str] = []


def clean_tags(tags) -> list:
    result = []
    for tag in tags or []:
        t = str(tag).strip().lstrip("#")[:24]
        if t and t not in result:
            result.append(t)
    return result[:5]


def clean_image_urls(urls) -> list:
    result = []
    for url in urls or []:
        u = str(url).strip()
        if u.startswith(("http://", "https://")) and u not in result:
            result.append(u[:1000])
    return result[:6]


def ensure_can_write(user: User):
    if user.ban_until and user.ban_until > datetime.utcnow():
        raise HTTPException(403, f"账号已被封禁至 {user.ban_until.isoformat()}Z")


def check_sensitive_words(db: Session, text: str):
    if not text:
        return
    lowered = text.lower()
    words = db.query(SensitiveWord).filter(SensitiveWord.is_active == True).all()
    for item in words:
        if item.word and item.word.lower() in lowered:
            raise HTTPException(400, f"内容包含敏感词：{item.word}")


def check_rate_limit(db: Session, user_id: str, model, minutes: int, limit: int, label: str):
    since = datetime.utcnow() - timedelta(minutes=minutes)
    count = (
        db.query(func.count(model.id))
        .filter(model.author_id == user_id, model.created_at >= since)
        .scalar()
    )
    if count >= limit:
        raise HTTPException(429, f"{label}过于频繁，请稍后再试")


def add_notification(
    db: Session,
    user_id: str,
    actor_id: Optional[str],
    type_: str,
    title: str,
    body: str = "",
    target_type: str = "",
    target_id: str = "",
):
    if not user_id or user_id == actor_id:
        return
    db.add(Notification(
        id=gen_id(), user_id=user_id, actor_id=actor_id, type=type_,
        title=title[:200], body=body[:500], target_type=target_type, target_id=target_id
    ))


# ════════════════════════════════════════════════════════
# 板块 Categories
# ════════════════════════════════════════════════════════
@router.get("/categories")
def list_categories(locale: str = "zh", db: Session = Depends(get_db)):
    cats = db.query(Category).order_by(Category.sort_order).all()
    # 统计每个板块帖子数
    counts = dict(
        db.query(Post.category_id, func.count(Post.id)).group_by(Post.category_id).all()
    )
    items = [c.to_dict(post_count=counts.get(c.id, 0)) for c in cats]
    if normalize_locale(locale) == "en":
        items = apply_translations(items, get_translations(db, "category", [c.id for c in cats]), locale)
    return items


@router.get("/categories/{slug}")
def get_category(slug: str, locale: str = "zh", db: Session = Depends(get_db)):
    cat = db.query(Category).filter(Category.slug == slug).first()
    if not cat:
        raise HTTPException(404, "板块不存在")
    count = db.query(func.count(Post.id)).filter(Post.category_id == cat.id).scalar()
    item = cat.to_dict(post_count=count)
    if normalize_locale(locale) == "en":
        item = apply_translation(item, get_translations(db, "category", [cat.id]).get(cat.id), locale)
    return item


# ════════════════════════════════════════════════════════
# 帖子 Posts
# ════════════════════════════════════════════════════════
@router.get("/posts")
def list_posts(
    category_slug: Optional[str] = None,
    search: Optional[str] = None,
    tag: Optional[str] = None,
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=50),
    sort: str = "latest_reply",  # latest_reply | latest | hot
    locale: str = "zh",
    db: Session = Depends(get_db),
    me: Optional[User] = Depends(get_current_user_optional),
):
    q = db.query(Post).filter(Post.status == "published")
    if category_slug:
        cat = db.query(Category).filter(Category.slug == category_slug).first()
        if not cat:
            raise HTTPException(404, "板块不存在")
        q = q.filter(Post.category_id == cat.id)

    if search and search.strip():
        like = f"%{search.strip()}%"
        q = q.join(User, Post.author_id == User.id).filter(
            or_(
                Post.title.ilike(like),
                Post.body.ilike(like),
                User.username.ilike(like),
            )
        )
    if tag and tag.strip():
        q = q.filter(Post.tags.ilike(f"%{tag.strip().lstrip('#')}%"))

    # 置顶帖永远在前
    if sort == "hot":
        q = q.order_by(Post.is_pinned.desc(), Post.view_count.desc(), Post.created_at.desc())
    elif sort == "latest":
        q = q.order_by(Post.is_pinned.desc(), Post.created_at.desc())
    else:
        q = q.order_by(Post.is_pinned.desc(), Post.last_activity_at.desc(), Post.created_at.desc())

    total = q.count()
    posts = q.offset((page - 1) * page_size).limit(page_size).all()

    # 批量统计回复数、点赞数、收藏数
    post_ids = [p.id for p in posts]
    comment_counts = dict(
        db.query(Comment.post_id, func.count(Comment.id))
        .filter(Comment.post_id.in_(post_ids)).group_by(Comment.post_id).all()
    ) if post_ids else {}
    like_counts = dict(
        db.query(PostLike.post_id, func.count(PostLike.id))
        .filter(PostLike.post_id.in_(post_ids)).group_by(PostLike.post_id).all()
    ) if post_ids else {}
    favorite_counts = dict(
        db.query(Favorite.target_id, func.count(Favorite.id))
        .filter(Favorite.target_type == "post", Favorite.target_id.in_(post_ids))
        .group_by(Favorite.target_id).all()
    ) if post_ids else {}
    my_likes = set()
    my_favorites = set()
    if me and post_ids:
        my_likes = {
            pl.post_id for pl in
            db.query(PostLike).filter(PostLike.post_id.in_(post_ids), PostLike.user_id == me.id).all()
        }
        my_favorites = {
            f.target_id for f in
            db.query(Favorite).filter(
                Favorite.target_type == "post",
                Favorite.target_id.in_(post_ids),
                Favorite.user_id == me.id,
            ).all()
        }

    items = [
        p.to_dict(
            comment_count=comment_counts.get(p.id, 0),
            like_count=like_counts.get(p.id, 0),
            liked_by_me=p.id in my_likes,
            favorite_count=favorite_counts.get(p.id, 0),
            favorited_by_me=p.id in my_favorites,
        ) for p in posts
    ]
    if normalize_locale(locale) == "en":
        items = apply_translations(items, get_translations(db, "post", post_ids), locale)
    return {"total": total, "page": page, "page_size": page_size,
            "pages": (total + page_size - 1) // page_size, "posts": items}


@router.get("/posts/{post_id}")
def get_post(post_id: str, db: Session = Depends(get_db),
             me: Optional[User] = Depends(get_current_user_optional),
             locale: str = "zh"):
    post = db.query(Post).filter(Post.id == post_id).first()
    if not post:
        raise HTTPException(404, "帖子不存在")
    if post.status != "published" and (not me or me.role != "admin"):
        raise HTTPException(404, "帖子不存在")
    # 浏览数 +1
    post.view_count = (post.view_count or 0) + 1
    db.commit()
    db.refresh(post)

    comment_count = db.query(func.count(Comment.id)).filter(Comment.post_id == post_id).scalar()
    like_count = db.query(func.count(PostLike.id)).filter(PostLike.post_id == post_id).scalar()
    favorite_count = db.query(func.count(Favorite.id)).filter(
        Favorite.target_type == "post",
        Favorite.target_id == post_id,
    ).scalar()
    liked = False
    favorited = False
    if me:
        liked = db.query(PostLike).filter(PostLike.post_id == post_id, PostLike.user_id == me.id).first() is not None
        favorited = db.query(Favorite).filter(
            Favorite.target_type == "post",
            Favorite.target_id == post_id,
            Favorite.user_id == me.id,
        ).first() is not None
    item = post.to_dict(
        comment_count=comment_count,
        like_count=like_count,
        liked_by_me=liked,
        favorite_count=favorite_count,
        favorited_by_me=favorited,
    )
    if normalize_locale(locale) == "en":
        item = apply_translation(item, get_translations(db, "post", [post_id]).get(post_id), locale)
    return item


@router.post("/posts", status_code=201)
def create_post(req: PostReq, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    ensure_can_write(user)
    check_rate_limit(db, user.id, Post, minutes=10, limit=5, label="发帖")
    if not req.title.strip():
        raise HTTPException(400, "标题不能为空")
    check_sensitive_words(db, f"{req.title}\n{req.body}")
    cat = db.query(Category).filter(Category.id == req.category_id).first()
    if not cat:
        raise HTTPException(400, "板块不存在")
    post = Post(id=gen_id(), category_id=req.category_id, author_id=user.id,
                title=req.title.strip()[:300], body=req.body,
                tags=clean_tags(req.tags), image_urls=clean_image_urls(req.image_urls),
                status="published", last_activity_at=datetime.utcnow())
    user.reputation = (user.reputation or 0) + 5
    db.add(post)
    db.commit()
    db.refresh(post)
    return post.to_dict(comment_count=0, like_count=0)


@router.put("/posts/{post_id}")
def update_post(post_id: str, req: PostUpdateReq,
                user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    post = db.query(Post).filter(Post.id == post_id).first()
    if not post:
        raise HTTPException(404, "帖子不存在")
    # 作者本人或管理员可编辑
    if post.author_id != user.id and user.role != "admin":
        raise HTTPException(403, "无权编辑")
    if req.title is not None:
        check_sensitive_words(db, req.title)
        post.title = req.title.strip()[:300]
    if req.body is not None:
        check_sensitive_words(db, req.body)
        post.body = req.body
    if req.category_id is not None:
        post.category_id = req.category_id
    if req.tags is not None:
        post.tags = clean_tags(req.tags)
    if req.image_urls is not None:
        post.image_urls = clean_image_urls(req.image_urls)
    db.commit()
    db.refresh(post)
    return post.to_dict()


@router.delete("/posts/{post_id}")
def delete_post(post_id: str, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    post = db.query(Post).filter(Post.id == post_id).first()
    if not post:
        raise HTTPException(404, "帖子不存在")
    if post.author_id != user.id and user.role != "admin":
        raise HTTPException(403, "无权删除")
    db.delete(post)
    db.commit()
    return {"deleted": post_id}


@router.post("/posts/{post_id}/favorite")
def toggle_post_favorite(post_id: str, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    ensure_can_write(user)
    post = db.query(Post).filter(Post.id == post_id).first()
    if not post:
        raise HTTPException(404, "帖子不存在")
    existing = db.query(Favorite).filter(
        Favorite.user_id == user.id,
        Favorite.target_type == "post",
        Favorite.target_id == post_id,
    ).first()
    if existing:
        db.delete(existing)
        favorited = False
    else:
        db.add(Favorite(id=gen_id(), user_id=user.id, target_type="post", target_id=post_id))
        favorited = True
    db.commit()
    count = db.query(func.count(Favorite.id)).filter(
        Favorite.target_type == "post",
        Favorite.target_id == post_id,
    ).scalar()
    return {"favorited": favorited, "favorite_count": count}


# ── 点赞 ──────────────────────────────────────────────────
@router.post("/posts/{post_id}/like")
def toggle_like(post_id: str, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    ensure_can_write(user)
    post = db.query(Post).filter(Post.id == post_id).first()
    if not post:
        raise HTTPException(404, "帖子不存在")
    existing = db.query(PostLike).filter(PostLike.post_id == post_id, PostLike.user_id == user.id).first()
    if existing:
        db.delete(existing)
        liked = False
    else:
        db.add(PostLike(id=gen_id(), post_id=post_id, user_id=user.id))
        if post.author_id != user.id:
            author = db.query(User).filter(User.id == post.author_id).first()
            if author:
                author.reputation = (author.reputation or 0) + 1
            add_notification(
                db, post.author_id, user.id, "like",
                "你的帖子收到了新的点赞", post.title,
                "post", post_id
            )
        liked = True
    db.commit()
    count = db.query(func.count(PostLike.id)).filter(PostLike.post_id == post_id).scalar()
    return {"liked": liked, "like_count": count}


# ════════════════════════════════════════════════════════
# 回复 Comments
# ════════════════════════════════════════════════════════
@router.get("/posts/{post_id}/comments")
def list_comments(post_id: str, locale: str = "zh", db: Session = Depends(get_db)):
    comments = db.query(Comment).filter(Comment.post_id == post_id).order_by(Comment.created_at).all()
    items = [c.to_dict() for c in comments]
    if normalize_locale(locale) == "en":
        items = apply_translations(items, get_translations(db, "comment", [c.id for c in comments]), locale)
    return items


@router.post("/posts/{post_id}/comments", status_code=201)
def create_comment(post_id: str, req: CommentReq,
                   user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    ensure_can_write(user)
    check_rate_limit(db, user.id, Comment, minutes=5, limit=10, label="回复")
    post = db.query(Post).filter(Post.id == post_id).first()
    if not post:
        raise HTTPException(404, "帖子不存在")
    if post.is_locked:
        raise HTTPException(403, "该帖已锁定，无法回复")
    if not req.body.strip():
        raise HTTPException(400, "回复内容不能为空")
    check_sensitive_words(db, req.body)
    c = Comment(id=gen_id(), post_id=post_id, author_id=user.id, body=req.body.strip())
    db.add(c)
    post.last_activity_at = datetime.utcnow()
    user.reputation = (user.reputation or 0) + 2
    add_notification(
        db, post.author_id, user.id, "comment",
        "你的帖子有新回复", req.body.strip(),
        "post", post_id
    )
    db.commit()
    db.refresh(c)
    return c.to_dict()


@router.post("/posts/{post_id}/quote")
def quote_post(post_id: str, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    ensure_can_write(user)
    post = db.query(Post).filter(Post.id == post_id).first()
    if not post:
        raise HTTPException(404, "帖子不存在")
    return {
        "title": f"Re: {post.title}",
        "body": f"> {post.title}\n\n",
        "category_id": post.category_id,
        "tags": list(post.tags or []),
        "image_urls": [],
    }


@router.delete("/comments/{comment_id}")
def delete_comment(comment_id: str, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    c = db.query(Comment).filter(Comment.id == comment_id).first()
    if not c:
        raise HTTPException(404, "回复不存在")
    if c.author_id != user.id and user.role != "admin":
        raise HTTPException(403, "无权删除")
    db.delete(c)
    db.commit()
    return {"deleted": comment_id}


# ════════════════════════════════════════════════════════
# 举报 Reports
# ════════════════════════════════════════════════════════
@router.post("/reports", status_code=201)
def create_report(req: ReportReq, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    ensure_can_write(user)
    if req.target_type not in ("post", "comment"):
        raise HTTPException(400, "举报对象类型错误")
    if req.target_type == "post":
        target = db.query(Post).filter(Post.id == req.target_id).first()
    else:
        target = db.query(Comment).filter(Comment.id == req.target_id).first()
    if not target:
        raise HTTPException(404, "举报对象不存在")
    existing = db.query(Report).filter(
        Report.target_type == req.target_type,
        Report.target_id == req.target_id,
        Report.reporter_id == user.id,
        Report.status == "open",
    ).first()
    if existing:
        return existing.to_dict()
    report = Report(
        id=gen_id(), target_type=req.target_type, target_id=req.target_id,
        reporter_id=user.id, reason=req.reason.strip()[:80],
        detail=req.detail.strip()[:1000], status="open"
    )
    db.add(report)
    db.commit()
    db.refresh(report)
    return report.to_dict()


# ════════════════════════════════════════════════════════
# 通知 Notifications
# ════════════════════════════════════════════════════════
@router.get("/notifications")
def list_notifications(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    now = datetime.utcnow()
    personal = db.query(Notification).filter(Notification.user_id == user.id).order_by(Notification.created_at.desc()).limit(50).all()
    personal_unread = db.query(func.count(Notification.id)).filter(Notification.user_id == user.id, Notification.is_read == False).scalar()

    announcements = db.query(Announcement).filter(Announcement.is_active == True).filter(
        or_(Announcement.starts_at.is_(None), Announcement.starts_at <= now),
        or_(Announcement.ends_at.is_(None), Announcement.ends_at >= now),
    ).order_by(Announcement.is_pinned.desc(), Announcement.updated_at.desc()).limit(20).all()
    read_ids = {
        x.announcement_id for x in db.query(AnnouncementRead)
        .filter(AnnouncementRead.user_id == user.id)
        .filter(AnnouncementRead.announcement_id.in_([a.id for a in announcements]))
        .all()
    } if announcements else set()

    announcement_items = []
    for a in announcements:
        d = a.to_dict(is_read=a.id in read_ids)
        announcement_items.append({
            "id": f"announcement:{a.id}",
            "announcement_id": a.id,
            "user_id": user.id,
            "actor_id": a.created_by,
            "actor_name": a.creator.username if a.creator else None,
            "type": "announcement",
            "title": d["title"],
            "body": d["body"],
            "level": d["level"],
            "link_url": d["link_url"],
            "target_type": "announcement",
            "target_id": a.id,
            "is_read": d["is_read"],
            "is_pinned": d["is_pinned"],
            "created_at": d["updated_at"] or d["created_at"],
        })

    personal_items = [n.to_dict() for n in personal]
    notifications = sorted(
        announcement_items + personal_items,
        key=lambda x: (x.get("is_pinned", False), x.get("created_at") or ""),
        reverse=True,
    )
    unread_announcements = sum(1 for x in announcement_items if not x["is_read"])
    return {"unread": personal_unread + unread_announcements, "notifications": notifications[:70]}


@router.post("/notifications/read")
def mark_notifications_read(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    db.query(Notification).filter(Notification.user_id == user.id, Notification.is_read == False).update(
        {"is_read": True}, synchronize_session=False
    )
    now = datetime.utcnow()
    announcements = db.query(Announcement).filter(Announcement.is_active == True).filter(
        or_(Announcement.starts_at.is_(None), Announcement.starts_at <= now),
        or_(Announcement.ends_at.is_(None), Announcement.ends_at >= now),
    ).all()
    existing = {
        x.announcement_id for x in db.query(AnnouncementRead)
        .filter(AnnouncementRead.user_id == user.id)
        .filter(AnnouncementRead.announcement_id.in_([a.id for a in announcements]))
        .all()
    } if announcements else set()
    for announcement in announcements:
        if announcement.id not in existing:
            db.add(AnnouncementRead(id=gen_id(), announcement_id=announcement.id, user_id=user.id))
    db.commit()
    return {"ok": True}


# ════════════════════════════════════════════════════════
# 草稿 Drafts
# ════════════════════════════════════════════════════════
@router.get("/drafts")
def list_drafts(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    drafts = db.query(Draft).filter(Draft.user_id == user.id).order_by(Draft.updated_at.desc()).all()
    return [d.to_dict() for d in drafts]


@router.post("/drafts")
def save_draft(req: DraftReq, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    ensure_can_write(user)
    draft = Draft(
        id=gen_id(), user_id=user.id, category_id=req.category_id,
        title=req.title.strip()[:300], body=req.body,
        tags=clean_tags(req.tags), image_urls=clean_image_urls(req.image_urls)
    )
    db.add(draft)
    db.commit()
    db.refresh(draft)
    return draft.to_dict()


@router.put("/drafts/{draft_id}")
def update_draft(draft_id: str, req: DraftReq, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    ensure_can_write(user)
    draft = db.query(Draft).filter(Draft.id == draft_id, Draft.user_id == user.id).first()
    if not draft:
        raise HTTPException(404, "草稿不存在")
    draft.category_id = req.category_id
    draft.title = req.title.strip()[:300]
    draft.body = req.body
    draft.tags = clean_tags(req.tags)
    draft.image_urls = clean_image_urls(req.image_urls)
    draft.updated_at = datetime.utcnow()
    db.commit()
    db.refresh(draft)
    return draft.to_dict()


@router.delete("/drafts/{draft_id}")
def delete_draft(draft_id: str, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    draft = db.query(Draft).filter(Draft.id == draft_id, Draft.user_id == user.id).first()
    if not draft:
        raise HTTPException(404, "草稿不存在")
    db.delete(draft)
    db.commit()
    return {"deleted": draft_id}


# ── 我的帖子 ──────────────────────────────────────────────
@router.get("/my/posts")
def my_posts(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    posts = db.query(Post).filter(Post.author_id == user.id).order_by(Post.created_at.desc()).all()
    post_ids = [p.id for p in posts]
    comment_counts = dict(
        db.query(Comment.post_id, func.count(Comment.id))
        .filter(Comment.post_id.in_(post_ids)).group_by(Comment.post_id).all()
    ) if post_ids else {}
    like_counts = dict(
        db.query(PostLike.post_id, func.count(PostLike.id))
        .filter(PostLike.post_id.in_(post_ids)).group_by(PostLike.post_id).all()
    ) if post_ids else {}
    favorite_counts = dict(
        db.query(Favorite.target_id, func.count(Favorite.id))
        .filter(Favorite.target_type == "post", Favorite.target_id.in_(post_ids))
        .group_by(Favorite.target_id).all()
    ) if post_ids else {}
    return [
        p.to_dict(
            comment_count=comment_counts.get(p.id, 0),
            like_count=like_counts.get(p.id, 0),
            favorite_count=favorite_counts.get(p.id, 0),
            favorited_by_me=True,
        ) for p in posts
    ]


@router.get("/my/favorites")
def my_favorite_posts(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    favorites = db.query(Favorite).filter(
        Favorite.user_id == user.id,
        Favorite.target_type == "post",
    ).order_by(Favorite.created_at.desc()).all()
    ids = [f.target_id for f in favorites]
    posts = {p.id: p for p in db.query(Post).filter(Post.id.in_(ids)).all()} if ids else {}
    items = []
    for fav in favorites:
        post = posts.get(fav.target_id)
        if not post:
            continue
        items.append(post.to_dict(favorited_by_me=True))
    return {"favorites": items}
