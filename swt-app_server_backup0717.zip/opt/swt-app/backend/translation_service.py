import hashlib
import json
from datetime import datetime
from typing import Iterable, Optional

from sqlalchemy.orm import Session

from ai_service import chat_json, get_or_create_ai_config, is_ai_ready
from database import Category, Comment, Post, RecordModel, Translation, gen_id


SUPPORTED_LOCALES = {"en"}


def normalize_locale(locale: Optional[str]) -> str:
    value = (locale or "zh").lower().strip()
    return "en" if value.startswith("en") else "zh"


def source_hash(fields: dict) -> str:
    payload = json.dumps(fields or {}, ensure_ascii=False, sort_keys=True)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def record_fields(record: RecordModel) -> dict:
    return {
        "job_position": record.job_position or "",
        "location_name": record.location_name or "",
        "city": record.city or "",
        "tips": record.tips or "",
        "avoidance_reasons": record.avoidance_reasons or [],
        "employer": record.employer or "",
        "summary": record.summary or "",
    }


def post_fields(post: Post) -> dict:
    return {
        "title": post.title or "",
        "body": post.body or "",
        "tags": post.tags or [],
    }


def comment_fields(comment: Comment) -> dict:
    return {"body": comment.body or ""}


def category_fields(category: Category) -> dict:
    return {
        "name": category.name or "",
        "description": category.description or "",
    }


ENTITY_BUILDERS = {
    "record": (RecordModel, record_fields),
    "post": (Post, post_fields),
    "comment": (Comment, comment_fields),
    "category": (Category, category_fields),
}


def apply_translation(data: dict, translation: Optional[Translation], locale: Optional[str]) -> dict:
    if normalize_locale(locale) != "en" or not translation or translation.status != "translated":
        return data
    fields = translation.fields_json or {}
    if not fields:
        return data
    result = dict(data)
    for key, value in fields.items():
        if value not in (None, ""):
            result[key] = value
    result["_translation"] = {"locale": "en", "status": "translated"}
    return result


def apply_translations(items: list[dict], translations: dict[str, Translation], locale: Optional[str]) -> list[dict]:
    if normalize_locale(locale) != "en":
        return items
    return [apply_translation(item, translations.get(item.get("id")), locale) for item in items]


def get_translations(db: Session, entity_type: str, ids: Iterable[str], locale: str = "en") -> dict[str, Translation]:
    id_list = [x for x in ids if x]
    if not id_list:
        return {}
    rows = db.query(Translation).filter(
        Translation.entity_type == entity_type,
        Translation.locale == locale,
        Translation.entity_id.in_(id_list),
    ).all()
    return {x.entity_id: x for x in rows}


def ensure_translation_row(db: Session, entity_type: str, entity_id: str, fields: dict, locale: str = "en") -> Translation:
    h = source_hash(fields)
    row = db.query(Translation).filter(
        Translation.entity_type == entity_type,
        Translation.entity_id == entity_id,
        Translation.locale == locale,
    ).first()
    now = datetime.utcnow()
    if not row:
        row = Translation(
            id=gen_id(),
            entity_type=entity_type,
            entity_id=entity_id,
            locale=locale,
            source_hash=h,
            fields_json={},
            status="pending",
            created_at=now,
            updated_at=now,
        )
        db.add(row)
        return row
    if row.source_hash != h:
        row.source_hash = h
        row.status = "stale"
        row.error = ""
        row.updated_at = now
    return row


def scan_translations(db: Session, locale: str = "en") -> dict:
    locale = normalize_locale(locale)
    if locale == "zh":
        locale = "en"
    counts = {"pending": 0, "translated": 0, "stale": 0, "failed": 0}
    total = 0
    by_type = {}
    for entity_type, (model, builder) in ENTITY_BUILDERS.items():
        rows = db.query(model).all()
        type_counts = {"pending": 0, "translated": 0, "stale": 0, "failed": 0}
        for item in rows:
            tr = ensure_translation_row(db, entity_type, item.id, builder(item), locale)
            status = tr.status or "pending"
            type_counts[status] = type_counts.get(status, 0) + 1
            counts[status] = counts.get(status, 0) + 1
            total += 1
        by_type[entity_type] = type_counts
    db.commit()
    return {
        "locale": locale,
        "total": total,
        "counts": counts,
        "by_type": by_type,
        "ai_ready": is_ai_ready(get_or_create_ai_config(db)),
    }


def translate_fields(db: Session, entity_type: str, fields: dict, locale: str = "en") -> dict:
    prompt = (
        "Translate the JSON values from Chinese to natural, concise English for a SWT/J-1 community website. "
        "Keep numbers, URLs, IDs, state abbreviations, wages, and proper nouns when appropriate. "
        "Return ONLY valid JSON with exactly the same keys. For arrays, return translated arrays."
    )
    result = chat_json(
        db,
        [
            {"role": "system", "content": prompt},
            {"role": "user", "content": json.dumps({"entity_type": entity_type, "fields": fields}, ensure_ascii=False)},
        ],
        temperature=0.1,
        timeout=45,
    )
    if not result:
        raise RuntimeError("AI is not configured or returned no result")
    translated = result.get("fields") if isinstance(result.get("fields"), dict) else result
    if not isinstance(translated, dict):
        raise RuntimeError("AI response is not a JSON object")
    return {key: translated.get(key, value) for key, value in fields.items()}


def run_translation_batch(db: Session, locale: str = "en", limit: int = 20, retry_failed: bool = False) -> dict:
    locale = normalize_locale(locale)
    if locale == "zh":
        locale = "en"
    config = get_or_create_ai_config(db)
    if not is_ai_ready(config):
        raise RuntimeError("AI config is not enabled or API key is missing")
    scan_translations(db, locale)
    statuses = ["pending", "stale"]
    if retry_failed:
        statuses.append("failed")
    rows = db.query(Translation).filter(
        Translation.locale == locale,
        Translation.status.in_(statuses),
    ).order_by(Translation.updated_at.asc()).limit(max(1, min(limit, 100))).all()
    processed = 0
    failed = 0
    for row in rows:
        model, builder = ENTITY_BUILDERS.get(row.entity_type, (None, None))
        if not model:
            row.status = "failed"
            row.error = "Unsupported entity type"
            failed += 1
            continue
        entity = db.query(model).filter(model.id == row.entity_id).first()
        if not entity:
            db.delete(row)
            continue
        fields = builder(entity)
        row.source_hash = source_hash(fields)
        try:
            row.fields_json = translate_fields(db, row.entity_type, fields, locale)
            row.status = "translated"
            row.error = ""
            processed += 1
        except Exception as exc:
            row.status = "failed"
            row.error = str(exc)[:1000]
            failed += 1
        row.updated_at = datetime.utcnow()
        db.commit()
    summary = scan_translations(db, locale)
    summary.update({"processed": processed, "failed_in_batch": failed})
    return summary
