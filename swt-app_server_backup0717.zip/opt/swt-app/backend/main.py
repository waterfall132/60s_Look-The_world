"""SWT 避雷数据后端 API - FastAPI + SQLAlchemy

包含：
  避雷记录 CRUD / 统计 / 地图数据（公开）
  导入导出（仅管理员）
  认证、论坛、管理员路由（见 routes_*.py）
"""
import urllib.parse
from fastapi import FastAPI, HTTPException, UploadFile, File, Query, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.trustedhost import TrustedHostMiddleware
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from typing import Optional, List
from sqlalchemy.orm import Session
from sqlalchemy import func, or_
import json, uuid, io, os, re
from functools import lru_cache
from datetime import datetime
from pathlib import Path
from urllib.parse import urlsplit, urlunsplit
from urllib import request as urllib_request

from database import (
    RecordModel, Favorite, FavoriteGroup, RecordFeedback, Notification,
    SiteSetting, get_db, init_db
)
from translation_service import apply_translation, apply_translations, get_translations, normalize_locale
from auth import require_admin, get_current_user, get_current_user_optional
from database import User

# 路由模块
from routes_auth import router as auth_router
from routes_forum import router as forum_router
from routes_admin import router as admin_router
from routes_assessment import router as assessment_router
from routes_visa_cards import router as visa_cards_router
from routes_paypal import router as paypal_router
from security import security_middleware, robots_txt


def csv_env(name: str, default: str) -> list[str]:
    return [x.strip() for x in os.getenv(name, default).split(",") if x.strip()]

app = FastAPI(title="SWT 避雷 API", version="3.0.0")
allowed_hosts = csv_env("ALLOWED_HOSTS", "*")
if allowed_hosts != ["*"]:
    app.add_middleware(TrustedHostMiddleware, allowed_hosts=allowed_hosts)

cors_origins = csv_env("CORS_ORIGINS", "*")
app.add_middleware(
    CORSMiddleware,
    allow_origins=cors_origins,
    allow_methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    allow_headers=["Authorization", "Content-Type"],
    allow_credentials=cors_origins != ["*"],
)
app.middleware("http")(security_middleware)

# 启动时建表 + 初始化默认管理员/板块
init_db()

# 注册路由
app.include_router(auth_router)
app.include_router(forum_router)
app.include_router(admin_router)
app.include_router(assessment_router)
app.include_router(visa_cards_router)
app.include_router(paypal_router)


@app.get("/robots.txt", include_in_schema=False)
def robots():
    return robots_txt()


DEFAULT_VIP_CONTACT = "请联系管理员开通 VIP：\n微信：请在后台配置\n邮箱：admin@swt.local"


def get_setting_value(db: Session, key: str, default: str = "") -> str:
    item = db.query(SiteSetting).filter(SiteSetting.key == key).first()
    return item.value if item and item.value else default


@app.get("/api/site-settings/vip-contact")
def public_vip_contact(db: Session = Depends(get_db)):
    return {"vip_contact": get_setting_value(db, "vip_contact", DEFAULT_VIP_CONTACT)}


# ── Pydantic Schema ───────────────────────────────────────
class Record(BaseModel):
    id: Optional[str] = None
    valuable: bool = True
    source_type: Optional[str] = "post"
    job_position: Optional[str] = None
    location_name: Optional[str] = None
    city: Optional[str] = None
    state: Optional[str] = None
    hourly_wage: Optional[float] = None
    tips: Optional[str] = None
    hours_per_day: Optional[float] = None
    hours_per_week: Optional[float] = None
    avoidance_reasons: Optional[List[str]] = []
    severity: Optional[int] = 3
    confidence: Optional[float] = 0.8
    employer: Optional[str] = None
    summary: Optional[str] = ""
    note_url: Optional[str] = ""


class RecordFeedbackReq(BaseModel):
    reason: str = ""
    detail: str = ""


class RecordSubmitReq(Record):
    pass


class FavoriteGroupReq(BaseModel):
    name: str
    sort_order: int = 0


class FavoriteMoveReq(BaseModel):
    group_id: Optional[str] = None


class RecordReviewReq(BaseModel):
    review_status: str
    review_note: Optional[str] = ""


STATE_COORDS = {
    "AL":[32.8,-86.8],"AK":[64.2,-153.4],"AZ":[34.3,-111.1],"AR":[34.8,-92.2],
    "CA":[36.8,-119.4],"CO":[39.0,-105.5],"CT":[41.6,-72.7],"DE":[39.0,-75.5],
    "FL":[27.8,-81.7],"GA":[33.0,-83.6],"HI":[20.8,-156.3],"ID":[44.2,-114.5],
    "IL":[40.0,-89.2],"IN":[39.8,-86.1],"IA":[42.0,-93.2],"KS":[38.5,-96.4],
    "KY":[37.5,-85.3],"LA":[31.1,-91.9],"ME":[45.2,-69.0],"MD":[39.0,-76.8],
    "MA":[42.2,-71.5],"MI":[44.2,-85.6],"MN":[46.4,-93.1],"MS":[32.7,-89.7],
    "MO":[38.4,-92.3],"MT":[47.0,-110.5],"NE":[41.5,-99.9],"NV":[38.8,-116.4],
    "NH":[43.7,-71.6],"NJ":[40.1,-74.4],"NM":[34.5,-106.2],"NY":[42.9,-75.5],
    "NC":[35.5,-79.4],"ND":[47.4,-100.4],"OH":[40.3,-82.8],"OK":[35.6,-96.9],
    "OR":[44.6,-122.1],"PA":[40.6,-77.2],"RI":[41.7,-71.6],"SC":[33.8,-80.9],
    "SD":[44.3,-100.2],"TN":[35.9,-86.7],"TX":[31.1,-97.6],"UT":[39.3,-111.1],
    "VT":[44.0,-72.7],"VA":[37.8,-79.5],"WA":[47.4,-120.5],"WV":[38.6,-80.5],
    "WI":[44.3,-89.8],"WY":[43.0,-107.6]
}

STATE_NAME_TO_ABBR = {
    "ALABAMA": "AL",
    "ALASKA": "AK",
    "ARIZONA": "AZ",
    "ARKANSAS": "AR",
    "CALIFORNIA": "CA",
    "COLORADO": "CO",
    "CONNECTICUT": "CT",
    "DELAWARE": "DE",
    "FLORIDA": "FL",
    "GEORGIA": "GA",
    "HAWAII": "HI",
    "IDAHO": "ID",
    "ILLINOIS": "IL",
    "INDIANA": "IN",
    "IOWA": "IA",
    "KANSAS": "KS",
    "KENTUCKY": "KY",
    "LOUISIANA": "LA",
    "MAINE": "ME",
    "MARYLAND": "MD",
    "MASSACHUSETTS": "MA",
    "MICHIGAN": "MI",
    "MINNESOTA": "MN",
    "MISSISSIPPI": "MS",
    "MISSOURI": "MO",
    "MONTANA": "MT",
    "NEBRASKA": "NE",
    "NEVADA": "NV",
    "NEW HAMPSHIRE": "NH",
    "NEW JERSEY": "NJ",
    "NEW MEXICO": "NM",
    "NEW YORK": "NY",
    "NORTH CAROLINA": "NC",
    "NORTH DAKOTA": "ND",
    "OHIO": "OH",
    "OKLAHOMA": "OK",
    "OREGON": "OR",
    "PENNSYLVANIA": "PA",
    "RHODE ISLAND": "RI",
    "SOUTH CAROLINA": "SC",
    "SOUTH DAKOTA": "SD",
    "TENNESSEE": "TN",
    "TEXAS": "TX",
    "UTAH": "UT",
    "VERMONT": "VT",
    "VIRGINIA": "VA",
    "WASHINGTON": "WA",
    "WEST VIRGINIA": "WV",
    "WISCONSIN": "WI",
    "WYOMING": "WY",
}

STATE_ABBR_TO_NAME = {abbr: name.title() for name, abbr in STATE_NAME_TO_ABBR.items()}


def now_iso():
    return datetime.utcnow().isoformat() + "Z"


def compact_text(value) -> str:
    return re.sub(r"\s+", " ", str(value or "").strip())


def normalize_state_code(value) -> str:
    raw = compact_text(value).upper().replace(".", "")
    if not raw:
        return ""
    if raw in STATE_COORDS:
        return raw
    return STATE_NAME_TO_ABBR.get(raw, "")


def match_state_in_text(text: str, allow_abbr: bool = True) -> str:
    raw = compact_text(text)
    if not raw:
        return ""
    upper = raw.upper()
    for name, abbr in STATE_NAME_TO_ABBR.items():
        if re.search(rf"\b{re.escape(name)}\b", upper):
            return abbr
    if allow_abbr:
        for abbr in STATE_COORDS:
            if re.search(rf"(?:^|[\s,()/\-]){abbr}(?:$|[\s,()/\-])", upper):
                return abbr
    return ""


def build_city_state_hints(db: Session):
    hints = {}
    office_path = Path(__file__).with_name("ssa_offices.json")
    if office_path.exists():
        try:
            offices = json.loads(office_path.read_text(encoding="utf-8"))
            for item in offices:
                city = compact_text(item.get("city")).upper()
                state = normalize_state_code(item.get("state"))
                if city and state:
                    hints.setdefault(city, state)
        except Exception:
            pass

    try:
        rows = db.query(RecordModel.city, RecordModel.state).filter(
            RecordModel.city.isnot(None),
            RecordModel.state.isnot(None),
        ).all()
        for city, state in rows:
            city_key = compact_text(city).upper()
            state_code = normalize_state_code(state)
            if city_key and state_code:
                hints.setdefault(city_key, state_code)
    except Exception:
        pass

    return hints


def infer_state_from_city_text(text: str, city_hints) -> str:
    raw = compact_text(text).upper()
    if not raw or not city_hints:
        return ""
    if raw in city_hints:
        return city_hints[raw]
    for city, state in sorted(city_hints.items(), key=lambda item: len(item[0]), reverse=True):
        if re.search(rf"\b{re.escape(city)}\b", raw):
            return state
    return ""


@lru_cache(maxsize=2048)
def geocode_state_from_query(query: str) -> str:
    query = compact_text(query)
    if not query:
        return ""
    url = "https://nominatim.openstreetmap.org/search?" + urllib.parse.urlencode({
        "q": query,
        "format": "jsonv2",
        "limit": "1",
        "countrycodes": "us",
        "addressdetails": "1",
    })
    try:
        req = urllib_request.Request(url, headers={"User-Agent": "swt-warning-map/1.0"})
        with urllib_request.urlopen(req, timeout=5) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        if not data:
            return ""
        item = data[0] or {}
        addr = item.get("address") or {}
        state = normalize_state_code(addr.get("state_code") or addr.get("state"))
        if state:
            return state
        return match_state_in_text(item.get("display_name") or "", allow_abbr=False)
    except Exception:
        return ""


def infer_record_state(record: dict, city_hints=None, allow_geocode: bool = True) -> str:
    direct = normalize_state_code(record.get("state"))
    if direct:
        return direct

    for field in (record.get("location_name"), record.get("city"), record.get("employer")):
        state = match_state_in_text(field, allow_abbr=True)
        if state:
            return state

    state = match_state_in_text(record.get("summary") or "", allow_abbr=False)
    if state:
        return state

    if city_hints:
        for field in (record.get("city"), record.get("location_name")):
            state = infer_state_from_city_text(field, city_hints)
            if state:
                return state

    query = " ".join(
        x for x in [record.get("location_name"), record.get("city"), record.get("employer")]
        if x
    ).strip()
    if allow_geocode and query:
        return geocode_state_from_query(query)
    return ""


def normalize_record_state_fields(data: dict, db: Session = None, infer_missing: bool = True) -> dict:
    payload = dict(data)
    state = normalize_state_code(payload.get("state"))
    if not state and infer_missing:
        city_hints = build_city_state_hints(db) if db is not None else {}
        state = infer_record_state(payload, city_hints, allow_geocode=True)
    if state:
        payload["state"] = state
    elif payload.get("state") is not None:
        payload["state"] = compact_text(payload.get("state")).upper()
    return payload


# ── VIP 权限辅助 ──────────────────────────────────────────
def is_vip_user(user) -> bool:
    """管理员或 VIP 用户可查看完整信息"""
    if not user:
        return False
    if user.role == "admin":
        return True
    if not user.is_vip:
        return False
    return user.vip_expires_at is None or user.vip_expires_at > datetime.utcnow()


def mask_record(d: dict) -> dict:
    """非 VIP 用户的记录脱敏：隐藏原帖链接/雇主，摘要截断"""
    d = dict(d)
    d["note_url"] = ""
    d["employer"] = None
    if d.get("summary") and len(d["summary"]) > 40:
        d["summary"] = d["summary"][:40] + "…（VIP 可查看完整内容）"
    return d


def notify_record_favoriters(db: Session, record_id: str, actor_id: str, title: str, body: str):
    favorites = db.query(Favorite).filter(
        Favorite.target_type == "record",
        Favorite.target_id == record_id,
    ).all()
    notified = set()
    for favorite in favorites:
        if favorite.user_id == actor_id or favorite.user_id in notified:
            continue
        notified.add(favorite.user_id)
        db.add(Notification(
            id=str(uuid.uuid4()),
            user_id=favorite.user_id,
            actor_id=actor_id,
            type="record_change",
            title=title[:200],
            body=body[:500],
            target_type="record",
            target_id=record_id,
        ))


def notify_admins(db: Session, actor_id: str, title: str, body: str, target_type: str = "", target_id: str = ""):
    admins = db.query(User).filter(User.role == "admin", User.is_active == True).all()
    for admin in admins:
        if admin.id == actor_id:
            continue
        db.add(Notification(
            id=str(uuid.uuid4()),
            user_id=admin.id,
            actor_id=actor_id,
            type="record_review",
            title=title[:200],
            body=body[:500],
            target_type=target_type,
            target_id=target_id,
        ))


# ── Health ────────────────────────────────────────────────
@app.get("/api/health")
def health(db: Session = Depends(get_db)):
    total = db.query(RecordModel).count()
    return {"status": "ok", "total": total, "ts": now_iso(), "db": "sqlite"}


# ── Stats ─────────────────────────────────────────────────
@app.get("/api/stats")
def get_stats(locale: str = "zh", db: Session = Depends(get_db)):
    city_hints = build_city_state_hints(db)
    records = []
    rows = db.query(RecordModel).filter(RecordModel.review_status == "verified").all()
    translations = get_translations(db, "record", [r.id for r in rows]) if normalize_locale(locale) == "en" else {}
    for r in rows:
        d = apply_translation(r.to_dict(), translations.get(r.id), locale)
        d["state"] = infer_record_state(d, city_hints, allow_geocode=False) or normalize_state_code(d.get("state")) or d.get("state")
        records.append(d)
    reason_counts, state_counts, pos_counts = {}, {}, {}
    sev_dist = {1: 0, 2: 0, 3: 0, 4: 0, 5: 0}
    wages = []
    for r in records:
        for reason in (r.get("avoidance_reasons") or []):
            reason_counts[reason] = reason_counts.get(reason, 0) + 1
        if r.get("state"):
            state_counts[r["state"]] = state_counts.get(r["state"], 0) + 1
        if r.get("job_position"):
            pos_counts[r["job_position"]] = pos_counts.get(r["job_position"], 0) + 1
        sev = r.get("severity") or 3
        sev_dist[sev] = sev_dist.get(sev, 0) + 1
        if r.get("hourly_wage"):
            wages.append(r["hourly_wage"])
    return {
        "total": len(records),
        "located": len(state_counts),
        "high_severity": sum(1 for r in records if (r.get("severity") or 0) >= 4),
        "avg_wage": round(sum(wages) / len(wages), 1) if wages else None,
        "reason_counts": sorted(reason_counts.items(), key=lambda x: -x[1]),
        "state_counts": sorted(state_counts.items(), key=lambda x: -x[1]),
        "position_counts": sorted(pos_counts.items(), key=lambda x: -x[1])[:20],
        "severity_distribution": sev_dist,
        "wage_stats": {
            "min": min(wages) if wages else None,
            "max": max(wages) if wages else None,
            "avg": round(sum(wages) / len(wages), 1) if wages else None,
            "samples": wages
        }
    }


# ── Records CRUD ──────────────────────────────────────────
@app.get("/api/records")
def list_records(
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=200),
    search: Optional[str] = None,
    state: Optional[str] = None,
    severity: Optional[int] = None,
    reason: Optional[str] = None,
    source_type: Optional[str] = None,
    sort: str = "severity_desc",
    valuable_only: bool = True,
    include_unverified: bool = False,
    review_status: Optional[str] = None,
    locale: str = "zh",
    db: Session = Depends(get_db),
    me: Optional[User] = Depends(get_current_user_optional)
):
    vip = is_vip_user ( me )
    if not vip and page > 1 :
        raise HTTPException ( 403, "仅 VIP 用户可查看更多数据，请升级账户" )
    q = db.query(RecordModel)
    is_admin = bool(me and me.role == "admin")
    if include_unverified and not is_admin:
        include_unverified = False
    if include_unverified:
        if review_status:
            q = q.filter(RecordModel.review_status == review_status)
    else:
        q = q.filter(RecordModel.review_status == "verified")
    if valuable_only:
        q = q.filter(RecordModel.valuable == True)
    if state:
        q = q.filter(RecordModel.state == state)
    if severity:
        q = q.filter(RecordModel.severity == severity)
    if source_type:
        q = q.filter(RecordModel.source_type == source_type)
    if search:
        like = f"%{search}%"
        q = q.filter(or_(
            RecordModel.job_position.ilike(like),
            RecordModel.location_name.ilike(like),
            RecordModel.state.ilike(like),
            RecordModel.summary.ilike(like),
            RecordModel.employer.ilike(like),
            RecordModel.avoidance_reasons.ilike(like),
        ))
    sort_map = {
        "severity_desc": (RecordModel.severity.desc(), RecordModel.updated_at.desc()),
        "updated_desc": (RecordModel.updated_at.desc(), RecordModel.severity.desc()),
        "created_desc": (RecordModel.created_at.desc(), RecordModel.severity.desc()),
        "wage_desc": (RecordModel.hourly_wage.desc(), RecordModel.severity.desc()),
        "hours_desc": (RecordModel.hours_per_week.desc(), RecordModel.hours_per_day.desc()),
        "confidence_desc": (RecordModel.confidence.desc(), RecordModel.severity.desc()),
    }
    all_records = [r.to_dict() for r in q.order_by(*sort_map.get(sort, sort_map["updated_desc"])).all()]
    if reason:
        all_records = [r for r in all_records if reason in (r.get("avoidance_reasons") or [])]
    total = len(all_records)
    start = (page - 1) * page_size
    page_records = all_records[start:start + page_size]

    vip = is_vip_user(me)
    favorite_ids = set()
    if me and page_records:
        ids = [r["id"] for r in page_records]
        favorite_ids = {
            f.target_id for f in db.query(Favorite)
            .filter(
                Favorite.user_id == me.id,
                Favorite.target_type == "record",
                Favorite.target_id.in_(ids),
            )
            .all()
        }
    for r in page_records:
        r["favorited"] = r["id"] in favorite_ids

    if normalize_locale(locale) == "en":
        translations = get_translations(db, "record", [r["id"] for r in page_records])
        page_records = apply_translations(page_records, translations, locale)

    if not vip:
        page_records = [mask_record(r) for r in page_records]

    return {
        "total": total, "page": page, "page_size": page_size,
        "pages": (total + page_size - 1) // page_size,
        "limited": not vip,
        "records": page_records
    }


@app.get("/api/records/{record_id}")
def get_record(record_id: str, db: Session = Depends(get_db),
               me: Optional[User] = Depends(get_current_user_optional),
               locale: str = "zh"):
    r = db.query(RecordModel).filter(RecordModel.id == record_id).first()
    if not r:
        raise HTTPException(404, "Not found")
    can_view_unverified = bool(me and (me.role == "admin" or r.submitted_by == me.id))
    if (r.review_status or "pending") != "verified" and not can_view_unverified:
        raise HTTPException(404, "Not found")
    d = r.to_dict()
    if me:
        d["favorited"] = db.query(Favorite).filter(
            Favorite.user_id == me.id,
            Favorite.target_type == "record",
            Favorite.target_id == record_id,
        ).first() is not None
    if normalize_locale(locale) == "en":
        d = apply_translation(d, get_translations(db, "record", [record_id]).get(record_id), locale)
    if not is_vip_user(me):
        d = mask_record(d)
    return d


@app.post("/api/records/{record_id}/favorite")
def toggle_record_favorite(
    record_id: str,
    group_id: Optional[str] = None,
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    record = db.query(RecordModel).filter(RecordModel.id == record_id).first()
    if not record:
        raise HTTPException(404, "记录不存在")
    if group_id:
        group = db.query(FavoriteGroup).filter(FavoriteGroup.id == group_id, FavoriteGroup.user_id == user.id).first()
        if not group:
            raise HTTPException(404, "收藏夹不存在")
    favorite = db.query(Favorite).filter(
        Favorite.user_id == user.id,
        Favorite.target_type == "record",
        Favorite.target_id == record_id,
    ).first()
    if favorite:
        db.delete(favorite)
        favorited = False
        favorite_id = None
    else:
        favorite = Favorite(
            id=str(uuid.uuid4()), user_id=user.id, group_id=group_id,
            target_type="record", target_id=record_id
        )
        db.add(favorite)
        favorited = True
    db.commit()
    favorite_id = favorite.id if favorited else None
    count = db.query(func.count(Favorite.id)).filter(
        Favorite.target_type == "record",
        Favorite.target_id == record_id,
    ).scalar()
    return {"favorited": favorited, "favorite_id": favorite_id, "group_id": group_id, "favorite_count": count}


@app.get("/api/favorite-groups")
def list_favorite_groups(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    groups = db.query(FavoriteGroup).filter(FavoriteGroup.user_id == user.id).order_by(
        FavoriteGroup.sort_order, FavoriteGroup.created_at
    ).all()
    counts = dict(
        db.query(Favorite.group_id, func.count(Favorite.id))
        .filter(Favorite.user_id == user.id, Favorite.target_type == "record")
        .group_by(Favorite.group_id)
        .all()
    )
    return [g.to_dict(favorite_count=counts.get(g.id, 0)) for g in groups]


@app.post("/api/favorite-groups", status_code=201)
def create_favorite_group(req: FavoriteGroupReq, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    name = req.name.strip()[:80]
    if not name:
        raise HTTPException(400, "收藏夹名称不能为空")
    group = FavoriteGroup(id=str(uuid.uuid4()), user_id=user.id, name=name, sort_order=req.sort_order)
    db.add(group)
    db.commit()
    db.refresh(group)
    return group.to_dict()


@app.put("/api/favorite-groups/{group_id}")
def update_favorite_group(group_id: str, req: FavoriteGroupReq, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    group = db.query(FavoriteGroup).filter(FavoriteGroup.id == group_id, FavoriteGroup.user_id == user.id).first()
    if not group:
        raise HTTPException(404, "收藏夹不存在")
    name = req.name.strip()[:80]
    if not name:
        raise HTTPException(400, "收藏夹名称不能为空")
    group.name = name
    group.sort_order = req.sort_order
    db.commit()
    db.refresh(group)
    return group.to_dict()


@app.delete("/api/favorite-groups/{group_id}")
def delete_favorite_group(group_id: str, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    group = db.query(FavoriteGroup).filter(FavoriteGroup.id == group_id, FavoriteGroup.user_id == user.id).first()
    if not group:
        raise HTTPException(404, "收藏夹不存在")
    db.query(Favorite).filter(Favorite.user_id == user.id, Favorite.group_id == group_id).update(
        {"group_id": None}, synchronize_session=False
    )
    db.delete(group)
    db.commit()
    return {"deleted": group_id}


@app.put("/api/favorites/{favorite_id}")
def move_favorite(favorite_id: str, req: FavoriteMoveReq, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    favorite = db.query(Favorite).filter(Favorite.id == favorite_id, Favorite.user_id == user.id).first()
    if not favorite:
        raise HTTPException(404, "收藏不存在")
    if req.group_id:
        group = db.query(FavoriteGroup).filter(FavoriteGroup.id == req.group_id, FavoriteGroup.user_id == user.id).first()
        if not group:
            raise HTTPException(404, "收藏夹不存在")
    favorite.group_id = req.group_id
    db.commit()
    db.refresh(favorite)
    return favorite.to_dict()


@app.get("/api/me/favorites")
def my_favorites(
    target_type: str = "record",
    group_id: Optional[str] = None,
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    if target_type != "record":
        raise HTTPException(400, "暂仅支持 record 收藏")
    favorites = db.query(Favorite).filter(
        Favorite.user_id == user.id,
        Favorite.target_type == "record",
    )
    if group_id == "ungrouped":
        favorites = favorites.filter(Favorite.group_id.is_(None))
    elif group_id:
        favorites = favorites.filter(Favorite.group_id == group_id)
    favorites = favorites.order_by(Favorite.created_at.desc()).all()
    ids = [f.target_id for f in favorites]
    records = {r.id: r for r in db.query(RecordModel).filter(RecordModel.id.in_(ids)).all()} if ids else {}
    items = []
    for favorite in favorites:
        record = records.get(favorite.target_id)
        if not record:
            continue
        d = record.to_dict()
        d["favorite_id"] = favorite.id
        d["favorite_group_id"] = favorite.group_id
        d["favorite_group_name"] = favorite.group.name if favorite.group else None
        d["favorited"] = True
        d["favorited_at"] = favorite.created_at.isoformat() + "Z" if favorite.created_at else None
        if not is_vip_user(user):
            d = mask_record(d)
        items.append(d)
    return {"favorites": items}


@app.post("/api/records/{record_id}/feedback", status_code=201)
def create_record_feedback(
    record_id: str,
    req: RecordFeedbackReq,
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    record = db.query(RecordModel).filter(RecordModel.id == record_id).first()
    if not record:
        raise HTTPException(404, "记录不存在")
    if not req.reason.strip() and not req.detail.strip():
        raise HTTPException(400, "请填写反馈原因或详情")
    existing = db.query(RecordFeedback).filter(
        RecordFeedback.record_id == record_id,
        RecordFeedback.user_id == user.id,
        RecordFeedback.status == "open",
    ).first()
    if existing:
        return existing.to_dict()
    feedback = RecordFeedback(
        id=str(uuid.uuid4()),
        record_id=record_id,
        user_id=user.id,
        reason=req.reason.strip()[:80],
        detail=req.detail.strip()[:1000],
        status="open",
    )
    db.add(feedback)
    db.commit()
    db.refresh(feedback)
    return feedback.to_dict()


# 增删改记录限管理员
@app.post("/api/records", status_code=201)
def create_record(record: Record, admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    data = record.model_dump()
    data.pop("id", None)
    data = normalize_record_state_fields(data, db, infer_missing=True)
    obj = RecordModel(
        id=str(uuid.uuid4()),
        review_status="verified",
        reviewed_by=admin.id,
        reviewed_at=datetime.utcnow(),
        **data
    )
    db.add(obj)
    db.commit()
    db.refresh(obj)
    return obj.to_dict()


@app.post("/api/records/submit", status_code=201)
def submit_record(record: RecordSubmitReq, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    data = record.model_dump()
    data.pop("id", None)
    data = normalize_record_state_fields(data, db, infer_missing=True)
    if not any([data.get("summary"), data.get("employer"), data.get("job_position"), data.get("location_name"), data.get("state")]):
        raise HTTPException(400, "请至少填写岗位、雇主、地点或经历摘要")
    data["valuable"] = True
    data["source_type"] = "user"
    data["confidence"] = 0.5
    is_admin_submit = user.role == "admin"
    review_status = "verified" if is_admin_submit else "pending"
    review_note = "管理员上报，自动通过" if is_admin_submit else "用户上报，等待管理员审核"
    obj = RecordModel(
        id=str(uuid.uuid4()),
        review_status=review_status,
        review_note=review_note,
        reviewed_by=user.id if is_admin_submit else None,
        reviewed_at=datetime.utcnow() if is_admin_submit else None,
        submitted_by=user.id,
        **data
    )
    db.add(obj)
    db.commit()
    db.refresh(obj)
    if not is_admin_submit:
        notify_admins(
            db,
            user.id,
            "新的避雷数据待审核",
            f"{user.username} 提交了新数据：{obj.summary or obj.job_position or obj.location_name or obj.id}",
            target_type="record",
            target_id=obj.id,
        )
        db.commit()
        return {"message": "已提交，管理员审核通过后会展示在数据明细页面", "record": obj.to_dict()}
    return {"message": "已提交，已自动审核通过并展示在数据明细页面", "record": obj.to_dict()}


@app.put("/api/records/{record_id}")
def update_record(record_id: str, record: Record, admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    obj = db.query(RecordModel).filter(RecordModel.id == record_id).first()
    if not obj:
        raise HTTPException(404, "Not found")
    before_summary = obj.summary or obj.job_position or record_id
    data = record.model_dump()
    data.pop("id", None)
    data = normalize_record_state_fields(data, db, infer_missing=True)
    for k, v in data.items():
        setattr(obj, k, v)
    notify_record_favoriters(
        db, record_id, admin.id,
        "收藏的避雷记录已更新",
        f"{before_summary} 的信息已由管理员更新"
    )
    db.commit()
    db.refresh(obj)
    return obj.to_dict()


@app.put("/api/records/{record_id}/review")
def review_record(record_id: str, req: RecordReviewReq, admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    obj = db.query(RecordModel).filter(RecordModel.id == record_id).first()
    if not obj:
        raise HTTPException(404, "Not found")
    if req.review_status not in ("pending", "verified", "needs_review", "rejected"):
        raise HTTPException(400, "审核状态无效")
    obj.review_status = req.review_status
    obj.review_note = (req.review_note or "").strip()[:1000]
    obj.reviewed_by = admin.id
    obj.reviewed_at = datetime.utcnow()
    notify_record_favoriters(
        db, record_id, admin.id,
        "收藏的避雷记录可信度状态已更新",
        f"{obj.summary or obj.job_position or record_id} 的状态变更为 {req.review_status}"
    )
    db.commit()
    db.refresh(obj)
    return obj.to_dict()


@app.delete("/api/records/{record_id}")
def delete_record(record_id: str, admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    obj = db.query(RecordModel).filter(RecordModel.id == record_id).first()
    if not obj:
        raise HTTPException(404, "Not found")
    summary = obj.summary or obj.job_position or record_id
    notify_record_favoriters(
        db, record_id, admin.id,
        "收藏的避雷记录已删除",
        f"{summary} 已由管理员删除"
    )
    db.delete(obj)
    db.commit()
    return {"deleted": record_id}


@app.delete("/api/records")
def delete_all(admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    db.query(RecordModel).delete()
    db.commit()
    return {"message": "All deleted"}


# ── Import / Export (仅管理员) ────────────────────────────
ALLOWED_FIELDS = {
    "valuable", "source_type", "job_position", "location_name", "city",
    "state", "hourly_wage", "tips", "hours_per_day", "hours_per_week",
    "avoidance_reasons", "severity", "confidence", "employer", "summary", "note_url"
}


def normalize_text(value) -> str:
    return str(value or "").strip().lower()


def normalize_state(value) -> str:
    return str(value or "").strip().upper()


def normalize_note_url(value) -> str:
    raw = str(value or "").strip()
    if not raw:
        return ""
    try:
        parsed = urlsplit(raw)
        if not parsed.netloc:
            return raw.rstrip("/").lower()
        path = parsed.path.rstrip("/")
        return urlunsplit((parsed.scheme.lower(), parsed.netloc.lower(), path, "", ""))
    except Exception:
        return raw.rstrip("/").lower()


def composite_duplicate_key(record: dict):
    parts = (
        normalize_text(record.get("employer")),
        normalize_text(record.get("job_position")),
        normalize_state(record.get("state")),
        normalize_text(record.get("summary")),
    )
    filled_count = sum(1 for part in parts if part)
    if parts[3] or filled_count >= 2:
        return ("combo", parts)
    return None


@app.post("/api/import")
async def import_records(
    file: UploadFile = File(...),
    overwrite: bool = False,
    confirm_overwrite: bool = False,
    admin: User = Depends(require_admin),
    db: Session = Depends(get_db)
):
    if overwrite and not confirm_overwrite:
        raise HTTPException(status_code=400, detail="覆盖导入需要显式确认")

    content = (await file.read()).decode("utf-8").strip()
    raw_records = []
    errors = []
    if not content:
        return {"imported": 0, "total_in_file": 0, "errors": ["文件为空"]}
    try:
        data = json.loads(content)
        if isinstance(data, list):
            raw_records = data
        elif isinstance(data, dict):
            raw_records = [data]
        else:
            errors.append("JSON 顶层必须是对象或数组")
    except Exception:
        for i, line in enumerate(content.splitlines()):
            line = line.strip()
            if not line:
                continue
            try:
                raw_records.append(json.loads(line))
            except Exception as e:
                errors.append(f"行{i + 1}: {e}")

    if overwrite:
        db.query(RecordModel).delete(synchronize_session=False)
        db.commit()

    existing_keys = set()
    for existing in db.query(
        RecordModel.note_url,
        RecordModel.employer,
        RecordModel.job_position,
        RecordModel.state,
        RecordModel.summary,
    ).all():
        existing_record = {
            "note_url": existing.note_url,
            "employer": existing.employer,
            "job_position": existing.job_position,
            "state": existing.state,
            "summary": existing.summary,
        }
        url_key = normalize_note_url(existing_record.get("note_url"))
        combo_key = composite_duplicate_key(existing_record)
        if url_key:
            existing_keys.add(("url", url_key))
        if combo_key:
            existing_keys.add(combo_key)

    rows = []
    seen_keys = set()
    skipped_duplicates = 0
    for idx, r in enumerate(raw_records):
        if not isinstance(r, dict):
            errors.append(f"第{idx + 1}条：发现非对象记录")
            continue
        clean = {k: v for k, v in r.items() if k in ALLOWED_FIELDS}
        clean.setdefault("valuable", True)
        clean.setdefault("source_type", "post")
        clean.setdefault("severity", 3)
        clean.setdefault("confidence", 0.8)
        clean.setdefault("summary", "")
        clean.setdefault("note_url", "")
        clean = normalize_record_state_fields(clean, db, infer_missing=True)
        if clean.get("avoidance_reasons") is None:
            clean["avoidance_reasons"] = []
        elif not isinstance(clean.get("avoidance_reasons"), list):
            clean["avoidance_reasons"] = [str(clean.get("avoidance_reasons"))]
        try:
            clean["severity"] = int(clean.get("severity") or 3)
        except Exception:
            clean["severity"] = 3
        clean["severity"] = max(1, min(5, clean["severity"]))
        for field in ["hourly_wage", "hours_per_day", "hours_per_week", "confidence"]:
            value = clean.get(field)
            if value in ["", None]:
                clean[field] = None
            else:
                try:
                    clean[field] = float(value)
                except Exception:
                    clean[field] = None
        if clean.get("confidence") is None:
            clean["confidence"] = 0.8

        row_keys = []
        url_key = normalize_note_url(clean.get("note_url"))
        combo_key = composite_duplicate_key(clean)
        if url_key:
            row_keys.append(("url", url_key))
        if combo_key:
            row_keys.append(combo_key)

        if any(key in existing_keys or key in seen_keys for key in row_keys):
            skipped_duplicates += 1
            continue
        seen_keys.update(row_keys)
        rows.append({
            "id": str(uuid.uuid4()),
            "review_status": "verified",
            "reviewed_by": admin.id,
            "reviewed_at": datetime.utcnow(),
            **clean
        })

    added = 0
    batch_size = 1000
    try:
        for i in range(0, len(rows), batch_size):
            batch = rows[i:i + batch_size]
            db.bulk_insert_mappings(RecordModel, batch)
            db.commit()
            added += len(batch)
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"导入数据库失败: {str(e)}")

    return {
        "imported": added,
        "skipped_duplicates": skipped_duplicates,
        "total_in_file": len(raw_records),
        "errors": errors
    }


@app.get("/api/export")
def export_records(valuable_only: bool = True, admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    q = db.query(RecordModel)
    if valuable_only:
        q = q.filter(RecordModel.valuable == True)
    records = [r.to_dict() for r in q.all()]
    output = "\n".join(json.dumps(r, ensure_ascii=False) for r in records)
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    return StreamingResponse(
        io.StringIO(output), media_type="application/x-ndjson",
        headers={"Content-Disposition": f"attachment; filename=swt_records_{ts}.jsonl"}
    )


# ── Map data ──────────────────────────────────────────────
@app.get("/api/map-data")
def get_map_data(db: Session = Depends(get_db),
                 me: Optional[User] = Depends(get_current_user_optional),
                 locale: str = "zh"):
    vip = is_vip_user(me)
    city_hints = build_city_state_hints(db)
    records = []
    rows = db.query(RecordModel).filter(RecordModel.review_status == "verified").all()
    translations = get_translations(db, "record", [r.id for r in rows]) if normalize_locale(locale) == "en" else {}
    for r in rows:
        d = apply_translation(r.to_dict(), translations.get(r.id), locale)
        d["state"] = infer_record_state(d, city_hints, allow_geocode=False) or normalize_state_code(d.get("state")) or d.get("state")
        records.append(d)
    loc_map = {}
    for r in records:
        st = normalize_state_code(r.get("state")) or (r.get("state") or "").upper().strip()
        if not st or st not in STATE_COORDS:
            continue
        if st not in loc_map:
            c = STATE_COORDS[st]
            name = r.get("location_name") or r.get("city") or STATE_ABBR_TO_NAME.get(st) or st
            loc_map[st] = {
                "state": st, "name": name,
                "lat": c[0], "lng": c[1], "count": 0, "records": [],
                "reasons": {}, "wages": [], "max_severity": 0
            }
        loc = loc_map[st]
        loc["count"] += 1
        loc["records"].append({
            "id": r.get("id"), "job_position": r.get("job_position"),
            "avoidance_reasons": r.get("avoidance_reasons") or [],
            "severity": r.get("severity"), "summary": r.get("summary"),
            "hourly_wage": r.get("hourly_wage"), "note_url": r.get("note_url"),
            "source_type": r.get("source_type")
        })
        for reason in (r.get("avoidance_reasons") or []):
            loc["reasons"][reason] = loc["reasons"].get(reason, 0) + 1
        if r.get("hourly_wage"):
            loc["wages"].append(r["hourly_wage"])
        loc["max_severity"] = max(loc["max_severity"], r.get("severity") or 0)
    locs = sorted(loc_map.values(), key=lambda x: -x["count"])
    for loc in locs:
        loc["avg_wage"] = round(sum(loc["wages"]) / len(loc["wages"]), 1) if loc["wages"] else None
        loc["top_reasons"] = sorted(loc["reasons"].items(), key=lambda x: -x[1])[:5]
        loc["records"] = sorted(loc["records"], key=lambda x: -(x.get("severity") or 0))
        # 非 VIP：每州只显示前 3 条，且脱敏
        if not vip:
            loc["records"] = [mask_record(x) for x in loc["records"][:3]]
    return {"locations": locs, "total": len(records), "limited": not vip}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
