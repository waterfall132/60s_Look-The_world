"""
生产环境：FastAPI 同时提供 API 和前端静态文件
在 start_prod.sh 构建后自动合并成单一服务
"""

from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from pathlib import Path
import sys
import os

# Import the main app
sys.path.insert(0, str(Path(__file__).parent))
from main import app

STATIC_DIR = Path(__file__).parent / "static"

if STATIC_DIR.exists():
    # Mount static assets (js, css, etc.)
    app.mount("/assets", StaticFiles(directory=str(STATIC_DIR / "assets")), name="assets")

    @app.get("/{full_path:path}")
    async def serve_spa(full_path: str):
        """Serve Vue SPA - all non-API routes go to index.html"""
        index = STATIC_DIR / "index.html"
        if index.exists():
            return FileResponse(str(index))
        return {"error": "Frontend not built. Run start_prod.sh first."}
