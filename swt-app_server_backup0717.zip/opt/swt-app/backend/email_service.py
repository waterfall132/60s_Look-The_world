"""
邮件服务模块
=============
开发模式（默认）：验证码不真发邮件，而是打印到后端控制台，
                  并在接口响应里返回（仅 DEV_MODE 下），方便本地调试。

上线时：把 EMAIL_DEV_MODE 设为 "false"，并实现 _send_via_smtp() 里的真实发信逻辑
        （已留好完整模板和注释，填入 SMTP 配置即可）。

环境变量：
  EMAIL_DEV_MODE   "true"(默认) / "false"
  SMTP_HOST        例如 smtp.gmail.com / smtp.qq.com / smtp.163.com
  SMTP_PORT        465(SSL) 或 587(TLS)
  SMTP_USER        发信邮箱账号
  SMTP_PASSWORD    发信邮箱授权码（不是登录密码！）
  SMTP_FROM        显示的发件人，默认同 SMTP_USER
"""

import os
import random
import string

# 是否开发模式：true 时不真发邮件，只打印 + 接口返回验证码
EMAIL_DEV_MODE = os.getenv("EMAIL_DEV_MODE", "true").lower() == "true"

# 验证码有效期（分钟）
CODE_EXPIRE_MINUTES = 10
# 同一邮箱两次发码的最小间隔（秒），防刷
CODE_RESEND_INTERVAL = 60


def generate_code(length: int = 6) -> str:
    """生成数字验证码"""
    return "".join(random.choices(string.digits, k=length))


# ── 不同用途的邮件文案 ────────────────────────────────────
_PURPOSE_TEXT = {
    "register": ("【SWT避雷】注册验证码", "您正在注册 SWT 避雷情报系统账号"),
    "reset_password": ("【SWT避雷】找回密码验证码", "您正在重置 SWT 避雷情报系统的登录密码"),
}


def send_code_email(to_email: str, code: str, purpose: str = "register") -> bool:
    """
    发送验证码邮件。
    开发模式：打印到控制台并返回 True。
    生产模式：调用 _send_via_smtp()。
    """
    subject, intro = _PURPOSE_TEXT.get(purpose, _PURPOSE_TEXT["register"])
    body = (
        f"{intro}。\n\n"
        f"您的验证码是：{code}\n\n"
        f"验证码 {CODE_EXPIRE_MINUTES} 分钟内有效，请勿泄露给他人。\n"
        f"如非本人操作，请忽略此邮件。"
    )

    if EMAIL_DEV_MODE:
        # 开发模式：打印到后端控制台
        print("=" * 50)
        print(f"[开发模式 · 模拟发信] 收件人: {to_email}")
        print(f"主题: {subject}")
        print(f"验证码: {code}  (用途: {purpose})")
        print("=" * 50)
        return True

    # 生产模式：真实发信
    return _send_via_smtp(to_email, subject, body)


def _send_via_smtp(to_email: str, subject: str, body: str) -> bool:
    """
    通过 SMTP 真实发送邮件。
    ─────────────────────────────────────────────────────
    上线前：取消下面代码的注释，并配置好环境变量即可。
    以 QQ 邮箱为例：
      SMTP_HOST=smtp.qq.com
      SMTP_PORT=465
      SMTP_USER=你的qq邮箱@qq.com
      SMTP_PASSWORD=授权码（QQ邮箱设置→账户→开启SMTP后生成）
    ─────────────────────────────────────────────────────
    """
    import smtplib
    from email.mime.text import MIMEText
    from email.header import Header

    host = os.getenv("SMTP_HOST")
    port = int(os.getenv("SMTP_PORT", "465"))
    user = os.getenv("SMTP_USER")
    password = os.getenv("SMTP_PASSWORD")
    sender = os.getenv("SMTP_FROM", user)

    if not all([host, user, password]):
        print("[邮件错误] SMTP 配置缺失，无法发信")
        return False

    try:
        msg = MIMEText(body, "plain", "utf-8")
        msg["Subject"] = Header(subject, "utf-8")
        msg["From"] = sender
        msg["To"] = to_email

        if port == 465:
            # SSL
            server = smtplib.SMTP_SSL(host, port, timeout=10)
        else:
            # TLS (587)
            server = smtplib.SMTP(host, port, timeout=10)
            server.starttls()

        server.login(user, password)
        server.sendmail(sender, [to_email], msg.as_string())
        server.quit()
        return True
    except Exception as e:
        print(f"[邮件发送失败] {e}")
        return False
