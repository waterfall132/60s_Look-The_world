"""Auth helpers - JWT and password hashing."""

import os
from datetime import datetime, timedelta
from typing import Optional

import bcrypt
from fastapi import Depends, HTTPException, Header, Request
from jose import JWTError, jwt
from sqlalchemy.orm import Session

from database import User, get_db

SECRET_KEY = os.getenv("SECRET_KEY", "swt-dev-secret-change-in-production-please")
ALGORITHM = "HS256"
TOKEN_EXPIRE_DAYS = 7


def hash_password(password: str) -> str:
    return bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")


def verify_password(password: str, password_hash: str) -> bool:
    try:
        return bcrypt.checkpw(password.encode("utf-8"), password_hash.encode("utf-8"))
    except Exception:
        return False


def create_token(user_id: str, role: str) -> str:
    payload = {
        "sub": user_id,
        "role": role,
        "exp": datetime.utcnow() + timedelta(days=TOKEN_EXPIRE_DAYS),
    }
    return jwt.encode(payload, SECRET_KEY, algorithm=ALGORITHM)


def decode_token(token: str) -> Optional[dict]:
    try:
        return jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
    except JWTError:
        return None


def _extract_token(authorization: Optional[str]) -> Optional[str]:
    if not authorization:
        return None
    parts = authorization.split()
    if len(parts) == 2 and parts[0].lower() == "bearer":
        return parts[1]
    return authorization


def get_client_ip(request: Optional[Request]) -> str:
    if request is None:
        return ""
    forwarded = request.headers.get("x-forwarded-for")
    if forwarded:
        return forwarded.split(",")[0].strip()
    real_ip = request.headers.get("x-real-ip")
    if real_ip:
        return real_ip.strip()
    client = getattr(request, "client", None)
    return getattr(client, "host", "") or ""


def touch_user_activity(db: Session, user: User, request: Optional[Request], kind: str = "active") -> None:
    now = datetime.utcnow()
    ip = get_client_ip(request)
    ua = (request.headers.get("user-agent") if request else "") or ""
    ua = ua[:300]

    user.last_seen_at = now
    if ip:
        user.last_seen_ip = ip
    if ua:
        user.last_seen_user_agent = ua

    if kind == "login":
        user.last_login_at = now
        if ip:
            user.last_login_ip = ip
        if ua:
            user.last_login_user_agent = ua

    db.commit()


def get_current_user(
    authorization: Optional[str] = Header(None),
    request: Request = None,
    db: Session = Depends(get_db),
) -> User:
    token = _extract_token(authorization)
    if not token:
        raise HTTPException(401, "Not logged in")
    payload = decode_token(token)
    if not payload:
        raise HTTPException(401, "Login expired, please login again")
    user = db.query(User).filter(User.id == payload.get("sub")).first()
    if not user or not user.is_active:
        raise HTTPException(401, "User not found or disabled")
    if request is not None:
        touch_user_activity(db, user, request, "active")
    return user


def get_current_user_optional(
    authorization: Optional[str] = Header(None),
    request: Request = None,
    db: Session = Depends(get_db),
) -> Optional[User]:
    token = _extract_token(authorization)
    if not token:
        return None
    payload = decode_token(token)
    if not payload:
        return None
    user = db.query(User).filter(User.id == payload.get("sub")).first()
    if user and user.is_active and request is not None:
        touch_user_activity(db, user, request, "active")
    return user


def require_admin(user: User = Depends(get_current_user)) -> User:
    if user.role != "admin":
        raise HTTPException(403, "Admin permission required")
    return user
