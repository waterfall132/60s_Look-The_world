"""雇主地点评估 - 付费/VIP 功能。

第一阶段：OpenStreetMap/Nominatim/Overpass + 本地 SSA Office 数据。
第二阶段：配置 GOOGLE_MAPS_API_KEY 后可用 Google Places 增强。
第三阶段：在后台 AI 配置中启用 OpenAI-compatible 第三方服务后可用 AI 总结，否则使用规则总结。
"""

import json
import math
import os
import urllib.parse
import urllib.request
from datetime import datetime
from pathlib import Path
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy import func
from sqlalchemy.orm import Session

from auth import get_current_user
from ai_service import chat_json, get_or_create_ai_config, is_ai_ready
from database import AssessmentUsage, RecordModel, User, get_db, gen_id


router = APIRouter(prefix="/api/assessments", tags=["assessments"])

HTTP_TIMEOUT = float(os.getenv("ASSESSMENT_HTTP_TIMEOUT", "8"))
DEFAULT_RADIUS_M = int(os.getenv("ASSESSMENT_SEARCH_RADIUS_M", "8000"))
GOOGLE_KEY = os.getenv("GOOGLE_MAPS_API_KEY", "").strip()


STATE_COORDS = {
    "AL": [32.8, -86.8], "AK": [64.2, -153.4], "AZ": [34.3, -111.1], "AR": [34.8, -92.2],
    "CA": [36.8, -119.4], "CO": [39.0, -105.5], "CT": [41.6, -72.7], "DE": [39.0, -75.5],
    "FL": [27.8, -81.7], "GA": [33.0, -83.6], "HI": [20.8, -156.3], "ID": [44.2, -114.5],
    "IL": [40.0, -89.2], "IN": [39.8, -86.1], "IA": [42.0, -93.2], "KS": [38.5, -96.4],
    "KY": [37.5, -85.3], "LA": [31.1, -91.9], "ME": [45.2, -69.0], "MD": [39.0, -76.8],
    "MA": [42.2, -71.5], "MI": [44.2, -85.6], "MN": [46.4, -93.1], "MS": [32.7, -89.7],
    "MO": [38.4, -92.3], "MT": [47.0, -110.5], "NE": [41.5, -99.9], "NV": [38.8, -116.4],
    "NH": [43.7, -71.6], "NJ": [40.1, -74.4], "NM": [34.5, -106.2], "NY": [42.9, -75.5],
    "NC": [35.5, -79.4], "ND": [47.4, -100.4], "OH": [40.3, -82.8], "OK": [35.6, -96.9],
    "OR": [44.6, -122.1], "PA": [40.6, -77.2], "RI": [41.7, -71.6], "SC": [33.8, -80.9],
    "SD": [44.3, -100.2], "TN": [35.9, -86.7], "TX": [31.1, -97.6], "UT": [39.3, -111.1],
    "VT": [44.0, -72.7], "VA": [37.8, -79.5], "WA": [47.4, -120.5], "WV": [38.6, -80.5],
    "WI": [44.3, -89.8], "WY": [43.0, -107.6],
}


class EmployerAssessmentReq(BaseModel):
    employer_name: str = ""
    address: str
    city: Optional[str] = ""
    state: Optional[str] = ""
    has_car: bool = False
    housing_address: Optional[str] = ""
    hourly_wage: Optional[float] = None
    hours_per_week: Optional[float] = None


def http_json(url: str, headers: Optional[dict] = None, data: Optional[bytes] = None):
    req = urllib.request.Request(
        url,
        data=data,
        headers={
            "User-Agent": "swt-warning-assessment/1.0",
            "Content-Type": "application/json",
            **(headers or {}),
        },
    )
    with urllib.request.urlopen(req, timeout=HTTP_TIMEOUT) as resp:
        return json.loads(resp.read().decode("utf-8"))


def haversine_miles(lat1, lon1, lat2, lon2):
    r = 3958.8
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp = math.radians(lat2 - lat1)
    dl = math.radians(lon2 - lon1)
    a = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * r * math.atan2(math.sqrt(a), math.sqrt(1 - a))


def monthly_usage_count(db: Session, user_id: str):
    start = datetime.utcnow().replace(day=1, hour=0, minute=0, second=0, microsecond=0)
    return db.query(func.count(AssessmentUsage.id)).filter(
        AssessmentUsage.user_id == user_id,
        AssessmentUsage.created_at >= start,
        AssessmentUsage.used_credit == False,
    ).scalar()


def quota_for(user: User, db: Session):
    is_member = user.role == "admin" or bool(user.is_vip)
    monthly_limit = user.assessment_monthly_limit or 10
    monthly_used = monthly_usage_count(db, user.id)
    return {
        "is_member": is_member,
        "monthly_limit": None if user.role == "admin" else monthly_limit,
        "monthly_used": monthly_used,
        "monthly_remaining": None if user.role == "admin" else max(0, monthly_limit - monthly_used),
        "credits": user.assessment_credits or 0,
    }


def consume_quota(user: User, db: Session):
    q = quota_for(user, db)
    if user.role == "admin":
        return False, q
    if q["is_member"] and q["monthly_remaining"] > 0:
        return False, q
    if (user.assessment_credits or 0) > 0:
        user.assessment_credits -= 1
        return True, q
    raise HTTPException(status_code=402, detail="该功能为付费/VIP 功能，会员或购买次数后可使用")


def geocode(req: EmployerAssessmentReq):
    query = " ".join(x for x in [req.address, req.city or "", req.state or ""] if x).strip()
    if GOOGLE_KEY:
        google = google_geocode(query)
        if google:
            return google

    url = "https://nominatim.openstreetmap.org/search?" + urllib.parse.urlencode({
        "q": query,
        "format": "json",
        "limit": "1",
        "countrycodes": "us",
    })
    try:
        data = http_json(url)
        if data:
            item = data[0]
            return {
                "lat": float(item["lat"]),
                "lng": float(item["lon"]),
                "display_name": item.get("display_name") or query,
                "source": "openstreetmap",
                "precision": "address",
            }
    except Exception:
        pass

    state = (req.state or "").strip().upper()
    if state in STATE_COORDS:
        lat, lng = STATE_COORDS[state]
        return {
            "lat": lat,
            "lng": lng,
            "display_name": f"{state} approximate center",
            "source": "local_fallback",
            "precision": "state",
        }
    raise HTTPException(400, "地址解析失败，请填写更完整的美国地址或州缩写")


def google_geocode(query: str):
    try:
        url = "https://maps.googleapis.com/maps/api/geocode/json?" + urllib.parse.urlencode({
            "address": query,
            "region": "us",
            "key": GOOGLE_KEY,
        })
        data = http_json(url)
        if data.get("status") == "OK" and data.get("results"):
            item = data["results"][0]
            loc = item["geometry"]["location"]
            return {
                "lat": float(loc["lat"]),
                "lng": float(loc["lng"]),
                "display_name": item.get("formatted_address") or query,
                "source": "google",
                "precision": item.get("geometry", {}).get("location_type", "address").lower(),
            }
    except Exception:
        return None
    return None


def google_pois(lat: float, lng: float, radius_m: int = DEFAULT_RADIUS_M):
    if not GOOGLE_KEY:
        return None
    mapping = {
        "grocery": ("supermarket", "超市/商场"),
        "bank": ("bank", "银行/ATM"),
        "convenience": ("convenience_store", "便利店"),
        "pharmacy": ("pharmacy", "药店"),
        "medical": ("hospital", "医疗"),
        "transit": ("transit_station", "公共交通"),
    }
    items = []
    for key, (place_type, label) in mapping.items():
        try:
            url = "https://maps.googleapis.com/maps/api/place/nearbysearch/json?" + urllib.parse.urlencode({
                "location": f"{lat},{lng}",
                "radius": radius_m,
                "type": place_type,
                "key": GOOGLE_KEY,
            })
            data = http_json(url)
            if data.get("status") not in {"OK", "ZERO_RESULTS"}:
                continue
            for place in (data.get("results") or [])[:8]:
                loc = place.get("geometry", {}).get("location", {})
                if "lat" not in loc or "lng" not in loc:
                    continue
                dist = haversine_miles(lat, lng, float(loc["lat"]), float(loc["lng"]))
                items.append({
                    "name": place.get("name") or label,
                    "category": key,
                    "label": label,
                    "distance_miles": round(dist, 2),
                    "lat": float(loc["lat"]),
                    "lng": float(loc["lng"]),
                    "rating": place.get("rating"),
                })
        except Exception:
            continue
    items.sort(key=lambda x: x["distance_miles"])
    categories = {}
    for item in items:
        categories.setdefault(item["category"], []).append(item)
    return {
        "provider": "google_places",
        "ok": bool(items),
        "items": items[:80],
        "categories": {k: v[:8] for k, v in categories.items()},
    }


def overpass_pois(lat: float, lng: float, radius_m: int = DEFAULT_RADIUS_M):
    query = f"""
    [out:json][timeout:12];
    (
      node["shop"~"supermarket|convenience|department_store|mall"](around:{radius_m},{lat},{lng});
      node["amenity"~"bank|atm|pharmacy|hospital|clinic|bus_station"](around:{radius_m},{lat},{lng});
      node["public_transport"="platform"](around:{radius_m},{lat},{lng});
      way["shop"~"supermarket|convenience|department_store|mall"](around:{radius_m},{lat},{lng});
      way["amenity"~"bank|atm|pharmacy|hospital|clinic|bus_station"](around:{radius_m},{lat},{lng});
    );
    out center tags 80;
    """
    try:
        data = urllib.parse.urlencode({"data": query}).encode("utf-8")
        raw = http_json("https://overpass-api.de/api/interpreter", data=data)
        return normalize_osm_pois(raw.get("elements", []), lat, lng)
    except Exception:
        return {"provider": "openstreetmap", "ok": False, "items": [], "categories": {}}


def normalize_osm_pois(elements, lat, lng):
    items = []
    for el in elements:
        tags = el.get("tags") or {}
        p_lat = el.get("lat") or (el.get("center") or {}).get("lat")
        p_lng = el.get("lon") or (el.get("center") or {}).get("lon")
        if p_lat is None or p_lng is None:
            continue
        category = poi_category(tags)
        if not category:
            continue
        name = tags.get("name") or category["label"]
        dist = haversine_miles(lat, lng, float(p_lat), float(p_lng))
        items.append({
            "name": name,
            "category": category["key"],
            "label": category["label"],
            "distance_miles": round(dist, 2),
            "lat": float(p_lat),
            "lng": float(p_lng),
        })
    items.sort(key=lambda x: x["distance_miles"])
    categories = {}
    for item in items:
        categories.setdefault(item["category"], []).append(item)
    return {
        "provider": "openstreetmap",
        "ok": True,
        "items": items[:80],
        "categories": {k: v[:8] for k, v in categories.items()},
    }


def poi_category(tags):
    shop = tags.get("shop")
    amenity = tags.get("amenity")
    public_transport = tags.get("public_transport")
    if shop in {"supermarket", "department_store", "mall"}:
        return {"key": "grocery", "label": "超市/商场"}
    if shop == "convenience":
        return {"key": "convenience", "label": "便利店"}
    if amenity in {"bank", "atm"}:
        return {"key": "bank", "label": "银行/ATM"}
    if amenity == "pharmacy":
        return {"key": "pharmacy", "label": "药店"}
    if amenity in {"hospital", "clinic"}:
        return {"key": "medical", "label": "医疗"}
    if amenity == "bus_station" or public_transport == "platform":
        return {"key": "transit", "label": "公共交通"}
    return None


def load_ssa_offices():
    path = Path(__file__).parent / "ssa_offices.json"
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def nearest_ssa(lat: float, lng: float, limit: int = 5):
    offices = load_ssa_offices()
    enriched = []
    for office in offices:
        dist = haversine_miles(lat, lng, office["lat"], office["lng"])
        enriched.append({**office, "distance_miles": round(dist, 2)})
    return sorted(enriched, key=lambda x: x["distance_miles"])[:limit]


def risk_snapshot(db: Session, state: str):
    q = db.query(RecordModel).filter(RecordModel.valuable == True)
    if state:
        q = q.filter(RecordModel.state == state.upper())
    records = q.all()
    total = len(records)
    high = sum(1 for r in records if (r.severity or 0) >= 4)
    verified = sum(1 for r in records if (r.review_status or "") == "verified")
    avg_sev = round(sum((r.severity or 3) for r in records) / total, 1) if total else None
    return {"state": state.upper() if state else "", "total": total, "high_severity": high, "verified": verified, "avg_severity": avg_sev}


def score_assessment(req, pois, ssa_list, risk):
    cats = pois.get("categories") or {}
    nearest_grocery = first_distance(cats.get("grocery"))
    nearest_bank = first_distance(cats.get("bank"))
    nearest_convenience = first_distance(cats.get("convenience"))
    nearest_pharmacy = first_distance(cats.get("pharmacy"))
    nearest_transit = first_distance(cats.get("transit"))
    nearest_ssa_dist = ssa_list[0]["distance_miles"] if ssa_list else None

    life = 0
    life += distance_score(nearest_grocery, 1.5, 4, 8, 28)
    life += distance_score(nearest_bank, 2, 5, 10, 18)
    life += distance_score(nearest_convenience or nearest_pharmacy, 1, 3, 6, 18)
    life = min(100, round(life))

    ssn = distance_score(nearest_ssa_dist, 10, 25, 60, 100)
    transit = 82 if req.has_car else distance_score(nearest_transit, 0.5, 2, 5, 100)

    risk_penalty = min(45, (risk["high_severity"] * 8) + max(0, (risk["total"] - 5) * 1.5))
    risk_score = max(0, round(100 - risk_penalty))

    wage = 65
    if req.hourly_wage:
        wage += 15 if req.hourly_wage >= 15 else -10
        wage += 10 if req.hourly_wage >= 18 else 0
    if req.hours_per_week:
        if req.hours_per_week < 25:
            wage -= 15
        elif req.hours_per_week <= 45:
            wage += 10
        else:
            wage -= 8
    wage = max(0, min(100, round(wage)))

    overall = round(life * 0.30 + ssn * 0.20 + transit * 0.20 + risk_score * 0.20 + wage * 0.10)
    return {
        "overall": overall,
        "decision": decision_label(overall),
        "parts": {
            "life": life,
            "ssn": ssn,
            "transport": transit,
            "risk": risk_score,
            "wage_hours": wage,
        },
    }


def first_distance(items):
    return items[0]["distance_miles"] if items else None


def distance_score(distance, good, ok, poor, max_score):
    if distance is None:
        return 35
    if distance <= good:
        return max_score
    if distance <= ok:
        return round(max_score * 0.75)
    if distance <= poor:
        return round(max_score * 0.45)
    return round(max_score * 0.2)


def decision_label(score):
    if score >= 82:
        return "推荐"
    if score >= 68:
        return "可选但需注意"
    if score >= 52:
        return "谨慎选择"
    return "不建议选择"


def build_summary(req, score, pois, ssa_list, risk, db: Session):
    cats = pois.get("categories") or {}
    positives = []
    warnings = []
    if cats.get("grocery"):
        positives.append(f"最近超市/商场约 {cats['grocery'][0]['distance_miles']} miles")
    else:
        warnings.append("周边未查到明确超市，生活采购可能不方便")
    if cats.get("bank"):
        positives.append(f"最近银行/ATM 约 {cats['bank'][0]['distance_miles']} miles")
    else:
        warnings.append("附近银行/ATM 覆盖较弱，建议提前准备银行卡和现金方案")
    if ssa_list:
        dist = ssa_list[0]["distance_miles"]
        if dist <= 25:
            positives.append(f"最近 SSA Office 约 {dist} miles，办 SSN 相对可控")
        else:
            warnings.append(f"最近 SSA Office 约 {dist} miles，办 SSN 需要规划交通")
    if not req.has_car and not cats.get("transit"):
        warnings.append("未查到明显公共交通点，无车生活风险较高")
    if risk["high_severity"]:
        warnings.append(f"该州已有 {risk['high_severity']} 条高严重度避雷记录")
    if req.hours_per_week and req.hours_per_week < 25:
        warnings.append("每周工时偏低，收入稳定性需要确认")

    rule_summary = {
        "headline": f"综合评分 {score['overall']}/100，结论：{score['decision']}",
        "positives": positives[:5],
        "warnings": warnings[:6],
        "advice": final_advice(score["overall"]),
        "ai_provider": "rules",
    }
    return ai_summary(req, score, rule_summary, risk, db) or rule_summary


def ai_summary(req, score, rule_summary, risk, db: Session):
    try:
        prompt = {
            "employer_name": req.employer_name,
            "address": req.address,
            "has_car": req.has_car,
            "hourly_wage": req.hourly_wage,
            "hours_per_week": req.hours_per_week,
            "score": score,
            "rule_summary": rule_summary,
            "risk": risk,
        }
        parsed = chat_json(
            db,
            [
                {
                    "role": "system",
                    "content": "你是 SWT 学生雇主选择顾问。只输出 JSON，字段为 headline, positives, warnings, advice。内容简洁、务实、中文。",
                },
                {"role": "user", "content": json.dumps(prompt, ensure_ascii=False)},
            ],
            temperature=0.2,
            timeout=HTTP_TIMEOUT + 12,
        )
        if not parsed:
            return None
        return {
            "headline": str(parsed.get("headline") or rule_summary["headline"])[:200],
            "positives": [str(x)[:160] for x in parsed.get("positives", [])][:5] or rule_summary["positives"],
            "warnings": [str(x)[:160] for x in parsed.get("warnings", [])][:6] or rule_summary["warnings"],
            "advice": str(parsed.get("advice") or rule_summary["advice"])[:600],
            "ai_provider": "configured_provider",
        }
    except Exception:
        return None


def final_advice(score):
    if score >= 82:
        return "整体条件较好，可以优先考虑，但仍建议确认住宿、交通和工时是否写入 offer 或邮件。"
    if score >= 68:
        return "可以考虑，但需要重点确认交通、采购和 SSN 办理方案，最好提前联系在当地的同学或雇主。"
    if score >= 52:
        return "建议谨慎选择，除非工资、住宿或交通有明确保障，否则落地后生活成本和办证压力可能较高。"
    return "不建议优先选择。除非有强保障条件，否则建议换生活设施更完善、风险更低的雇主。"


@router.get("/quota")
def get_assessment_quota(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    return quota_for(user, db)


@router.post("/employer")
def assess_employer(req: EmployerAssessmentReq, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    if not req.address.strip():
        raise HTTPException(400, "请填写雇主地址或城市州")

    used_credit, _ = consume_quota(user, db)
    location = geocode(req)
    pois = google_pois(location["lat"], location["lng"]) or overpass_pois(location["lat"], location["lng"])
    ssa = nearest_ssa(location["lat"], location["lng"])
    risk = risk_snapshot(db, req.state or infer_state_from_display(location.get("display_name", "")))
    score = score_assessment(req, pois, ssa, risk)
    summary = build_summary(req, score, pois, ssa, risk, db)
    ai_config = get_or_create_ai_config(db)

    usage = AssessmentUsage(
        id=gen_id(),
        user_id=user.id,
        query=req.employer_name.strip()[:300],
        address=req.address.strip()[:500],
        score=score["overall"],
        used_credit=used_credit,
    )
    db.add(usage)
    db.commit()

    return {
        "usage_id": usage.id,
        "quota": quota_for(user, db),
        "location": location,
        "provider": {
            "poi": pois.get("provider"),
            "poi_ok": pois.get("ok"),
            "google_enabled": bool(GOOGLE_KEY),
            "ai_enabled": is_ai_ready(ai_config),
            "ai_provider": ai_config.provider,
            "ai_model": ai_config.model if is_ai_ready(ai_config) else "",
        },
        "score": score,
        "summary": summary,
        "nearby": {
            "categories": pois.get("categories") or {},
            "items": pois.get("items") or [],
        },
        "ssa_offices": ssa,
        "risk": risk,
    }


def infer_state_from_display(text: str):
    upper = f" {text.upper()} "
    for state in STATE_COORDS:
        if f" {state} " in upper or f", {state}," in upper:
            return state
    return ""
