"""
验证码存取与校验逻辑（基于 SQLite）
=====================================
负责：生成并存码、限流（防刷）、校验、标记已用、清理过期码。
真正的"发邮件"动作委托给 email_service.send_code_email()。
"""

from datetime import datetime, timedelta
from sqlalchemy.orm import Session

from database import EmailCode, gen_id
from email_service import (
    generate_code, send_code_email,
    CODE_EXPIRE_MINUTES, CODE_RESEND_INTERVAL, EMAIL_DEV_MODE,
)


def issue_code(db: Session, email: str, purpose: str) -> dict:
    """
    生成并"发送"验证码。
    返回 dict：开发模式下含 dev_code 字段方便前端调试。
    抛 ValueError 表示限流等业务错误。
    """
    now = datetime.utcnow()

    # 限流：检查最近是否刚发过
    recent = (
        db.query(EmailCode)
        .filter(EmailCode.email == email, EmailCode.purpose == purpose)
        .order_by(EmailCode.created_at.desc())
        .first()
    )
    if recent:
        elapsed = (now - recent.created_at).total_seconds()
        if elapsed < CODE_RESEND_INTERVAL:
            wait = int(CODE_RESEND_INTERVAL - elapsed)
            raise ValueError(f"发送过于频繁，请 {wait} 秒后再试")

    # 生成新码
    code = generate_code(6)
    rec = EmailCode(
        id=gen_id(), email=email, code=code, purpose=purpose,
        is_used=False, created_at=now,
        expires_at=now + timedelta(minutes=CODE_EXPIRE_MINUTES),
    )
    db.add(rec)
    db.commit()

    # 委托发信（开发模式打印控制台）
    send_code_email(email, code, purpose)

    result = {"message": f"验证码已发送至 {email}", "expire_minutes": CODE_EXPIRE_MINUTES}
    # 开发模式下把验证码也返回，方便前端/调试（生产模式绝不返回）
    if EMAIL_DEV_MODE:
        result["dev_code"] = code
    return result


def verify_code(db: Session, email: str, code: str, purpose: str) -> bool:
    """
    校验验证码是否正确且有效。校验通过会把该码标记为已用。
    返回 True/False。
    """
    now = datetime.utcnow()
    rec = (
        db.query(EmailCode)
        .filter(
            EmailCode.email == email,
            EmailCode.code == code,
            EmailCode.purpose == purpose,
            EmailCode.is_used == False,
        )
        .order_by(EmailCode.created_at.desc())
        .first()
    )
    if not rec:
        return False
    if rec.expires_at < now:
        return False

    # 标记已用，防止重复使用
    rec.is_used = True
    db.commit()
    return True


def cleanup_expired(db: Session):
    """清理过期验证码（可选，定期调用）"""
    now = datetime.utcnow()
    db.query(EmailCode).filter(EmailCode.expires_at < now).delete(synchronize_session=False)
    db.commit()
