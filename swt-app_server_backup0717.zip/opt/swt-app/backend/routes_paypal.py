"""PayPal Checkout integration for VIP purchases."""

import base64
import json
import os
from datetime import datetime, timedelta
from decimal import Decimal, InvalidOperation
from typing import Any, Optional
from urllib import parse as urllib_parse
from urllib import request as urllib_request
from urllib.error import HTTPError, URLError

from fastapi import APIRouter, Depends, Header, HTTPException, Request
from sqlalchemy.orm import Session

from auth import get_current_user
from database import PaymentOrder, SiteSetting, User, gen_id, get_db

router = APIRouter(prefix="/api/paypal", tags=["paypal"])


def setting_value(db: Session, key: str, env_name: str, default: str = "") -> str:
    setting = db.query(SiteSetting).filter(SiteSetting.key == key).first()
    if setting and setting.value:
        return setting.value.strip()
    return os.getenv(env_name, default).strip()


def paypal_env(db: Session) -> str:
    return setting_value(db, "paypal_env", "PAYPAL_ENV", "sandbox").lower()


def paypal_base_url(db: Session) -> str:
    env = paypal_env(db)
    if env in ("live", "production"):
        return "https://api-m.paypal.com"
    return "https://api-m.sandbox.paypal.com"


def paypal_client_id(db: Session) -> str:
    return setting_value(db, "paypal_client_id", "PAYPAL_CLIENT_ID")


def paypal_secret(db: Session) -> str:
    return setting_value(db, "paypal_secret", "PAYPAL_SECRET")


def paypal_webhook_id(db: Session) -> str:
    return setting_value(db, "paypal_webhook_id", "PAYPAL_WEBHOOK_ID")


def frontend_base_url(request: Request) -> str:
    origin = request.headers.get("origin")
    if origin:
        return origin.rstrip("/")
    referer = request.headers.get("referer")
    if referer:
        parsed = urllib_parse.urlparse(referer)
        if parsed.scheme and parsed.netloc:
            return f"{parsed.scheme}://{parsed.netloc}"
    return str(request.base_url).rstrip("/")


def vip_amount(db: Session) -> str:
    raw = setting_value(db, "vip_price_usd", "VIP_PRICE_USD", "39.99")
    try:
        amount = Decimal(raw)
    except InvalidOperation:
        raise HTTPException(500, "VIP_PRICE_USD is invalid")
    if amount <= 0:
        raise HTTPException(500, "VIP_PRICE_USD must be greater than 0")
    return f"{amount:.2f}"


def vip_days(db: Session) -> int:
    try:
        days = int(setting_value(db, "vip_days", "VIP_DAYS", "365"))
    except ValueError:
        raise HTTPException(500, "VIP_DAYS is invalid")
    if days <= 0:
        raise HTTPException(500, "VIP_DAYS must be greater than 0")
    return days


def paypal_request(db: Session, path: str, method: str = "GET", data: Optional[dict[str, Any]] = None, token: Optional[str] = None) -> dict[str, Any]:
    body = json.dumps(data).encode("utf-8") if data is not None else None
    headers = {
        "Accept": "application/json",
        "Content-Type": "application/json",
    }
    if token:
        headers["Authorization"] = f"Bearer {token}"
    req = urllib_request.Request(
        f"{paypal_base_url(db)}{path}",
        data=body,
        headers=headers,
        method=method,
    )
    try:
        with urllib_request.urlopen(req, timeout=20) as resp:
            payload = resp.read().decode("utf-8")
            return json.loads(payload) if payload else {}
    except HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")
        raise HTTPException(exc.code, f"PayPal API error: {detail[:500]}")
    except URLError as exc:
        raise HTTPException(502, f"PayPal API unavailable: {exc.reason}")


def paypal_access_token(db: Session) -> str:
    client_id = paypal_client_id(db)
    secret = paypal_secret(db)
    if not client_id or not secret:
        raise HTTPException(500, "PayPal credentials are not configured")
    credentials = base64.b64encode(f"{client_id}:{secret}".encode("utf-8")).decode("ascii")
    req = urllib_request.Request(
        f"{paypal_base_url(db)}/v1/oauth2/token",
        data=b"grant_type=client_credentials",
        headers={
            "Accept": "application/json",
            "Authorization": f"Basic {credentials}",
            "Content-Type": "application/x-www-form-urlencoded",
        },
        method="POST",
    )
    try:
        with urllib_request.urlopen(req, timeout=20) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            return data["access_token"]
    except HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")
        raise HTTPException(exc.code, f"PayPal auth error: {detail[:500]}")
    except (KeyError, URLError) as exc:
        raise HTTPException(502, f"PayPal auth unavailable: {exc}")


def activate_vip(db: Session, user: User, days: int) -> datetime:
    now = datetime.utcnow()
    current_expiry = user.vip_expires_at if user.vip_expires_at and user.vip_expires_at > now else now
    user.is_vip = True
    user.vip_expires_at = current_expiry + timedelta(days=days)
    db.commit()
    db.refresh(user)
    return user.vip_expires_at


def first_capture_from_order(order_data: dict[str, Any]) -> Optional[dict[str, Any]]:
    for unit in order_data.get("purchase_units", []):
        payments = unit.get("payments", {})
        captures = payments.get("captures", [])
        if captures:
            return captures[0]
    return None


def validate_capture_amount(capture: dict[str, Any], payment: PaymentOrder) -> None:
    amount = capture.get("amount") or {}
    if amount.get("currency_code") != payment.currency or amount.get("value") != payment.amount:
        raise HTTPException(400, "PayPal capture amount mismatch")


@router.get("/config")
def paypal_config(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    client_id = paypal_client_id(db)
    secret = paypal_secret(db)
    return {
        "client_id": client_id,
        "currency": "USD",
        "amount": vip_amount(db),
        "vip_days": vip_days(db),
        "enabled": bool(client_id and secret),
        "env": paypal_env(db),
    }


@router.post("/create-order")
def create_order(request: Request, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    amount = vip_amount(db)
    days = vip_days(db)
    order = PaymentOrder(
        id=gen_id(),
        user_id=user.id,
        amount=amount,
        currency="USD",
        vip_days=days,
        status="creating",
        created_at=datetime.utcnow(),
    )
    db.add(order)
    db.commit()

    token = paypal_access_token(db)
    payload = {
        "intent": "CAPTURE",
        "purchase_units": [
            {
                "reference_id": order.id,
                "custom_id": order.id,
                "description": f"SWT VIP {days} days",
                "amount": {"currency_code": "USD", "value": amount},
            }
        ],
        "application_context": {
            "brand_name": "SWT VIP",
            "landing_page": "LOGIN",
            "user_action": "PAY_NOW",
            "return_url": f"{frontend_base_url(request)}/vip?paypal_return=1",
            "cancel_url": f"{frontend_base_url(request)}/vip?paypal_cancel=1",
        },
    }
    data = paypal_request(db, "/v2/checkout/orders", method="POST", data=payload, token=token)
    order.provider_order_id = data.get("id")
    order.status = data.get("status", "CREATED").lower()
    order.raw_response = json.dumps(data, ensure_ascii=False)
    db.commit()
    approve_url = None
    for link in data.get("links", []):
        if link.get("rel") == "approve":
            approve_url = link.get("href")
            break
    return {"id": order.provider_order_id, "local_order_id": order.id, "approve_url": approve_url}


@router.post("/capture/{order_id}")
def capture_order(order_id: str, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    payment = db.query(PaymentOrder).filter(PaymentOrder.provider_order_id == order_id).first()
    if not payment:
        raise HTTPException(404, "Order not found")
    if payment.user_id != user.id:
        raise HTTPException(403, "Order does not belong to current user")
    if payment.status == "completed":
        return {"status": payment.status, "vip_expires_at": user.vip_expires_at.isoformat() + "Z" if user.vip_expires_at else None}

    token = paypal_access_token(db)
    data = paypal_request(db, f"/v2/checkout/orders/{order_id}/capture", method="POST", data={}, token=token)
    status = data.get("status", "").lower()
    if status != "completed":
        payment.status = status or "capture_failed"
        payment.raw_response = json.dumps(data, ensure_ascii=False)
        db.commit()
        raise HTTPException(400, f"Payment not completed: {data.get('status', 'unknown')}")

    capture = first_capture_from_order(data)
    if not capture:
        raise HTTPException(400, "PayPal capture data missing")
    validate_capture_amount(capture, payment)
    payment.status = "completed"
    payment.provider_capture_id = capture.get("id")
    payment.raw_response = json.dumps(data, ensure_ascii=False)
    payment.paid_at = datetime.utcnow()
    activate_vip(db, user, payment.vip_days)
    db.commit()
    db.refresh(user)
    return {
        "status": "completed",
        "vip_expires_at": user.vip_expires_at.isoformat() + "Z" if user.vip_expires_at else None,
    }


@router.post("/webhook")
async def paypal_webhook(
    request: Request,
    db: Session = Depends(get_db),
    paypal_transmission_id: Optional[str] = Header(None, alias="paypal-transmission-id"),
    paypal_transmission_time: Optional[str] = Header(None, alias="paypal-transmission-time"),
    paypal_cert_url: Optional[str] = Header(None, alias="paypal-cert-url"),
    paypal_auth_algo: Optional[str] = Header(None, alias="paypal-auth-algo"),
    paypal_transmission_sig: Optional[str] = Header(None, alias="paypal-transmission-sig"),
):
    webhook_id = paypal_webhook_id(db)
    body = await request.body()
    event = json.loads(body.decode("utf-8")) if body else {}

    if not webhook_id:
        return {"ok": False, "ignored": "paypal_webhook_id_not_configured"}

    token = paypal_access_token(db)
    verify_payload = {
        "auth_algo": paypal_auth_algo,
        "cert_url": paypal_cert_url,
        "transmission_id": paypal_transmission_id,
        "transmission_sig": paypal_transmission_sig,
        "transmission_time": paypal_transmission_time,
        "webhook_id": webhook_id,
        "webhook_event": event,
    }
    verified = paypal_request(db, "/v1/notifications/verify-webhook-signature", method="POST", data=verify_payload, token=token)
    if verified.get("verification_status") != "SUCCESS":
        raise HTTPException(400, "Invalid PayPal webhook signature")

    event_type = event.get("event_type")
    resource = event.get("resource", {})
    if event_type == "PAYMENT.CAPTURE.COMPLETED":
        capture_id = resource.get("id")
        custom_id = resource.get("custom_id")
        payment = None
        if custom_id:
            payment = db.query(PaymentOrder).filter(PaymentOrder.id == custom_id).first()
        if not payment and capture_id:
            payment = db.query(PaymentOrder).filter(PaymentOrder.provider_capture_id == capture_id).first()
        if payment and payment.status != "completed":
            user = db.query(User).filter(User.id == payment.user_id).first()
            if user:
                validate_capture_amount(resource, payment)
                payment.status = "completed"
                payment.provider_capture_id = capture_id or payment.provider_capture_id
                payment.raw_response = json.dumps(event, ensure_ascii=False)
                payment.paid_at = datetime.utcnow()
                activate_vip(db, user, payment.vip_days)

    return {"ok": True}
