﻿"""
数据库层 - SQLAlchemy ORM
==========================
开发环境使用 SQLite，部署时可通过 DATABASE_URL 切换到 PostgreSQL/MySQL

表结构：
  records       避雷记录（核心数据）
  users         用户（含管理员）
  user_activity_logs 用户活动日志
  categories    论坛板块
  posts         帖子
  comments      回复
  post_likes    帖子点赞
"""

import os
import json
import uuid
from datetime import datetime
from pathlib import Path


from sqlalchemy import (
    create_engine, Column, String, Boolean, Float, Integer, Text, DateTime,
    ForeignKey, UniqueConstraint
)
from sqlalchemy.orm import declarative_base, sessionmaker, relationship
from sqlalchemy.types import TypeDecorator

# ── 数据库连接 ────────────────────────────────────────────
DATA_DIR = Path(__file__).parent.parent / "data"
DATA_DIR.mkdir(exist_ok=True)

DATABASE_URL = os.getenv("DATABASE_URL", f"sqlite:///{DATA_DIR / 'swt.db'}")
connect_args = {"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {}
engine = create_engine(DATABASE_URL, connect_args=connect_args)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()


def gen_id():
    return str(uuid.uuid4())


class JSONList(TypeDecorator):
    impl = Text
    cache_ok = True

    def process_bind_param(self, value, dialect):
        return json.dumps(value or [], ensure_ascii=False)

    def process_result_value(self, value, dialect):
        if not value:
            return []
        try:
            return json.loads(value)
        except Exception:
            return []


class JSONDict(TypeDecorator):
    impl = Text
    cache_ok = True

    def process_bind_param(self, value, dialect):
        return json.dumps(value or {}, ensure_ascii=False)

    def process_result_value(self, value, dialect):
        if not value:
            return {}
        try:
            return json.loads(value)
        except Exception:
            return {}


# ── 避雷记录 ──────────────────────────────────────────────
class RecordModel(Base):
    __tablename__ = "records"
    id = Column(String(40), primary_key=True, default=gen_id)
    valuable = Column(Boolean, default=True, index=True)
    source_type = Column(String(20), default="post", index=True)
    job_position = Column(String(200))
    location_name = Column(String(200))
    city = Column(String(100))
    state = Column(String(10), index=True)
    hourly_wage = Column(Float)
    tips = Column(String(200))
    hours_per_day = Column(Float)
    hours_per_week = Column(Float)
    avoidance_reasons = Column(JSONList, default=list)
    severity = Column(Integer, default=3, index=True)
    confidence = Column(Float, default=0.8)
    review_status = Column(String(20), default="pending", index=True)  # pending | verified | needs_review | rejected
    review_note = Column(Text, default="")
    reviewed_by = Column(String(40), ForeignKey("users.id"), nullable=True)
    reviewed_at = Column(DateTime, nullable=True)
    submitted_by = Column(String(40), ForeignKey("users.id"), nullable=True, index=True)
    employer = Column(String(200))
    summary = Column(Text, default="")
    note_url = Column(Text, default="")
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def to_dict(self):
        return {
            "id": self.id, "valuable": self.valuable, "source_type": self.source_type,
            "job_position": self.job_position, "location_name": self.location_name,
            "city": self.city, "state": self.state, "hourly_wage": self.hourly_wage,
            "tips": self.tips, "hours_per_day": self.hours_per_day,
            "hours_per_week": self.hours_per_week, "avoidance_reasons": self.avoidance_reasons or [],
            "severity": self.severity, "confidence": self.confidence, "employer": self.employer,
            "review_status": self.review_status or "pending", "review_note": self.review_note or "",
            "reviewed_by": self.reviewed_by,
            "reviewed_at": self.reviewed_at.isoformat() + "Z" if self.reviewed_at else None,
            "submitted_by": self.submitted_by,
            "summary": self.summary or "", "note_url": self.note_url or "",
            "created_at": self.created_at.isoformat() + "Z" if self.created_at else None,
            "updated_at": self.updated_at.isoformat() + "Z" if self.updated_at else None,
        }


# ── 用户 ──────────────────────────────────────────────────
class User(Base):
    __tablename__ = "users"
    id = Column(String(40), primary_key=True, default=gen_id)
    username = Column(String(50), unique=True, nullable=False, index=True)
    email = Column(String(120), unique=True, nullable=True)
    password_hash = Column(String(200), nullable=False)
    role = Column(String(20), default="user")  # user | admin
    is_vip = Column(Boolean, default=False)     # VIP 用户可查看完整记录信息
    vip_expires_at = Column(DateTime, nullable=True)
    reputation = Column(Integer, default=0)
    assessment_credits = Column(Integer, default=0)
    assessment_monthly_limit = Column(Integer, default=10)
    ban_until = Column(DateTime, nullable=True)
    ban_reason = Column(Text, default="")
    avatar = Column(String(10), default="🐱")   # emoji 头像
    bio = Column(Text, default="")
    is_active = Column(Boolean, default=True)
    last_login_at = Column(DateTime, nullable=True)
    last_login_ip = Column(String(80), nullable=True)
    last_login_user_agent = Column(String(300), nullable=True)
    last_seen_at = Column(DateTime, nullable=True)
    last_seen_ip = Column(String(80), nullable=True)
    last_seen_user_agent = Column(String(300), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    posts = relationship("Post", back_populates="author", cascade="all, delete-orphan")
    comments = relationship("Comment", back_populates="author", cascade="all, delete-orphan")

    def to_dict(self, include_email=False):
        vip_active = bool(self.is_vip) and (self.vip_expires_at is None or self.vip_expires_at > datetime.utcnow())
        d = {
            "id": self.id, "username": self.username, "role": self.role,
            "is_vip": vip_active or self.role == "admin",
            "vip_expires_at": self.vip_expires_at.isoformat() + "Z" if self.vip_expires_at else None,
            "reputation": self.reputation or 0,
            "level": user_level(self.reputation or 0),
            "assessment_credits": self.assessment_credits or 0,
            "assessment_monthly_limit": self.assessment_monthly_limit or 10,
            "ban_until": self.ban_until.isoformat() + "Z" if self.ban_until else None,
            "ban_reason": self.ban_reason or "",
            "avatar": self.avatar, "bio": self.bio or "", "is_active": self.is_active,
            "last_login_at": self.last_login_at.isoformat() + "Z" if self.last_login_at else None,
            "last_login_ip": self.last_login_ip or "",
            "last_login_user_agent": self.last_login_user_agent or "",
            "last_seen_at": self.last_seen_at.isoformat() + "Z" if self.last_seen_at else None,
            "last_seen_ip": self.last_seen_ip or "",
            "last_seen_user_agent": self.last_seen_user_agent or "",
            "created_at": self.created_at.isoformat() + "Z" if self.created_at else None,
        }
        if include_email:
            d["email"] = self.email
        return d


class UserActivityLog(Base):
    __tablename__ = "user_activity_logs"
    id = Column(String(40), primary_key=True, default=gen_id)
    user_id = Column(String(40), ForeignKey("users.id"), nullable=False, index=True)
    kind = Column(String(20), default="active", index=True)  # login | active
    ip = Column(String(80), default="")
    user_agent = Column(String(300), default="")
    created_at = Column(DateTime, default=datetime.utcnow, index=True)

    user = relationship("User")

    def to_dict(self):
        return {
            "id": self.id,
            "user_id": self.user_id,
            "kind": self.kind,
            "ip": self.ip or "",
            "user_agent": self.user_agent or "",
            "created_at": self.created_at.isoformat() + "Z" if self.created_at else None,
        }


class PaymentOrder(Base):
    __tablename__ = "payment_orders"

    id = Column(String(40), primary_key=True, default=gen_id)
    user_id = Column(String(40), ForeignKey("users.id"), nullable=False, index=True)
    provider = Column(String(30), default="paypal", index=True)
    provider_order_id = Column(String(120), unique=True, nullable=True, index=True)
    provider_capture_id = Column(String(120), nullable=True, index=True)
    status = Column(String(30), default="created", index=True)
    amount = Column(String(20), nullable=False)
    currency = Column(String(10), default="USD")
    vip_days = Column(Integer, default=365)
    raw_response = Column(Text, default="")
    created_at = Column(DateTime, default=datetime.utcnow)
    paid_at = Column(DateTime, nullable=True)

    user = relationship("User")

    def to_dict(self):
        return {
            "id": self.id,
            "user_id": self.user_id,
            "provider": self.provider,
            "provider_order_id": self.provider_order_id,
            "provider_capture_id": self.provider_capture_id,
            "status": self.status,
            "amount": self.amount,
            "currency": self.currency,
            "vip_days": self.vip_days,
            "created_at": self.created_at.isoformat() + "Z" if self.created_at else None,
            "paid_at": self.paid_at.isoformat() + "Z" if self.paid_at else None,
        }


class VisaCard(Base):
    __tablename__ = "visa_cards"

    id = Column(String(40), primary_key=True, default=gen_id)
    user_id = Column(String(40), ForeignKey("users.id"), nullable=False, index=True)
    question = Column(Text, nullable=False)
    answer = Column(Text, nullable=False)
    category = Column(String(20), nullable=False, default="both", index=True)
    tag = Column(String(100), default="")
    sort_order = Column(Integer, default=0)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def to_dict(self):
        return {
            "id": self.id,
            "user_id": self.user_id,
            "question": self.question,
            "answer": self.answer,
            "category": self.category,
            "tag": self.tag or "",
            "sort_order": self.sort_order or 0,
            "created_at": self.created_at.isoformat() + "Z" if self.created_at else None,
            "updated_at": self.updated_at.isoformat() + "Z" if self.updated_at else None,
        }
class InviteCode(Base):
    __tablename__ = "invite_codes"

    id = Column(String(40), primary_key=True, default=gen_id)

    code = Column(String(100), unique=True, nullable=False, index=True)

    is_vip = Column(Boolean, default=True)

    max_uses = Column(Integer, default=1)

    used_count = Column(Integer, default=0)

    is_active = Column(Boolean, default=True)

    created_at = Column(DateTime, default=datetime.utcnow)

    def to_dict(self):
        return {
            "id": self.id,
            "code": self.code,
            "is_vip": self.is_vip,
            "max_uses": self.max_uses,
            "used_count": self.used_count,
            "remaining": max(0, self.max_uses - self.used_count),
            "is_active": self.is_active,
            "created_at": self.created_at.isoformat() + "Z"
                if self.created_at else None,
        }
# ── 板块 ──────────────────────────────────────────────────
class Category(Base):
    __tablename__ = "categories"
    id = Column(String(40), primary_key=True, default=gen_id)
    name = Column(String(50), unique=True, nullable=False)
    slug = Column(String(50), unique=True, nullable=False)
    description = Column(Text, default="")
    icon = Column(String(10), default="💬")
    sort_order = Column(Integer, default=0)
    created_at = Column(DateTime, default=datetime.utcnow)

    posts = relationship("Post", back_populates="category", cascade="all, delete-orphan")

    def to_dict(self, post_count=None):
        return {
            "id": self.id, "name": self.name, "slug": self.slug,
            "description": self.description or "", "icon": self.icon,
            "sort_order": self.sort_order,
            "post_count": post_count,
            "created_at": self.created_at.isoformat() + "Z" if self.created_at else None,
        }


# ── 帖子 ──────────────────────────────────────────────────
class Post(Base):
    __tablename__ = "posts"
    id = Column(String(40), primary_key=True, default=gen_id)
    category_id = Column(String(40), ForeignKey("categories.id"), nullable=False, index=True)
    author_id = Column(String(40), ForeignKey("users.id"), nullable=False, index=True)
    title = Column(String(300), nullable=False)
    body = Column(Text, default="")
    tags = Column(JSONList, default=list)
    image_urls = Column(JSONList, default=list)
    status = Column(String(20), default="published", index=True)
    is_pinned = Column(Boolean, default=False)
    is_locked = Column(Boolean, default=False)
    view_count = Column(Integer, default=0)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    last_activity_at = Column(DateTime, default=datetime.utcnow, index=True)

    category = relationship("Category", back_populates="posts")
    author = relationship("User", back_populates="posts")
    comments = relationship("Comment", back_populates="post", cascade="all, delete-orphan")
    likes = relationship("PostLike", back_populates="post", cascade="all, delete-orphan")

    def to_dict(self, comment_count=None, like_count=None, liked_by_me=False, favorite_count=None, favorited_by_me=False):
        return {
            "id": self.id, "category_id": self.category_id,
            "category_name": self.category.name if self.category else None,
            "category_slug": self.category.slug if self.category else None,
            "author_id": self.author_id,
            "author_name": self.author.username if self.author else "已注销",
            "author_avatar": self.author.avatar if self.author else "👤",
            "author_reputation": self.author.reputation if self.author else 0,
            "author_level": user_level(self.author.reputation or 0) if self.author else "Lv1",
            "title": self.title, "body": self.body or "",
            "tags": self.tags or [], "image_urls": self.image_urls or [],
            "status": self.status or "published",
            "is_pinned": self.is_pinned, "is_locked": self.is_locked,
            "view_count": self.view_count,
            "comment_count": comment_count,
            "like_count": like_count,
            "liked_by_me": liked_by_me,
            "favorite_count": favorite_count,
            "favorited_by_me": favorited_by_me,
            "created_at": self.created_at.isoformat() + "Z" if self.created_at else None,
            "updated_at": self.updated_at.isoformat() + "Z" if self.updated_at else None,
            "last_activity_at": self.last_activity_at.isoformat() + "Z" if self.last_activity_at else None,
        }


# ── 回复 ──────────────────────────────────────────────────
class Comment(Base):
    __tablename__ = "comments"
    id = Column(String(40), primary_key=True, default=gen_id)
    post_id = Column(String(40), ForeignKey("posts.id"), nullable=False, index=True)
    author_id = Column(String(40), ForeignKey("users.id"), nullable=False)
    body = Column(Text, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)

    post = relationship("Post", back_populates="comments")
    author = relationship("User", back_populates="comments")

    def to_dict(self):
        return {
            "id": self.id, "post_id": self.post_id, "author_id": self.author_id,
            "author_name": self.author.username if self.author else "已注销",
            "author_avatar": self.author.avatar if self.author else "👤",
            "body": self.body,
            "created_at": self.created_at.isoformat() + "Z" if self.created_at else None,
        }


# ── 点赞 ──────────────────────────────────────────────────
class PostLike(Base):
    __tablename__ = "post_likes"
    __table_args__ = (UniqueConstraint("post_id", "user_id", name="uq_post_user"),)
    id = Column(String(40), primary_key=True, default=gen_id)
    post_id = Column(String(40), ForeignKey("posts.id"), nullable=False, index=True)
    user_id = Column(String(40), ForeignKey("users.id"), nullable=False, index=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    post = relationship("Post", back_populates="likes")


class Favorite(Base):
    __tablename__ = "favorites"
    __table_args__ = (UniqueConstraint("user_id", "target_type", "target_id", name="uq_favorite_target"),)
    id = Column(String(40), primary_key=True, default=gen_id)
    user_id = Column(String(40), ForeignKey("users.id"), nullable=False, index=True)
    group_id = Column(String(40), ForeignKey("favorite_groups.id"), nullable=True, index=True)
    target_type = Column(String(20), nullable=False, index=True)  # record | post
    target_id = Column(String(40), nullable=False, index=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    group = relationship("FavoriteGroup")

    def to_dict(self):
        return {
            "id": self.id, "user_id": self.user_id,
            "group_id": self.group_id,
            "group_name": self.group.name if self.group else None,
            "target_type": self.target_type, "target_id": self.target_id,
            "created_at": self.created_at.isoformat() + "Z" if self.created_at else None,
        }


class FavoriteGroup(Base):
    __tablename__ = "favorite_groups"
    id = Column(String(40), primary_key=True, default=gen_id)
    user_id = Column(String(40), ForeignKey("users.id"), nullable=False, index=True)
    name = Column(String(80), nullable=False)
    sort_order = Column(Integer, default=0)
    created_at = Column(DateTime, default=datetime.utcnow)

    def to_dict(self, favorite_count=0):
        return {
            "id": self.id, "user_id": self.user_id, "name": self.name,
            "sort_order": self.sort_order,
            "favorite_count": favorite_count,
            "created_at": self.created_at.isoformat() + "Z" if self.created_at else None,
        }


class RecordFeedback(Base):
    __tablename__ = "record_feedback"
    id = Column(String(40), primary_key=True, default=gen_id)
    record_id = Column(String(40), ForeignKey("records.id"), nullable=False, index=True)
    user_id = Column(String(40), ForeignKey("users.id"), nullable=False, index=True)
    reason = Column(String(80), default="")
    detail = Column(Text, default="")
    status = Column(String(20), default="open", index=True)  # open | resolved | dismissed
    created_at = Column(DateTime, default=datetime.utcnow)
    resolved_at = Column(DateTime, nullable=True)
    resolved_by = Column(String(40), ForeignKey("users.id"), nullable=True)

    record = relationship("RecordModel")
    user = relationship("User", foreign_keys=[user_id])

    def to_dict(self):
        return {
            "id": self.id, "record_id": self.record_id,
            "user_id": self.user_id,
            "username": self.user.username if self.user else "已注销",
            "reason": self.reason or "", "detail": self.detail or "",
            "status": self.status or "open",
            "record_summary": self.record.summary if self.record else "记录已删除",
            "record_state": self.record.state if self.record else None,
            "record_job_position": self.record.job_position if self.record else None,
            "created_at": self.created_at.isoformat() + "Z" if self.created_at else None,
            "resolved_at": self.resolved_at.isoformat() + "Z" if self.resolved_at else None,
            "resolved_by": self.resolved_by,
        }


class Report(Base):
    __tablename__ = "reports"
    id = Column(String(40), primary_key=True, default=gen_id)
    target_type = Column(String(20), nullable=False, index=True)  # post | comment
    target_id = Column(String(40), nullable=False, index=True)
    reporter_id = Column(String(40), ForeignKey("users.id"), nullable=False, index=True)
    reason = Column(String(80), default="")
    detail = Column(Text, default="")
    status = Column(String(20), default="open", index=True)  # open | resolved | dismissed
    created_at = Column(DateTime, default=datetime.utcnow)
    resolved_at = Column(DateTime, nullable=True)
    resolved_by = Column(String(40), ForeignKey("users.id"), nullable=True)

    reporter = relationship("User", foreign_keys=[reporter_id])

    def to_dict(self):
        return {
            "id": self.id, "target_type": self.target_type, "target_id": self.target_id,
            "reporter_id": self.reporter_id,
            "reporter_name": self.reporter.username if self.reporter else "已注销",
            "reason": self.reason or "", "detail": self.detail or "",
            "status": self.status or "open",
            "created_at": self.created_at.isoformat() + "Z" if self.created_at else None,
            "resolved_at": self.resolved_at.isoformat() + "Z" if self.resolved_at else None,
            "resolved_by": self.resolved_by,
        }


class Notification(Base):
    __tablename__ = "notifications"
    id = Column(String(40), primary_key=True, default=gen_id)
    user_id = Column(String(40), ForeignKey("users.id"), nullable=False, index=True)
    actor_id = Column(String(40), ForeignKey("users.id"), nullable=True)
    type = Column(String(40), default="system", index=True)
    title = Column(String(200), default="")
    body = Column(Text, default="")
    target_type = Column(String(20), default="")
    target_id = Column(String(40), default="")
    is_read = Column(Boolean, default=False, index=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    actor = relationship("User", foreign_keys=[actor_id])

    def to_dict(self):
        return {
            "id": self.id, "user_id": self.user_id,
            "actor_id": self.actor_id,
            "actor_name": self.actor.username if self.actor else None,
            "type": self.type, "title": self.title or "", "body": self.body or "",
            "target_type": self.target_type or "", "target_id": self.target_id or "",
            "is_read": bool(self.is_read),
            "created_at": self.created_at.isoformat() + "Z" if self.created_at else None,
        }


class Announcement(Base):
    __tablename__ = "announcements"
    id = Column(String(40), primary_key=True, default=gen_id)
    title = Column(String(200), nullable=False)
    body = Column(Text, default="")
    level = Column(String(20), default="info")  # info | success | warning | danger
    link_url = Column(Text, default="")
    is_active = Column(Boolean, default=True, index=True)
    is_pinned = Column(Boolean, default=False, index=True)
    starts_at = Column(DateTime, nullable=True)
    ends_at = Column(DateTime, nullable=True)
    created_by = Column(String(40), ForeignKey("users.id"), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    creator = relationship("User")

    def to_dict(self, is_read=False):
        return {
            "id": self.id,
            "title": self.title or "",
            "body": self.body or "",
            "level": self.level or "info",
            "link_url": self.link_url or "",
            "is_active": bool(self.is_active),
            "is_pinned": bool(self.is_pinned),
            "is_read": bool(is_read),
            "created_by": self.created_by,
            "creator_name": self.creator.username if self.creator else None,
            "starts_at": self.starts_at.isoformat() + "Z" if self.starts_at else None,
            "ends_at": self.ends_at.isoformat() + "Z" if self.ends_at else None,
            "created_at": self.created_at.isoformat() + "Z" if self.created_at else None,
            "updated_at": self.updated_at.isoformat() + "Z" if self.updated_at else None,
        }


class AnnouncementRead(Base):
    __tablename__ = "announcement_reads"
    __table_args__ = (UniqueConstraint("announcement_id", "user_id", name="uq_announcement_user"),)
    id = Column(String(40), primary_key=True, default=gen_id)
    announcement_id = Column(String(40), ForeignKey("announcements.id"), nullable=False, index=True)
    user_id = Column(String(40), ForeignKey("users.id"), nullable=False, index=True)
    read_at = Column(DateTime, default=datetime.utcnow)


class Draft(Base):
    __tablename__ = "drafts"
    id = Column(String(40), primary_key=True, default=gen_id)
    user_id = Column(String(40), ForeignKey("users.id"), nullable=False, index=True)
    category_id = Column(String(40), ForeignKey("categories.id"), nullable=True)
    title = Column(String(300), default="")
    body = Column(Text, default="")
    tags = Column(JSONList, default=list)
    image_urls = Column(JSONList, default=list)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    category = relationship("Category")

    def to_dict(self):
        return {
            "id": self.id, "user_id": self.user_id, "category_id": self.category_id,
            "category_name": self.category.name if self.category else None,
            "title": self.title or "", "body": self.body or "",
            "tags": self.tags or [], "image_urls": self.image_urls or [],
            "created_at": self.created_at.isoformat() + "Z" if self.created_at else None,
            "updated_at": self.updated_at.isoformat() + "Z" if self.updated_at else None,
        }


class SensitiveWord(Base):
    __tablename__ = "sensitive_words"
    id = Column(String(40), primary_key=True, default=gen_id)
    word = Column(String(120), unique=True, nullable=False, index=True)
    action = Column(String(20), default="block")  # block
    is_active = Column(Boolean, default=True, index=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    def to_dict(self):
        return {
            "id": self.id, "word": self.word, "action": self.action,
            "is_active": bool(self.is_active),
            "created_at": self.created_at.isoformat() + "Z" if self.created_at else None,
        }


class BanRecord(Base):
    __tablename__ = "ban_records"
    id = Column(String(40), primary_key=True, default=gen_id)
    user_id = Column(String(40), ForeignKey("users.id"), nullable=False, index=True)
    admin_id = Column(String(40), ForeignKey("users.id"), nullable=True)
    reason = Column(Text, default="")
    starts_at = Column(DateTime, default=datetime.utcnow)
    ends_at = Column(DateTime, nullable=True)
    is_active = Column(Boolean, default=True, index=True)

    user = relationship("User", foreign_keys=[user_id])
    admin = relationship("User", foreign_keys=[admin_id])

    def to_dict(self):
        return {
            "id": self.id, "user_id": self.user_id,
            "username": self.user.username if self.user else "已注销",
            "admin_id": self.admin_id,
            "admin_name": self.admin.username if self.admin else None,
            "reason": self.reason or "",
            "starts_at": self.starts_at.isoformat() + "Z" if self.starts_at else None,
            "ends_at": self.ends_at.isoformat() + "Z" if self.ends_at else None,
            "is_active": bool(self.is_active),
        }


class AssessmentUsage(Base):
    __tablename__ = "assessment_usage"
    id = Column(String(40), primary_key=True, default=gen_id)
    user_id = Column(String(40), ForeignKey("users.id"), nullable=False, index=True)
    query = Column(String(300), default="")
    address = Column(String(500), default="")
    score = Column(Integer, default=0)
    used_credit = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow, index=True)

    user = relationship("User")

    def to_dict(self):
        return {
            "id": self.id,
            "user_id": self.user_id,
            "query": self.query or "",
            "address": self.address or "",
            "score": self.score or 0,
            "used_credit": bool(self.used_credit),
            "created_at": self.created_at.isoformat() + "Z" if self.created_at else None,
        }


class AIConfig(Base):
    __tablename__ = "ai_configs"
    id = Column(String(40), primary_key=True, default=gen_id)
    name = Column(String(80), default="default", unique=True, nullable=False, index=True)
    provider = Column(String(40), default="openai_compatible")
    base_url = Column(String(300), default="https://api.openai.com/v1")
    api_key = Column(Text, default="")
    model = Column(String(120), default="gpt-4o-mini")
    enabled = Column(Boolean, default=False)
    temperature = Column(Float, default=0.2)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    created_at = Column(DateTime, default=datetime.utcnow)

    def to_dict(self, include_secret=False):
        data = {
            "id": self.id,
            "name": self.name,
            "provider": self.provider or "openai_compatible",
            "base_url": self.base_url or "",
            "model": self.model or "",
            "enabled": bool(self.enabled),
            "temperature": self.temperature if self.temperature is not None else 0.2,
            "has_api_key": bool(self.api_key),
            "api_key_masked": mask_secret(self.api_key),
            "created_at": self.created_at.isoformat() + "Z" if self.created_at else None,
            "updated_at": self.updated_at.isoformat() + "Z" if self.updated_at else None,
        }
        if include_secret:
            data["api_key"] = self.api_key or ""
        return data


def mask_secret(value: str) -> str:
    if not value:
        return ""
    if len(value) <= 8:
        return "****"
    return f"{value[:4]}...{value[-4:]}"


def user_level(reputation: int) -> str:
    if reputation >= 500:
        return "Lv5"
    if reputation >= 200:
        return "Lv4"
    if reputation >= 80:
        return "Lv3"
    if reputation >= 20:
        return "Lv2"
    return "Lv1"


# ── 邮箱验证码 ────────────────────────────────────────────
class EmailCode(Base):
    """邮箱验证码记录（注册/找回密码用）"""
    __tablename__ = "email_codes"
    id = Column(String(40), primary_key=True, default=gen_id)
    email = Column(String(120), nullable=False, index=True)
    code = Column(String(10), nullable=False)
    purpose = Column(String(20), default="register")  # register | reset_password
    is_used = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    expires_at = Column(DateTime, nullable=False)


class Translation(Base):
    __tablename__ = "translations"
    __table_args__ = (
        UniqueConstraint("entity_type", "entity_id", "locale", name="uq_translation_entity_locale"),
    )
    id = Column(String(40), primary_key=True, default=gen_id)
    entity_type = Column(String(40), nullable=False, index=True)
    entity_id = Column(String(40), nullable=False, index=True)
    locale = Column(String(10), nullable=False, default="en", index=True)
    source_hash = Column(String(64), nullable=False, default="")
    fields_json = Column(JSONDict, default=dict)
    status = Column(String(20), default="pending", index=True)  # pending | translated | stale | failed
    error = Column(Text, default="")
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def to_dict(self):
        return {
            "id": self.id,
            "entity_type": self.entity_type,
            "entity_id": self.entity_id,
            "locale": self.locale,
            "source_hash": self.source_hash,
            "fields": self.fields_json or {},
            "status": self.status or "pending",
            "error": self.error or "",
            "created_at": self.created_at.isoformat() + "Z" if self.created_at else None,
            "updated_at": self.updated_at.isoformat() + "Z" if self.updated_at else None,
        }


class SiteSetting(Base):
    __tablename__ = "site_settings"
    key = Column(String(80), primary_key=True)
    value = Column(Text, default="")
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def to_dict(self):
        return {
            "key": self.key,
            "value": self.value or "",
            "updated_at": self.updated_at.isoformat() + "Z" if self.updated_at else None,
        }


# ──────────────────────────────────────────────────────────
def init_db():
    Base.metadata.create_all(bind=engine)
    _migrate()
    _seed_defaults()


def _migrate():
    """轻量迁移：给已存在的表补新列（SQLite/通用）"""
    from sqlalchemy import text
    with engine.connect() as conn:
        try:
            conn.execute(text("ALTER TABLE users ADD COLUMN is_vip BOOLEAN DEFAULT 0"))
            conn.commit()
        except Exception:
            pass  # 列已存在
        # 把 NULL 值统一改成 0
        try:
            conn.execute(text("UPDATE users SET is_vip = 0 WHERE is_vip IS NULL"))
            conn.commit()
        except Exception:
            pass
        for sql in [
            "ALTER TABLE users ADD COLUMN vip_expires_at DATETIME",
            "ALTER TABLE users ADD COLUMN reputation INTEGER DEFAULT 0",
            "ALTER TABLE users ADD COLUMN assessment_credits INTEGER DEFAULT 0",
            "ALTER TABLE users ADD COLUMN assessment_monthly_limit INTEGER DEFAULT 10",
            "ALTER TABLE users ADD COLUMN ban_until DATETIME",
            "ALTER TABLE users ADD COLUMN ban_reason TEXT DEFAULT ''",
            "ALTER TABLE users ADD COLUMN last_login_at DATETIME",
            "ALTER TABLE users ADD COLUMN last_login_ip VARCHAR(80)",
            "ALTER TABLE users ADD COLUMN last_login_user_agent VARCHAR(300)",
            "ALTER TABLE users ADD COLUMN last_seen_at DATETIME",
            "ALTER TABLE users ADD COLUMN last_seen_ip VARCHAR(80)",
            "ALTER TABLE users ADD COLUMN last_seen_user_agent VARCHAR(300)",
            "ALTER TABLE posts ADD COLUMN tags TEXT",
            "ALTER TABLE posts ADD COLUMN image_urls TEXT",
            "ALTER TABLE posts ADD COLUMN status VARCHAR(20) DEFAULT 'published'",
            "ALTER TABLE posts ADD COLUMN last_activity_at DATETIME",
            "ALTER TABLE records ADD COLUMN review_status VARCHAR(20) DEFAULT 'pending'",
            "ALTER TABLE records ADD COLUMN review_note TEXT DEFAULT ''",
            "ALTER TABLE records ADD COLUMN reviewed_by VARCHAR(40)",
            "ALTER TABLE records ADD COLUMN reviewed_at DATETIME",
            "ALTER TABLE records ADD COLUMN submitted_by VARCHAR(40)",
            "ALTER TABLE favorites ADD COLUMN group_id VARCHAR(40)",
        ]:
            try:
                conn.execute(text(sql))
                conn.commit()
            except Exception:
                pass
        try:
            conn.execute(text("""
                CREATE TABLE IF NOT EXISTS payment_orders (
                    id VARCHAR(40) PRIMARY KEY,
                    user_id VARCHAR(40) NOT NULL,
                    provider VARCHAR(30) DEFAULT 'paypal',
                    provider_order_id VARCHAR(120) UNIQUE,
                    provider_capture_id VARCHAR(120),
                    status VARCHAR(30) DEFAULT 'created',
                    amount VARCHAR(20) NOT NULL,
                    currency VARCHAR(10) DEFAULT 'USD',
                    vip_days INTEGER DEFAULT 365,
                    raw_response TEXT DEFAULT '',
                    created_at DATETIME,
                    paid_at DATETIME,
                    FOREIGN KEY(user_id) REFERENCES users(id)
                )
            """))
            conn.execute(text("CREATE INDEX IF NOT EXISTS ix_payment_orders_user_id ON payment_orders(user_id)"))
            conn.execute(text("CREATE INDEX IF NOT EXISTS ix_payment_orders_provider ON payment_orders(provider)"))
            conn.execute(text("CREATE INDEX IF NOT EXISTS ix_payment_orders_provider_order_id ON payment_orders(provider_order_id)"))
            conn.execute(text("CREATE INDEX IF NOT EXISTS ix_payment_orders_provider_capture_id ON payment_orders(provider_capture_id)"))
            conn.execute(text("CREATE INDEX IF NOT EXISTS ix_payment_orders_status ON payment_orders(status)"))
            conn.commit()
        except Exception:
            pass
        try:
            conn.execute(text("""
                CREATE TABLE IF NOT EXISTS translations (
                    id VARCHAR(40) PRIMARY KEY,
                    entity_type VARCHAR(40) NOT NULL,
                    entity_id VARCHAR(40) NOT NULL,
                    locale VARCHAR(10) NOT NULL DEFAULT 'en',
                    source_hash VARCHAR(64) NOT NULL DEFAULT '',
                    fields_json TEXT DEFAULT '{}',
                    status VARCHAR(20) DEFAULT 'pending',
                    error TEXT DEFAULT '',
                    created_at DATETIME,
                    updated_at DATETIME
                )
            """))
            conn.execute(text("CREATE UNIQUE INDEX IF NOT EXISTS uq_translation_entity_locale ON translations(entity_type, entity_id, locale)"))
            conn.execute(text("CREATE INDEX IF NOT EXISTS ix_translations_entity_type ON translations(entity_type)"))
            conn.execute(text("CREATE INDEX IF NOT EXISTS ix_translations_entity_id ON translations(entity_id)"))
            conn.execute(text("CREATE INDEX IF NOT EXISTS ix_translations_locale ON translations(locale)"))
            conn.execute(text("CREATE INDEX IF NOT EXISTS ix_translations_status ON translations(status)"))
            conn.commit()
        except Exception:
            pass
        try:
            conn.execute(text("""
                CREATE TABLE IF NOT EXISTS site_settings (
                    key VARCHAR(80) PRIMARY KEY,
                    value TEXT DEFAULT '',
                    updated_at DATETIME
                )
            """))
            conn.commit()
        except Exception:
            pass
        try:
            conn.execute(text("UPDATE users SET reputation = 0 WHERE reputation IS NULL"))
            conn.execute(text("UPDATE users SET assessment_credits = 0 WHERE assessment_credits IS NULL"))
            conn.execute(text("UPDATE users SET assessment_monthly_limit = 10 WHERE assessment_monthly_limit IS NULL"))
            conn.execute(text("UPDATE users SET ban_reason = '' WHERE ban_reason IS NULL"))
            conn.execute(text("UPDATE posts SET tags = '[]' WHERE tags IS NULL"))
            conn.execute(text("UPDATE posts SET image_urls = '[]' WHERE image_urls IS NULL"))
            conn.execute(text("UPDATE posts SET status = 'published' WHERE status IS NULL"))
            conn.execute(text("UPDATE posts SET last_activity_at = COALESCE(updated_at, created_at) WHERE last_activity_at IS NULL"))
            conn.execute(text("UPDATE records SET review_status = 'verified' WHERE review_status IS NULL OR (review_status = 'pending' AND submitted_by IS NULL)"))
            conn.execute(text("UPDATE records SET review_note = '' WHERE review_note IS NULL"))
            conn.commit()
        except Exception:
            pass



def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def _seed_defaults():
    """初始化默认管理员账号和默认板块"""
    from auth import hash_password  # 导入统一的哈希函数
    db = SessionLocal()
    try:
        # 默认管理员
        admin = db.query(User).filter(User.username == "admin").first()
        if not admin:
            pw = os.getenv("ADMIN_PASSWORD", "admin123")
            admin = User(
                id=gen_id(), username="admin",
                email="admin@swt.local",
                password_hash=hash_password(pw),  # 使用统一的哈希函数
                role="admin", avatar="🛡️", bio="系统管理员",
            )
            db.add(admin)

        # 默认板块
        if db.query(Category).count() == 0:
            defaults = [
                ("SWT避雷", "swt-warning", "分享踩坑经历，帮后来者避坑", "⚠️", 1),
                ("美国找搭子", "find-partner", "寻找同行小伙伴、合租室友", "🤝", 2),
                ("面签讨论", "visa-interview", "J1 签证面试经验交流", "🛂", 3),
                ("岗位推荐", "job-rec", "好雇主、好岗位推荐", "💼", 4),
                ("闲聊灌水", "chitchat", "随便聊聊，轻松一下", "💬", 5),
            ]
            for name, slug, desc, icon, order in defaults:
                db.add(Category(id=gen_id(), name=name, slug=slug,
                                description=desc, icon=icon, sort_order=order))

        # 默认邀请码
        founding = (
            db.query(InviteCode)
            .filter(InviteCode.code == "FOUNDING200")
            .first()
        )

        if not founding:
            db.add(
                InviteCode(
                    id=gen_id(),
                    code="FOUNDING200",
                    is_vip=True,
                    max_uses=200,
                    used_count=0,
                    is_active=True,
                )
            )

        vip_contact = db.query(SiteSetting).filter(SiteSetting.key == "vip_contact").first()
        if not vip_contact:
            db.add(SiteSetting(
                key="vip_contact",
                value="请联系管理员开通 VIP：\n微信：请在后台配置\n邮箱：admin@swt.local",
            ))
        db.commit()
    finally:
        db.close()

