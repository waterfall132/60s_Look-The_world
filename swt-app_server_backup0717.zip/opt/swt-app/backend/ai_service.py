"""统一 AI 调用配置与 OpenAI-compatible 客户端。

后台可维护一个默认 AI 配置。所有 AI 功能都应从这里读取配置，
避免在业务代码里散落环境变量和第三方 API 地址。
"""

import json
import os
import time
import urllib.error
import urllib.request
from typing import Optional

from sqlalchemy.orm import Session

from database import AIConfig, gen_id


DEFAULT_BASE_URL = "https://api.openai.com/v1"
DEFAULT_MODEL = "gpt-4o-mini"


def get_or_create_ai_config(db: Session) -> AIConfig:
    config = db.query(AIConfig).filter(AIConfig.name == "default").first()
    if config:
        return config

    # 兼容旧环境变量：如果生产环境已配置 OPENAI_API_KEY，首次启动时自动导入。
    api_key = os.getenv("OPENAI_API_KEY", "").strip()
    config = AIConfig(
        id=gen_id(),
        name="default",
        provider=os.getenv("AI_PROVIDER", "openai_compatible").strip() or "openai_compatible",
        base_url=os.getenv("AI_BASE_URL", DEFAULT_BASE_URL).strip() or DEFAULT_BASE_URL,
        api_key=api_key,
        model=os.getenv("AI_MODEL", os.getenv("OPENAI_ASSESSMENT_MODEL", DEFAULT_MODEL)).strip() or DEFAULT_MODEL,
        enabled=bool(api_key) and os.getenv("AI_ENABLED", "true").lower() not in {"0", "false", "no", "off"},
        temperature=float(os.getenv("AI_TEMPERATURE", "0.2")),
    )
    db.add(config)
    db.commit()
    db.refresh(config)
    return config


def is_ai_ready(config: AIConfig) -> bool:
    return bool(config and config.enabled and config.api_key and config.base_url and config.model)


def chat_json(
    db: Session,
    messages: list[dict],
    *,
    temperature: Optional[float] = None,
    timeout: float = 20,
) -> Optional[dict]:
    config = get_or_create_ai_config(db)
    if not is_ai_ready(config):
        return None

    base_url = (config.base_url or DEFAULT_BASE_URL).rstrip("/")
    payload = {
        "model": config.model or DEFAULT_MODEL,
        "messages": messages,
        "temperature": temperature if temperature is not None else (config.temperature if config.temperature is not None else 0.2),
    }
    data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(
        f"{base_url}/chat/completions",
        data=data,
        headers={
            "Authorization": f"Bearer {config.api_key}",
            "Content-Type": "application/json",
        },
    )
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        raw = json.loads(resp.read().decode("utf-8"))

    content = raw["choices"][0]["message"]["content"].strip()
    if content.startswith("```"):
        content = content.strip("`")
        content = content.replace("json\n", "", 1).replace("JSON\n", "", 1)
    return json.loads(content)


def test_ai_config(
    *,
    base_url: str,
    api_key: str,
    model: str,
    temperature: float = 0.2,
    timeout: float = 20,
) -> dict:
    """Test an OpenAI-compatible chat/completions endpoint without persisting config."""
    started = time.monotonic()
    try:
        payload = {
            "model": model,
            "messages": [
                {"role": "system", "content": "Reply with a short plain text health check."},
                {"role": "user", "content": "Say: SWT AI OK"},
            ],
            "temperature": temperature,
            "max_tokens": 32,
        }
        data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        req = urllib.request.Request(
            f"{base_url.rstrip('/')}/chat/completions",
            data=data,
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
            },
        )
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            raw = json.loads(resp.read().decode("utf-8"))
        content = raw["choices"][0]["message"]["content"].strip()
        return {
            "ok": True,
            "status": "success",
            "latency_ms": round((time.monotonic() - started) * 1000),
            "content_preview": content[:200],
        }
    except urllib.error.HTTPError as e:
        try:
            body = e.read().decode("utf-8", errors="replace")
        except Exception:
            body = ""
        return {
            "ok": False,
            "status": "http_error",
            "http_status": e.code,
            "latency_ms": round((time.monotonic() - started) * 1000),
            "error": (body or str(e))[:500],
        }
    except Exception as e:
        return {
            "ok": False,
            "status": "request_error",
            "latency_ms": round((time.monotonic() - started) * 1000),
            "error": str(e)[:500],
        }
