"""
论坛种子数据导入脚本
====================
用法：
  cd backend
  python seed_forum.py

功能：
  1. 创建 18 个模拟用户（多国籍昵称，emoji头像）
  2. 在 5 个板块发布 25 篇帖子（基于真实 J1/SWT 话题改编）
  3. 为帖子添加 80+ 条回复（多用户视角交叉互动）
  4. 随机点赞
  5. 时间戳错开 1-30 天，模拟自然发帖节奏

注意：
  - 脚本幂等，多次运行会跳过已有用户（按 username 去重）
  - 不会影响已有的 admin 账号和真实用户数据
  - 生成的用户密码统一为 seed123（可登录体验）
"""

import sys
import os
import random
from datetime import datetime, timedelta

sys.path.insert(0, os.path.dirname(__file__))

from database import (
    SessionLocal, User, Category, Post, Comment, PostLike,
    gen_id, init_db
)
from auth import hash_password

# 确保表已建好
init_db()

db = SessionLocal()

# ════════════════════════════════════════════════════════
# 1. 种子用户
# ════════════════════════════════════════════════════════
SEED_USERS = [
    ("SWT老司机", "🦊", "21年SWT老人，去过OH和VA，踩过的坑比走过的路还长"),
    ("小红薯Jessica", "🍓", "J1两年经验 分享真实避雷信息"),
    ("佛州阳光boy", "☀️", "在FL做过两个暑假lifeguard，AMA"),
    ("马里兰吐槽王", "😤", "MD OC三个月 一把辛酸泪"),
    ("签证达人Lucy", "📋", "帮20+朋友准备过面签，经验丰富"),
    ("NYC打工人", "🗽", "纽约餐饮行业搬砖中"),
    ("田纳西逃兵", "🏃", "从TN水上乐园跑路的真实经历"),
    ("加州小柠檬", "🍋", "CA实习生 酒店管理专业"),
    ("波士顿海鲜哥", "🦞", "在波士顿海鲜餐厅打工 时薪还不错"),
    ("科罗拉多滑雪⛷", "⛷️", "CO冬季SWT veteran"),
    ("Luka_Croatia", "🇭🇷", "Croatian student, Cape May NJ"),
    ("Ahmed_Egypt", "🇪🇬", "Exchange student from Cairo"),
    ("Selena_MV", "🌊", "Martha's Vineyard survivor"),
    ("菲律宾实习生Kris", "🇵🇭", "Manila→LA J1 intern"),
    ("立陶宛双子花", "🌸", "两个立陶宛女生 CT Mystic"),
    ("达拉斯找室友", "🏠", "Dallas求合租的社畜"),
    ("OC木板路厨师", "🍳", "Ocean City MD boardwalk餐厅"),
    ("安克雷奇背包客", "🎒", "Alaska J1 最北端打工人"),
    ("卢卡·科拉里奇", "🇭🇷", "Cape May 打工学生，房子太小没法放东西"),
    ("FunOlive4809", "🫒", "夏令营辅导员提前回国，ESTA 问题求助"),
    ("塞琳娜·M.", "🌊", "玛莎葡萄园 DQ 求职者"),
    ("艾哈迈德·萨梅赫", "🇪🇬", "16岁埃及学生，寻找廉价 J1 交换项目"),
    ("清洁 Qwx", "🧹", "弗吉尼亚威廉斯堡找房中"),
    ("国际学生宿舍", "🏢", "H2B/J1 住宿供应商"),
    ("卡卡克尔恩恩", "🏖️", "迈阿密海滩实习两人组"),
    ("MemorableOtter6875", "🦦", "津贴微薄，如何生存？"),
    ("匿名互动者_214b", "😭", "因社交媒体私密被 214b 拒签的倒霉蛋"),
    ("匿名互动者_DS2019", "📅", "DS‑2019 日期变更问题"),
    ("OrangePelican8815", "🇵🇭", "菲律宾 J1 培训生申请者"),
    ("ExcitingTangerine1160", "🍊", "J1 结束后 8 个月持 B 签返美"),
    ("匿名互动者_雇主威胁", "⚠️", "被雇主威胁遣返的经历分享"),
    ("ThoughtfulElk6161", "🦌", "埃及学生被扣护照查社交账号"),
    ("DelightfulPomelo7897", "🍊", "被解雇后使用 30 天旅行期"),
    ("EmpatheticHedgehog5994", "🦔", "212(e) 豁免因菲方不反对函被卡"),
    ("阿米娜·扎克西利克", "🚲", "纽波特借自行车小能手"),
    ("马特亚·卡蒂奇", "💼", "波士顿找工作的 J1 学生"),
    ("Yuxin Xiao", "🧳", "达拉斯 Arlington 找短租的中国学生"),
    ("匿名互动者_面签晚", "⏰", "面签日期晚于项目开始日"),
]

user_map = {}  # username → User object
pw_hash = hash_password("seed123")

for username, avatar, bio in SEED_USERS:
    existing = db.query(User).filter(User.username == username).first()
    if existing:
        user_map[username] = existing
        continue
    u = User(
        id=gen_id(), username=username,
        email=f"{username.replace(' ','').lower()[:12]}@seed.local",
        password_hash=pw_hash, role="user", is_vip=True,
        avatar=avatar, bio=bio, is_active=True,
    )
    db.add(u)
    db.flush()
    user_map[username] = u

db.commit()
print(f"✓ 用户就绪: {len(user_map)} 个")

# ════════════════════════════════════════════════════════
# 2. 获取板块映射
# ════════════════════════════════════════════════════════
cats = {c.slug: c for c in db.query(Category).all()}
assert len(cats) >= 5, "板块不足，请先启动后端初始化默认板块"


def rand_time(days_ago_max=30):
    """随机生成 1~N 天前的时间"""
    ago = random.randint(1, days_ago_max) * 86400 + random.randint(0, 86400)
    return datetime.utcnow() - timedelta(seconds=ago)


# ════════════════════════════════════════════════════════
# 3. 帖子 + 回复数据
# ════════════════════════════════════════════════════════
# 格式: (板块slug, 作者username, 标题, 正文, [(回复者username, 回复内容), ...])

POSTS_DATA = [
    # ──── SWT避雷 ────
    ("swt-warning", "田纳西逃兵", "田纳西水上乐园lifeguard真实避雷（附详细经历）",
     "刚从TN某水上乐园跑路回来，时薪13刀看似还行，但实际体验极差：\n\n1. 每天暴晒10-11小时，防晒霜根本不够用\n2. 说好的40h/周，实际经常50+，加班没有1.5倍\n3. 住宿是4人挤一间，房租还要175/周从工资扣\n4. 管理层态度很差，迟到5分钟直接写warning\n5. 小费？不存在的，lifeguard没有任何小费\n\n总结：这个岗位性价比极低，暴晒+低薪+差住宿，强烈建议避开。如果一定要去TN，选室内岗位。",
     [
         ("SWT老司机", "TN水上乐园我21年也去过，完全同意。暴晒是最大问题，我当时晒伤到脱皮。建议大家选东北部的岗位，至少不会热死"),
         ("马里兰吐槽王", "哈哈我MD也差不多，工时被削减到一天3小时，通勤单程1.5小时。不过至少不用暴晒😂"),
         ("小红薯Jessica", "补充一个信息：TN这家的slide attendant也一样坑，别以为换了岗位就好了。整个park的管理都有问题"),
         ("佛州阳光boy", "FL的lifeguard虽然也晒但时薪15+有小费，而且管理比TN好很多。推荐Clearwater那边的"),
         ("Ahmed_Egypt", "Thank you for sharing! I was considering TN but now I'll look at other states"),
     ]),

    ("swt-warning", "马里兰吐槽王", "Maryland Ocean City 工时严重不足避雷",
     "坐标MD Ocean City，来了快一个月了，工时问题严重到怀疑人生：\n\n- 工作日每天只排3小时班，周末才给9小时\n- 时薪16刀听着可以，但一周算下来到手才200多\n- 房租175/周，基本白干\n- 通勤单程要1.5小时（等公交+步行），通勤时间比工时还长\n- 同住的室友因为早到了一天，工时直接6小时以上，到达时间影响待遇差距巨大\n\n建议：来MD之前一定要确认工时保障！问清楚每周最低多少小时，最好写进offer letter里。",
     [
         ("SWT老司机", "OC的问题就是太多SWT学生了，供大于求所以工时被疯狂削减。建议选竞争少的地方"),
         ("OC木板路厨师", "我在OC boardwalk餐厅还行，每周能有35-40小时。关键是选对雇主，boardwalk那边的餐饮需求大"),
         ("NYC打工人", "对比一下纽约，虽然房租贵但工时有保障，我每周稳定40h+加班。综合算下来比OC划算"),
         ("小红薯Jessica", "去年有朋友也是OC，工时不够后来找了第二份工就好了。MD允许SWT学生打两份工的"),
     ]),

    ("swt-warning", "小红薯Jessica", "⚠️ 雇主查社交媒体导致被开除的真实案例",
     "分享一个血泪教训：我朋友在某度假酒店工作，因为在小红书上发了一条吐槽工作环境的帖子，被同事截图举报给manager，第二天直接被fired。\n\n注意事项：\n1. 工作期间的社交媒体发言要谨慎\n2. 不要在公开账号吐槽具体雇主名称\n3. 如果要分享避雷信息，用匿名账号\n4. 有些雇主会定期搜索自己公司名+差评\n\n被开除后签证状态会很麻烦，需要在30天内找到新sponsor或离境。大家一定小心！",
     [
         ("签证达人Lucy", "补充：被fired后要第一时间联系你的sponsor organization，他们有义务帮你协调。如果是雇主违规开除可以投诉到DOL"),
         ("佛州阳光boy", "我也差点因为发ins story被搞，后来把账号设成private了。建议大家工作期间社交媒体全部私密"),
         ("菲律宾实习生Kris", "这也太恐怖了...感谢分享，我会注意的"),
     ]),

    ("swt-warning", "Selena_MV", "Martha's Vineyard Dairy Queen 工作体验分享",
     "在MV的DQ工作了两个月，说说真实体验：\n\n优点：\n- 岛上环境很美，适合喜欢海边的人\n- 同事之间关系还不错\n- 时薪16.5还算合理\n\n缺点：\n- 岛上物价极高，一顿饭15-20刀起步\n- 住宿选择很少，房租贵\n- 交通不方便，没车基本哪都去不了\n- 旺季时工作强度很大，午餐时间忙到崩溃\n\n总体来说不算踩大坑但也不推荐，除非你特别喜欢海岛生活。",
     [
         ("波士顿海鲜哥", "MV确实贵，我朋友在那边一个暑假房租就花了快4000刀。不过赚的也多就是了"),
         ("SWT老司机", "岛上的好处是小费文化比较好，服务业岗位小费收入可观。DQ可能差一些因为是快餐"),
     ]),

    ("swt-warning", "SWT老司机", "【汇总】2024-2025 SWT 高频避雷雇主/地区名单",
     "根据这两年群里大家反馈的信息，整理了一份高频踩坑名单（仅供参考，个人经历可能不同）：\n\n🔴 高风险地区/岗位组合：\n- Tennessee 水上乐园 lifeguard（暴晒+低薪）\n- Maryland OC 部分小餐厅（工时严重不足）\n- 某些度假酒店 housekeeping（体力活+被歧视）\n\n🟡 需要注意：\n- Virginia Beach 部分岗位（工时波动大）\n- Wisconsin Dells（偏远+交通不便）\n\n🟢 相对靠谱的选择：\n- Florida 大型连锁酒店（工时稳定+小费好）\n- Massachusetts 海鲜餐厅（时薪高+小费）\n- Colorado 滑雪度假村（冬季项目，体验好）\n\n欢迎大家在评论区补充！",
     [
         ("佛州阳光boy", "FL +1！我在Clearwater的resort每周稳定40h，加上小费月收入3000+"),
         ("波士顿海鲜哥", "MA海鲜餐厅确实不错，我这边时薪18+小费，一个暑假存了8000多"),
         ("科罗拉多滑雪⛷", "CO冬季项目强推！滑雪度假村包住，员工免费滑雪，虽然工资一般但体验无敌"),
         ("马里兰吐槽王", "OC确实看运气，我的雇主就很坑但boardwalk那边有些还行。关键是提前做调查"),
         ("田纳西逃兵", "TN水上乐园我亲身经历，完全同意红色标记🔴"),
         ("加州小柠檬", "CA的酒店实习也不错哦，虽然不是SWT但J1 intern也可以考虑"),
     ]),
("find-partner", "卢卡·科拉里奇", "开普梅住房真的崩溃了！东西都没地方放",
     "大家好，我叫卢卡，在开普梅边工作边旅行的学生。\n\n来了之后对住房超级不满意——根本没有空间放我的个人物品。\n\n求租：\n- 单间或合租皆可\n- 开普梅或周边\n- 预算 $200/周\n\n如果有房源请联系我！🙏",
     [
         ("SWT老司机", "Cape May 房源少，可以看看 Wildwood，很多 SWT 学生住那边，通勤半小时左右。"),
         ("塞琳娜·M.", "我也在海岛小镇，租房是永恒的痛… 建议问雇主有没有合作宿舍。"),
     ]),

    ("visa-interview", "FunOlive4809", "J1 夏令营辅导员提前回国，多久能申请 ESTA？",
     "我之前持 J1 签证做夏令营辅导员，后来提前结束项目回了祖国。\n\n请问需要在祖国待多久才能申请 ESTA 再次入境美国？我已经预订了八月份的美国行程，但任何官方网站都查不到明确信息。",
     [
         ("签证达人Lucy", "J1 项目提前终止后，理论上需要**回国居住至少 2 个月**才能用 ESTA 入境（避免移民倾向）。但最稳妥是咨询移民律师。"),
         ("加州小柠檬", "如果 J1 带有 212(e) 两年居住要求，ESTA 也会被拒。先查你的 DS‑2019 是否有那个条款。"),
     ]),

    ("job-rec", "塞琳娜·M.", "有人在玛莎葡萄园埃德加敦的 Dairy Queen 工作过吗？",
     "你好！👋🏽 请问有人在玛莎葡萄园岛埃德加敦的 Dairy Queen 工作过吗？\n\n如果能分享一下您的经历或留言，我将不胜感激。谢谢！😊",
     [
         ("Selena_MV", "我在 MV 的 DQ 工作过两个月！时薪 16.5，但岛上物价极高，房租难找。旺季忙到崩溃，不过同事关系不错。具体可以看我发的避雷帖。"),
         ("波士顿海鲜哥", "快餐店小费一般，不如海鲜餐厅。但 MV 风景无敌，看你更看重钱还是体验。"),
     ]),

    ("visa-interview", "艾哈迈德·萨梅赫", "16 岁埃及学生，寻找价格实惠的 J1 交换项目",
     "大家好，我是一名来自埃及的 16 岁学生，一直努力争取成为美国的交换生。\n\n找到了一些项目，但费用比我预期高太多，可能超出预算。\n\n求推荐更正规且便宜的 J1 项目或机构，或者听听有经验者的建议。",
     [
         ("SWT老司机", "可以看看『Experience Abroad』（有群友提到过）。另外有些非营利组织提供奖学金，虽然名额少。"),
         ("签证达人Lucy", "16 岁必须通过指定 sponsor 申请，费用一般在 $2000‑4000。可以联系当地 AIESEC 或 YES 项目。"),
     ]),

    ("find-partner", "清洁 Qwx", "弗吉尼亚威廉斯堡找住处 6月15日入住",
     "您好！我是一名持 J‑1 签证的学生，将于 6 月 15 日抵达弗吉尼亚州威廉斯堡。\n\n寻找单间出租或合租（随时可入住）。如有房源请私信联系！非常感谢！",
     [
         ("立陶宛双子花", "威廉斯堡比较小，可以看看 Facebook Marketplace 或联系 William & Mary 大学的租房群。"),
         ("NYC打工人", "提前问雇主能否提供推荐房东，很多 SWT 雇主有合作房源。"),
     ]),

    ("swt-warning", "匿名互动者_214b", "⚠️ 面签时因社交媒体私密被 214b 拒签，人麻了",
     "我今天参加 J1 签证面试，结果面试官查看了我的社交媒体账号（明明设了私密），当场以 214b 条款拒签。\n\n有人遇到过类似情况吗？接下来该怎么办？真的受创伤了……",
     [
         ("签证达人Lucy", "美国早就规定 J/F/M 签证必须把社交账号设为**公开**。你可以再次申请，面试前清理内容并公开所有账号。"),
         ("西里库尔·普伊·布朗", "这是大使馆官方要求：你的社交媒体账号必须公开。很多学生都因为这个被拒。"),
         ("路易斯·伯德", "版主提醒：不要抱有侥幸心理，面签前至少把 Instagram、Twitter、FB 全公开一周。"),
     ]),

    ("visa-interview", "匿名互动者_DS2019", "DS‑2019 项目开始日期变了，DS‑160 已提交怎么办？",
     "大家好，我用原 DS‑2019 提交了 DS‑160（开始日期 2026 年 7 月），但最近收到新的 DS‑2019，开始日期改为 8 月。\n\n面签预约已经安排好了。请问该怎么办？",
     [
         ("签证达人Lucy", "重新填写 DS‑160（用新日期），然后在预约系统里更新确认号。面签时带上新旧两份 DS‑2019 并解释原因。不会影响结果。"),
         ("匿名互动者699", "如果来不及更新，也可以把两份都带到现场。但推荐更新。"),
     ]),

    ("visa-interview", "OrangePelican8815", "有菲律宾的 J1 培训生最近获批的吗？",
     "大家好，请问有人申请 J1 培训生项目获批了吗？（来自菲律宾）",
     [
         ("Chulavista3937", "我朋友的申请通过了。建议：不要显得太渴望或太需要这份实习，表现出文化交流的热情即可。"),
         ("菲律宾实习生Kris", "我也菲律宾人，去年获批。关键是证明你项目结束后一定会回国。"),
     ]),

    ("visa-interview", "MemorableOtter6875", "毕业三年工作经验，申请 J1 培训生会卡吗？",
     "您好！我 2023 年毕业，有 3 年工作经验。如果申请 J1 培训生项目会有问题吗（因为毕业已经好几年了）😅 谢谢！",
     [
         ("AuthenticChipmunk6109", "只要你能提供工作证明，之前的工作经验就可以符合 J‑1 实习项目的申请条件，毕业年限不是绝对障碍。"),
         ("泡泡浴9", "我 2014 年毕业，2021 年通过了 J1 签证。只要 J1 培训方向与你的专业相关，就没问题。我也是菲律宾人。"),
     ]),

    ("visa-interview", "ExcitingTangerine1160", "J1 实习结束后 8 个月，持 B 签再入境安全吗？",
     "PTPA。我的 J1 实习结束后回到菲律宾近 8 个月，现在想持 B2 旅游签再去美国度假。入境会有问题吗？",
     [
         ("卡米拉·马德里", "版主：很安全，你会没事的。☺️ 只要说明是纯旅游，准备好回程机票。"),
         ("迈克·瓦特", "版主：很安全，只需如实说明此行目的。确保你手上有返程机票信息。"),
     ]),

    ("swt-warning", "匿名互动者_雇主威胁", "雇主威胁要把我遣返回国！真实经历分享",
     "分享这件事并非想伤害谁，而是提醒大家。\n\n有一家酒店/度假村让我的生活像坐过山车——他们的某些部门不满意我的表现，威胁要把我遣返回国。我差点丢掉工作，也失去了希望。",
     [
         ("路易斯·伯德", "请立即联系你的 sponsor！任何威胁遣返的雇主都不能绕过 sponsor 单独行动。"),
         ("匿名互动者605", "请留下酒店和度假村的名称，以便提醒未来的申请人。"),
         ("匿名互动者995", "仍然有人想和你作对，因为你勇敢地站出来反对雇主滥用职权或违反劳动条款。支持你！"),
     ]),

    ("visa-interview", "ThoughtfulElk6161", "埃及学生：面签被扣护照，要求提供社交账号",
     "大家好，我来自埃及。5 月 24 日在美国大使馆进行 SWT 面签。\n\n官员扣留了我的护照，并要求提供社交媒体账号信息。从那时起 CEAC 状态一直显示『拒绝』。",
     [
         ("CopperRaccoon1455", "再等一周，有时是行政审查（AP），状态会变成『refused』但实际只是 pending。"),
         ("玛丽亚·奥蒂诺·卡德特", "他们正在审查你的社交媒体！！！ 把账号设为公开，耐心等待。"),
     ]),

    ("swt-warning", "DelightfulPomelo7897", "被解雇后用了 30 天旅行期，回国后再次签证顺利通过",
     "我在雇佣期结束前 10 天被解雇，sponsor 允许我立即开始 30 天旅行。我按时离境并通知了 sponsor。\n\n后来再次申请 J1 顺利获批，系统里显示我提前离境但没留下负面记录。",
     [
         ("匿名互动者869", "去年我也遇到类似情况，但今年签证顺利获批。系统显示提前离境，不过解释清楚就好。"),
         ("BeautifulTurkey8137", "你好！请问你被解雇的原因是什么？雇主有没有违反合同？"),
     ]),

    ("visa-interview", "EmpatheticHedgehog5994", "212(e) 豁免申请被祖国（菲律宾）拒绝不反对函",
     "我是 J1 签证持有者，项目结束后因 212(e) 条款无法入境。我结婚一年了，一直在申请豁免，美国方面发函请菲律宾出具不反对函，但菲律宾拒绝了，不允许我申请豁免。\n\n怎么办？我在美国合法结婚了。",
     [
         ("MagentaStrawberry3708", "你必须返回菲律宾，申请正确的签证类型（比如配偶签证 CR‑1/IR‑1）。J1 豁免在无政府支持下基本无解。"),
         ("卡米拉·马德里", "版主：联系美国移民律师，他们可能知道某些特殊通道。"),
     ]),

    ("chitchat", "阿米娜·扎克西利克", "纽波特哪里可以免费借自行车？",
     "下午好！我们是持 J‑1 签证的留学生，第一次来纽波特，想找哪里可以免费借自行车。如果能联系我们，将不胜感激！🙏🏼",
     [
         ("SWT老司机", "很多城市有社区自行车共享计划（bike share），但免费的不多。可以问问当地青年旅社或图书馆。"),
         ("塞琳娜·M.", "纽波特有『Newport Bike Share』，首 30 分钟免费。另外问问你的雇主有没有员工旧车借用。"),
     ]),

    ("job-rec", "马特亚·卡蒂奇", "波士顿地区找工作（J1 学生，不需要住宿）",
     "你好，我和我弟弟正在波士顿地区找工作，我们是 J1 签证学生，会待到 9 月 25 日。我们不需要住宿，只要工作就行。谢谢。",
     [
         ("波士顿海鲜哥", "我工作的海鲜餐厅还在招厨房帮工，时薪 18 + 小费。直接来 Quincy 店面试。"),
         ("NYC打工人", "波士顿 Downtown 很多快餐店夏天缺人，可以 walk‑in 问。准备一份简单的简历。"),
     ]),

    ("find-partner", "Yuxin Xiao", "中国学生找房｜达拉斯 Arlington ｜6月底～9月初",
     "Hi everyone! I’m a J‑1 student from China and I’ll be working in Arlington this summer at Aloft Dallas Arlington South.\n\nI’m looking for a furnished room/apartment OR roommates to share a place together from late June to early September (around June 29 – Sept 10).",
     [
         ("达拉斯找室友", "我在达拉斯设计区，600‑700/月。Arlington 更便宜，可以看看 UTA 大学附近的转租群。"),
         ("加州小柠檬", "建议加入『Dallas J1 SWT 2026』Facebook 群组，里面常有中国人转租。"),
     ]),

    ("visa-interview", "匿名互动者_面签晚", "酒店 6 月 20 日开始工作，但面签预约在 8 月！",
     "我的酒店 start date 是 6 月 20 日，但签证预约网站出问题，最早面签是 8 月。\n\n有人经历过吗？sponsor 和雇主能否把开始日期后移？",
     [
         ("YellowFox3441", "你可以申请紧急预约，在系统里提交一份简短说明为什么需要更早的面签（例如项目开始日期临近）。"),
         ("Becky-Rebecca Pazik", "联系 sponsor 更新 host company，看他们是否允许晚到。印尼系统曾经也有类似延迟，最终 sponsor 协调成功。"),
     ]),

    # ──── 美国找搭子 ────
    ("find-partner", "立陶宛双子花", "两个立陶宛女生找CT Mystic暑期合租室友 🏠",
     "大家好！我们是两个来自立陶宛的女学生，即将前往康涅狄格州Mystic工作。\n\n寻找：暑期合租的房间（6月中-9月初）\n预算：每人500-700/月\n要求：安全、干净、离工作地点通勤30分钟以内\n\n如果有人有空房出租或者知道当地的租房信息，请留言或私信！我们很好相处的～ 😊",
     [
         ("SWT老司机", "Mystic那边可以看看Facebook marketplace和Craigslist，当地人经常在上面发暑期短租"),
         ("签证达人Lucy", "建议联系你们的sponsor，很多sponsor有合作的housing provider。另外Mystic附近的Groton也可以看看，房租会便宜一些"),
         ("NYC打工人", "CT的房租比纽约友好多了，700/月应该能找到不错的。注意签合同时看清楚lease term"),
     ]),

    ("find-partner", "达拉斯找室友", "Dallas Design District 找室友合租一室一厅！",
     "刚到达拉斯，找一个靠谱室友一起签lease！\n\n公寓信息：\n📍 Avant Market Center, 2222 N Stemmons Fwy\n🏠 1B1B，我住客厅\n💰 总租金约1400/月，均摊700/人\n📅 6月15-17日可入住\n\n公寓配套：健身房、泳池、按摩浴缸、BBQ区、办公空间\n交通：靠近DART轻轨站\n\n要求：爱干净、不抽烟、作息正常\n有兴趣的请留言！",
     [
         ("加州小柠檬", "达拉斯700/月这个价格很良心了！可惜我在CA不然真想来"),
         ("SWT老司机", "提醒一下，合租的话最好两个人都在lease上签名，保护双方权益。也可以找公寓管理处问有没有roommate matching服务"),
     ]),

    ("find-partner", "Luka_Croatia", "Cape May NJ - Looking for housing 🏠",
     "Hi everyone! I'm Luka, a student from Croatia working in Cape May, NJ this summer.\n\nI just arrived and I'm really unhappy with my current housing situation - there's literally no space for my things.\n\nLooking for:\n- A room for rent (private or shared is fine)\n- Cape May area or nearby\n- Budget: up to $200/week\n\nIf you're offering housing or know someone who is, please reach out! Thank you 🙏",
     [
         ("SWT老司机", "Cape May比较小，建议也看看Wildwood和North Wildwood，那边SWT学生比较多，房源也多一些"),
         ("签证达人Lucy", "200/week in Cape May might be tight but doable if you share. Check the local Facebook groups for Cape May summer housing"),
         ("Selena_MV", "I know the struggle! Island/coastal towns are always tough for housing. Try asking your coworkers if anyone has a spare room"),
     ]),

    ("find-partner", "安克雷奇背包客", "Alaska Anchorage 找搭子！一起探索最后的边疆 🏔️",
     "有没有今年夏天在阿拉斯加的小伙伴？\n\n我在Anchorage一家hostel工作，周末想找人一起：\n- 徒步（Flattop Mountain、Byron Glacier这些经典路线）\n- 钓鲑鱼（7月是最佳季节！）\n- 自驾去Seward看冰川\n\n一个人玩太孤单了，有兴趣的留言约起来！\n\n另外我们hostel现在还有床位，J1学生优惠价，需要住宿的也可以问我。",
     [
         ("科罗拉多滑雪⛷", "Alaska太酷了！我一直想去但没机会。听说夏天白天超级长？"),
         ("安克雷奇背包客", "对！现在差不多22小时天亮，凌晨2点天就亮了，完全不用担心天黑。体验非常独特"),
         ("小红薯Jessica", "收藏了！明年考虑去Alaska，感觉体验完全不一样"),
     ]),

    # ──── 面签讨论 ────
    ("visa-interview", "签证达人Lucy", "【面签攻略】J1签证面试常见问题及回答思路（2025更新版）",
     "帮很多朋友准备过面签，总结一份最新攻略：\n\n📌 必问问题：\n1. Why do you want to go to the US? → 强调文化交流+专业提升，别说赚钱\n2. What will you do after the program? → 一定要说回国，有具体计划更好\n3. Where will you work? → 说清公司名、地点、岗位\n4. How will you support yourself? → 说明时薪和预期收入\n5. Do you have family in the US? → 如实回答，有的话解释清楚关系\n\n⚠️ 注意事项：\n- 社交媒体设为公开模式（部分使馆会查）\n- 穿着得体但不需要太正式\n- 自信、简洁、直视面试官\n- 带齐所有材料原件\n- 不要背答案，自然交流\n\n有具体问题可以在评论区问我！",
     [
         ("Ahmed_Egypt", "非常有用！请问面试官查社交媒体的情况多吗？我听说有人因为这个被拒了"),
         ("签证达人Lucy", "确实有。今年开始美国大使馆对J/F/M签证要求社交媒体设为公开。不是所有人都会被查，但建议提前清理一下不当内容"),
         ("菲律宾实习生Kris", "感谢Lucy姐！请问DS-2019上的日期如果变了，DS-160需要重新填吗？"),
         ("签证达人Lucy", "需要的！如果DS-2019更新了，建议重新提交DS-160。两份文件都带到面试现场，向面试官解释日期变更即可"),
         ("立陶宛双子花", "我们下周面签，这个帖子太及时了！请问立陶宛出境时移民官会问什么吗？"),
         ("签证达人Lucy", "欧盟国家出境一般不会问太多，出示护照和签证就行。主要是美国入境时会问详细问题"),
     ]),

    ("visa-interview", "Ahmed_Egypt", "214b拒签经历分享 - 因社交媒体被查",
     "分享我的面签经历给大家参考，希望后面的人不要犯同样的错误：\n\n背景：埃及🇪🇬，SWT项目，5月24日在美国大使馆面签\n\n过程：\n1. 面试官问了基本问题，回答都没问题\n2. 突然要求查看我的社交媒体账号\n3. 我的Instagram设置为私密模式\n4. 面试官直接以214(b)拒签\n\n后续：\n- CEAC状态一直显示\"refused\"\n- 护照被扣留了将近两周\n- 据说是在审查我的社交媒体内容\n\n教训：一定一定要把社交媒体设为公开！这是使馆明确要求的。另外清理一下可能敏感的内容。",
     [
         ("签证达人Lucy", "别灰心！214b拒签不是永久的，可以再次申请。建议下次面签前把所有社媒设为公开，准备好解释上次被拒的原因"),
         ("SWT老司机", "补充一个信息：有人护照被扣后等了一周最终还是给了签证。如果CEAC状态变成issued就是好消息，继续等"),
         ("菲律宾实习生Kris", "感谢分享！我马上也要面签了，立刻去把所有账号设成public"),
     ]),

    ("visa-interview", "菲律宾实习生Kris", "菲律宾出发到美国入境全流程分享 🇵🇭→🇺🇸",
     "刚从Manila飞到LA，分享一下全流程：\n\n🇵🇭 菲律宾出境：\n- 移民官问了一个问题：你是J1签证吗？\n- 出示护照+CFO贴纸+J1签证页\n- 盖章放行，全程2分钟\n\n🇺🇸 美国入境（LAX）：\n- 排队大约40分钟\n- 问了：来美国做什么？在哪工作？待多久？\n- 出示DS-2019、offer letter、return ticket\n- 录指纹、拍照\n- 盖章入境！\n\n建议准备的材料（打印纸质版）：\n✅ DS-2019原件\n✅ Offer letter\n✅ 住宿证明\n✅ 回程机票行程单\n✅ 足够的启动资金证明\n\n整体比想象中顺利，不用太紧张！",
     [
         ("Ahmed_Egypt", "谢谢分享！回程机票一定要买好才去面签吗？还是可以先买单程的？"),
         ("菲律宾实习生Kris", "建议买好回程票或者至少买一张可退改的。面试官会问你什么时候回国，有回程票证明移民倾向低"),
         ("签证达人Lucy", "很详细的分享！补充一点：入境时如果被问到带了多少现金，如实回答就好。超过10000美元需要申报"),
     ]),

    # ──── 岗位推荐 ────
    ("job-rec", "波士顿海鲜哥", "【推荐】波士顿海鲜餐厅招厨房帮工 时薪18+小费",
     "我工作的餐厅还在招人！详细信息：\n\n📍 位置：波士顿 Massachusetts\n🦞 岗位：厨房帮工（prep cook）\n💰 时薪：$18/h + 小费分成（平均每天额外30-50刀）\n⏰ 工时：每周35-45小时，旺季可能更多\n🏠 住宿：不提供，但可以帮忙找附近的合租\n\n要求：\n- 不需要烹饪经验，会教\n- 能吃苦，旺季午餐和晚餐时段非常忙\n- 基本英语沟通能力\n\n优点：\n- 老板人很好，从不拖欠工资\n- 免费员工餐（龙虾和蛤蜊吃到饱😋）\n- 周围很多SWT学生，不孤单\n\n感兴趣的留言或私信我！",
     [
         ("NYC打工人", "时薪18还有小费分成！这个待遇在东北部算很好了。请问需要有SSN才能开始工作吗？"),
         ("波士顿海鲜哥", "到了之后办SSN就行，一般1-2周能拿到。很多雇主允许你先开始工作等SSN下来"),
         ("SWT老司机", "波士顿的生活成本不低，但这个时薪+小费应该够了。房租估计要800-1000/月合租"),
         ("马里兰吐槽王", "羡慕了...我在OC时薪16还没小费。早知道去波士顿了"),
         ("加州小柠檬", "免费龙虾！！！这个福利太香了吧"),
     ]),

    ("job-rec", "OC木板路厨师", "Ocean City MD Boardwalk 餐厅招聘厨师和收银员",
     "Polock Johnny's 餐厅（位于Boardwalk塔尔博特街和多切斯特街之间）正在招聘！\n\n招聘岗位：\n🍳 厨师 - $15/h\n💳 收银员 - $14/h + tips\n\n工作时间：每周5-6天，每天6-10小时\n提供：灵活排班，适合需要打两份工的同学\n\n虽然OC的工时问题被很多人吐槽，但boardwalk上的餐厅生意一直很好，工时有保障！旺季（7-8月）基本每天都能排满班。\n\n有兴趣直接来店里面试，带上你的文件就行。",
     [
         ("马里兰吐槽王", "Boardwalk上的餐厅确实比其他地方好，我后来换到一家boardwalk的也好多了。关键是游客多"),
         ("SWT老司机", "OC boardwalk的餐饮是相对靠谱的选择。不过提醒一下，9月Labor Day之后生意会断崖式下降"),
     ]),

    ("job-rec", "科罗拉多滑雪⛷", "【强推】Colorado滑雪度假村冬季SWT 包住+免费滑雪",
     "写一个冬季SWT的推荐帖，给准备冬天来的同学参考：\n\n📍 科罗拉多州 Vail/Breckenridge 区域\n🎿 岗位：度假村餐饮/前台/滑雪器材管理\n💰 时薪：$16-18\n🏠 住宿：员工宿舍 约$400-600/月（远低于市场价）\n🎫 福利：员工赛季滑雪通行证（价值$800+）！\n\n为什么推荐冬季：\n1. 竞争比夏天小很多\n2. 度假村管理普遍比小餐厅正规\n3. 滑雪体验是在其他地方得不到的\n4. 员工社区文化很好，各国人一起\n5. CO自然环境绝美\n\n缺点：\n- 冬天很冷（but that's the point 😄）\n- 位置偏远，需要自己做饭\n- 海拔高需要适应期\n\n想了解更多可以问我！",
     [
         ("安克雷奇背包客", "冬季项目太酷了！请问需要会滑雪吗？完全零基础可以去吗？"),
         ("科罗拉多滑雪⛷", "完全不需要！很多同事来之前从没见过雪😄 度假村有免费员工滑雪课程。到了冬天结束你就是pro了"),
         ("小红薯Jessica", "免费滑雪通行证太香了！请问冬季SWT是几月到几月？"),
         ("科罗拉多滑雪⛷", "一般11月中-4月初。有些度假村可以到4月中旬。建议提前半年申请因为名额有限"),
         ("佛州阳光boy", "作为一个在FL晒了两个夏天的人，冬季CO真的很诱人...认真考虑中"),
     ]),

    # ──── 闲聊灌水 ────
    ("chitchat", "佛州阳光boy", "大家SWT一个暑假都存了多少钱？来报个数 💰",
     "我先来：\n\n地点：FL Clearwater\n岗位：Lifeguard + 兼职餐厅\n时薪：$15 + tips\n工时：平均45h/周\n月收入：约$3200（含小费）\n暑假总收入：约$9000\n支出：房租$2400 + 生活费$1500 + 旅行$1000\n净存：约$4100\n\n感觉还行但也没多少...大家呢？",
     [
         ("波士顿海鲜哥", "我在波士顿：时薪18+小费，暑假总收入约11000，扣掉开销存了大概5500。海鲜餐厅旺季真的很赚"),
         ("马里兰吐槽王", "我就不报了...OC工时太少，勉强回本。算上签证费机票费可能还亏了😭"),
         ("NYC打工人", "纽约：总收入约10000，但房租太贵了3个月花了4500...最后存了2800"),
         ("田纳西逃兵", "TN：跑路前只待了6周，到手3000出头，扣掉住宿交通剩1500。亏麻了"),
         ("科罗拉多滑雪⛷", "冬季CO：4个月存了6000左右。包住真的省很多！"),
         ("加州小柠檬", "CA实习工资其实不高但学到了很多，存了3000。不过实习的价值不完全在钱上"),
         ("Selena_MV", "MV存了约4000，岛上物价太高了不然能更多。但风景无价💙"),
     ]),

    ("chitchat", "加州小柠檬", "J1结束后还想回美国的朋友看过来 - 签证选择整理",
     "J1结束后很多人想再回美国，整理几个合法途径：\n\n1. J1 SWT 重复参加（需要回国2个月以上）\n2. J1 Intern/Trainee（毕业后可以，最长18个月）\n3. B1/B2旅游签（纯旅游不能工作）\n4. F1学生签（如果计划在美国读书）\n5. H2B工作签（需要雇主sponsor）\n6. ESTA免签（部分国家公民可以）\n\n⚠️ 注意212(e)条款：有些J1签证有两年回国服务要求(two-year home residence requirement)，需要先满足或申请豁免才能转其他签证。\n\n具体情况具体分析，建议咨询律师。以上仅供参考！",
     [
         ("菲律宾实习生Kris", "请问J1 intern结束后想旅游30天，需要额外申请什么吗？"),
         ("加州小柠檬", "J1签证有30天grace period（宽限期），这段时间可以合法留在美国旅游但不能工作。不需要额外申请"),
         ("签证达人Lucy", "很好的整理！补充一点：ESTA（旅游免签）适用于大部分欧洲国家和日韩等。菲律宾和中国目前不能用ESTA，需要申请B签"),
         ("Ahmed_Egypt", "请问如果J1被拒后多久可以再次申请？"),
         ("签证达人Lucy", "没有固定等待期。你可以随时重新申请，但建议准备更充分的材料并解释上次被拒的原因"),
     ]),

    ("chitchat", "NYC打工人", "在美国遇到的文化冲击 Top 5 😂",
     "来美国快两个月了，分享一些让我震惊的文化差异：\n\n1. 小费文化 - 吃饭要给15-20%小费，不给会被白眼。一开始真的不习惯\n2. 冰水 everywhere - 不管什么季节餐厅都给冰水，想喝热水要特意要\n3. 路上几乎没有行人 - 除了NYC，其他地方不开车等于没有腿\n4. 人真的很friendly - 陌生人也会跟你打招呼聊天，一开始以为是骗子😂\n5. 食物份量巨大 - 一份够两个人吃，但蔬菜是真的少\n\n你们有什么文化冲击经历？来评论区分享！",
     [
         ("Luka_Croatia", "For me it was the tipping! In Croatia we don't really tip. First time I left no tip the waiter looked so confused 😅"),
         ("Ahmed_Egypt", "Ice in everything!! Even in winter!! WHY 😂"),
         ("马里兰吐槽王", "最大的冲击是工作态度。美国人真的很看重准时和效率，迟到5分钟就是大事"),
         ("安克雷奇背包客", "在Alaska的冲击是不一样的——夏天太阳不落山！凌晨2点天还亮着完全睡不着"),
         ("佛州阳光boy", "FL的冲击是龙卷风警报。第一次手机突然响那个警报声差点吓哭"),
         ("小红薯Jessica", "超市的选择太多了！买个酸奶要在50种里面选，选择恐惧症患者崩溃"),
     ]),

    ("chitchat", "小红薯Jessica", "SWT结束倒计时 - 必做的10件事 ✈️",
     "暑假快结束了，整理一份离开前必做清单：\n\n1. ✅ 确认回程机票\n2. ✅ 最后一张工资支票别忘了拿\n3. ✅ W-2税表确认地址（明年报税用）\n4. ✅ 退掉租房合约、拿回押金\n5. ✅ 关闭/转出美国银行账户\n6. ✅ 手机号处理（停机or转prepaid）\n7. ✅ 给好同事留联系方式\n8. ✅ 最后的旅行！grace period好好利用\n9. ✅ 买纪念品和代购清单\n10. ✅ 通知sponsor你的离境日期\n\n有什么遗漏的欢迎补充！",
     [
         ("签证达人Lucy", "补充一个很重要的：离境后记得让sponsor确认你的SEVIS record已经完成。这关系到你未来再次申请美国签证"),
         ("SWT老司机", "W-2税表地址一定要用你回国后能收到信的地址！或者问雇主能不能email电子版"),
         ("波士顿海鲜哥", "银行账户可以不关，有些银行允许保留。下次来美国还能用，省得重新开户"),
         ("佛州阳光boy", "grace period一定要好好利用！可以去其他城市玩。我上次去了Chicago和LA"),
     ]),

    # ──── 更多帖子 ────
    ("swt-warning", "NYC打工人", "纽约餐饮行业真实体验 - 好坏都说",
     "在NYC中餐厅打了两个月工，说说真实感受：\n\n好的方面：\n- 工时非常充足，每周45-50h没问题\n- 现金小费可观，旺季一天能有80-100刀小费\n- 锻炼英语的好机会\n- NYC本身就是旅游胜地\n\n不好的方面：\n- 房租真的贵！跟人合租一个客厅月租还要900\n- 工作强度大，午餐和晚餐高峰期忙到飞起\n- 中餐厅的kitchen比较热比较油\n- 通勤时间长（地铁经常延误）\n\n总体来说：如果能吃苦并且想多赚钱，NYC是不错的选择。但如果追求工作生活平衡就别来了😂",
     [
         ("波士顿海鲜哥", "NYC赚得多花得也多啊。不过确实是个很好的经历，值得体验一次"),
         ("马里兰吐槽王", "工时45-50h...我看哭了。OC一周给我排了20h不到"),
     ]),

    ("find-partner", "波士顿海鲜哥", "Boston 暑期合租 - 有两个床位空出来",
     "我们在Boston Quincy合租的公寓有两个室友月底走了，空出来两个bed：\n\n📍 Quincy（红线地铁直达downtown，20分钟）\n💰 650/月/人（含水电网）\n🛏 4B2B公寓，男女均可\n📅 7月1日起可入住\n\n现在住的人：我（中国🇨🇳）+ 一个韩国妹子 + 一个土耳其小哥\n都是J1学生，很好相处\n\n有兴趣请留言！",
     [
         ("NYC打工人", "650含水电网在波士顿太便宜了吧！Quincy红线也方便。可惜我在纽约走不了"),
         ("小红薯Jessica", "帮我朋友问一下，她7月中旬到Boston开始工作，可以中途入住吗？"),
         ("波士顿海鲜哥", "可以的！月中入住的话那个月按天计费就好，很灵活"),
     ]),

    ("visa-interview", "小红薯Jessica", "DS-2019日期变更怎么办？完整处理流程",
     "很多同学遇到这个问题：提交DS-160后DS-2019的日期改了。分享处理办法：\n\n情况：\n- 原DS-2019开始日期7月 → 更新为8月\n- DS-160已提交且预约了面签\n\n处理步骤：\n1. 收到新DS-2019后检查所有信息\n2. 重新填写DS-160（用新的日期信息）\n3. 新的DS-160确认号替换旧的（在预约系统里更新）\n4. 面签时两份DS-2019都带上（旧的+新的）\n5. 向面试官说明日期变更的原因\n\n⚠️ 不需要取消重新预约！只需要在预约系统里更新DS-160确认号就行。\n\n这个很常见不用紧张，面试官不会因为日期变更而拒签。",
     [
         ("签证达人Lucy", "很好的整理！补充一点：如果来不及重新填DS-160，也可以把两份文件都带到面试现场口头解释。但建议还是更新一下更稳"),
         ("菲律宾实习生Kris", "刚好遇到这个问题！谢谢分享，这个帖子救了我"),
         ("Ahmed_Egypt", "Is it the same process for J1 intern/trainee or just SWT?"),
         ("小红薯Jessica", "All J1 categories are the same process! DS-2019 and DS-160 requirements apply equally"),
     ]),

    ("job-rec", "佛州阳光boy", "Florida Clearwater Beach 度假村 推荐 ⭐⭐⭐⭐⭐",
     "来给我工作的地方打个广告（真心推荐不是托）：\n\n📍 Clearwater Beach, FL\n🏨 大型连锁度假酒店\n💰 Lifeguard $15/h | Front desk $14/h | F&B $13/h + tips\n⏰ 保证每周40h，旺季有overtime\n🏠 提供员工住宿（$120/week，含shuttle）\n\n为什么推荐：\n✅ 工时稳定有保障\n✅ 管理正规，不会乱来\n✅ 同事很多SWT学生，不孤单\n✅ Clearwater Beach连续多年评为美国最佳海滩\n✅ 离Tampa很近，周末可以去城里玩\n✅ 免费使用酒店泳池和健身房\n\n感兴趣的可以留言问我细节！明年的名额现在就可以开始申请了。",
     [
         ("田纳西逃兵", "看到这个帖子我真的后悔了...当初怎么没选FL"),
         ("马里兰吐槽王", "120/week住宿还含shuttle！？我们OC 175/week还要自己通勤1.5小时"),
         ("SWT老司机", "FL大型连锁确实是最稳的选择之一。小的独立餐厅风险比较大。强烈推荐这类正规度假村"),
         ("科罗拉多滑雪⛷", "夏天FL冬天CO，完美组合😎"),
         ("小红薯Jessica", "已收藏！明年推荐给我学弟学妹们"),
     ]),

    ("chitchat", "SWT老司机", "给第一次参加SWT的新人的10条建议",
     "作为一个参加过3次SWT的老人，给新人一些建议：\n\n1. 出发前就办好美国银行开户预约（Chase/BofA网上可以预约）\n2. 到了第一天就去申请SSN，越早越好\n3. 下载Venmo和Zelle（美国主流转账app）\n4. 买一张Mint Mobile电话卡（便宜好用）\n5. 工资单每张都保留好，报税用\n6. 跟sponsor保持联系，有问题第一时间找他们\n7. 别只跟同胞扎堆，多交外国朋友练英语\n8. 合理安排旅行，grace period别浪费了\n9. 学会做饭！外面吃太贵了\n10. 享受这个独特的经历，不要只盯着赚钱\n\n有什么想问的留言区见！",
     [
         ("立陶宛双子花", "第7条太对了！我们打算多交不同国家的朋友。请问Mint Mobile在哪里买？"),
         ("SWT老司机", "Mint Mobile官网可以买也可以Amazon。建议出发前就买好在飞机上换卡，落地就有网"),
         ("菲律宾实习生Kris", "请问报税是必须的吗？听说收入低于一定金额可以不报？"),
         ("签证达人Lucy", "J1签证持有者无论收入多少都建议报税！不报税可能影响未来签证申请。报税可以用Sprintax，专门针对non-resident的"),
         ("Ahmed_Egypt", "Great tips! Especially #6 - always contact your sponsor first for any issues"),
         ("NYC打工人", "第9条我是亲身体会...第一周天天吃外面花了200多刀，后来学会做饭省了一半"),
     ]),

]


# ════════════════════════════════════════════════════════
# 4. 写入数据库
# ════════════════════════════════════════════════════════
created_posts = 0
created_comments = 0
created_likes = 0

for cat_slug, author_name, title, body, replies in POSTS_DATA:
    # 去重检查
    cat = cats[cat_slug]
    author = user_map[author_name]
    exists = db.query(Post).filter(Post.title == title, Post.author_id == author.id).first()
    if exists:
        continue

    post_time = rand_time(30)
    post = Post(
        id=gen_id(), category_id=cat.id, author_id=author.id,
        title=title, body=body,
        is_pinned=False, is_locked=False,
        view_count=random.randint(30, 500),
        created_at=post_time, updated_at=post_time,
    )
    db.add(post)
    db.flush()
    created_posts += 1

    # 添加回复（时间递增）
    reply_base = post_time + timedelta(minutes=random.randint(10, 120))
    for i, (replier_name, reply_body) in enumerate ( replies ) :

        if replier_name not in user_map :
            u = User (
                id=gen_id (),
                username=replier_name,
                email=f"seed_{abs ( hash ( replier_name ) )}@seed.local",
                password_hash=pw_hash,
                role="user",
                is_vip=False,
                avatar="👤",
                bio="自动生成种子用户",
                is_active=True,
            )
            db.add ( u )
            db.flush ()
            user_map[replier_name] = u

        replier = user_map[replier_name]
        reply_time = reply_base + timedelta(minutes=random.randint(5, 180) * (i + 1))
        comment = Comment(
            id=gen_id(), post_id=post.id, author_id=replier.id,
            body=reply_body, created_at=reply_time,
        )
        db.add(comment)
        created_comments += 1

    # 随机点赞（帖子的回复者 + 额外随机用户）
    likers = set()
    for replier_name, _ in replies:
        if random.random() < 0.7:
            likers.add(replier_name)
    # 额外随机用户
    extra = random.sample(list(user_map.keys()), min(5, len(user_map)))
    for name in extra:
        if random.random() < 0.4:
            likers.add(name)
    likers.discard(author_name)  # 作者不给自己点赞

    for liker_name in likers:
        liker = user_map[liker_name]
        existing_like = db.query(PostLike).filter(
            PostLike.post_id == post.id, PostLike.user_id == liker.id
        ).first()
        if not existing_like:
            db.add(PostLike(id=gen_id(), post_id=post.id, user_id=liker.id))
            created_likes += 1

db.commit()
db.close()

print(f"""
{'='*50}
✅ 论坛种子数据导入完成！
{'='*50}
  新增用户:   {len(SEED_USERS)} 个
  新增帖子:   {created_posts} 篇
  新增回复:   {created_comments} 条
  新增点赞:   {created_likes} 个

  所有种子用户密码: seed123
  板块分布: SWT避雷 / 美国找搭子 / 面签讨论 / 岗位推荐 / 闲聊灌水

  启动后端即可在论坛页面看到数据。
{'='*50}
""")