"""认证与用户路由。"""

from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, EmailStr
from sqlalchemy import func
from sqlalchemy.orm import Session

from auth import create_token, get_current_user, hash_password, require_admin, touch_user_activity, verify_password
from database import Comment, InviteCode, Post, User, gen_id, get_db
from verification import issue_code, verify_code

router = APIRouter(prefix="/api/auth", tags=["auth"])


class SendCodeReq(BaseModel):
    email: EmailStr
    purpose: str = "register"


class RegisterReq(BaseModel):
    username: str
    password: str
    email: EmailStr
    code: str
    invite_code: Optional[str] = None


class LoginReq(BaseModel):
    username: str
    password: str


class ForgotPasswordReq(BaseModel):
    email: EmailStr
    code: str
    new_password: str


class UpdateProfileReq(BaseModel):
    avatar: Optional[str] = None
    bio: Optional[str] = None
    email: Optional[EmailStr] = None


class ChangePasswordReq(BaseModel):
    old_password: str
    new_password: str


@router.post("/send-code")
def send_code(req: SendCodeReq, db: Session = Depends(get_db)):
    email = req.email.lower().strip()
    purpose = req.purpose
    if purpose not in ("register", "reset_password"):
        raise HTTPException(400, "验证码用途无效")
    if purpose == "register" and db.query(User).filter(User.email == email).first():
        raise HTTPException(400, "该邮箱已被注册")
    if purpose == "reset_password" and not db.query(User).filter(User.email == email).first():
        raise HTTPException(404, "该邮箱未注册")
    try:
        return issue_code(db, email, purpose)
    except ValueError as e:
        raise HTTPException(429, str(e))


@router.post("/register")
def register(req: RegisterReq, db: Session = Depends(get_db)):
    username = req.username.strip()
    email = req.email.lower().strip()
    if len(username) < 2 or len(username) > 20:
        raise HTTPException(400, "用户名长度需 2-20 个字符")
    if len(req.password) < 6:
        raise HTTPException(400, "密码至少 6 位")
    if db.query(User).filter(User.username == username).first():
        raise HTTPException(400, "用户名已被占用")
    if db.query(User).filter(User.email == email).first():
        raise HTTPException(400, "邮箱已被注册")
    if not verify_code(db, email, req.code.strip(), "register"):
        raise HTTPException(400, "验证码错误或已过期")

    auto_vip = False
    if req.invite_code and req.invite_code.strip():
        invite_code = req.invite_code.strip().upper()
        invite = db.query(InviteCode).filter(InviteCode.code == invite_code, InviteCode.is_active == True).first()
        if not invite:
            raise HTTPException(400, "邀请码不存在")
        if invite.used_count >= invite.max_uses:
            raise HTTPException(400, "邀请码已达使用上限")
        auto_vip = bool(invite.is_vip)
        invite.used_count += 1

    user = User(
        id=gen_id(),
        username=username,
        email=email,
        password_hash=hash_password(req.password),
        role="user",
        is_vip=auto_vip,
    )
    db.add(user)
    try:
        db.commit()
    except Exception:
        db.rollback()
        raise HTTPException(500, "注册失败，请稍后重试")
    db.refresh(user)
    return {"token": create_token(user.id, user.role), "user": user.to_dict(include_email=True)}


@router.post("/login")
def login(req: LoginReq, request: Request, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.username == req.username.strip()).first()
    if not user or not verify_password(req.password, user.password_hash):
        raise HTTPException(401, "用户名或密码错误")
    if not user.is_active:
        raise HTTPException(403, "账号已被禁用")
    touch_user_activity(db, user, request, "login")
    token = create_token(user.id, user.role)
    return {"token": token, "user": user.to_dict(include_email=True)}


@router.post("/forgot-password")
def forgot_password(req: ForgotPasswordReq, db: Session = Depends(get_db)):
    email = req.email.lower().strip()
    user = db.query(User).filter(User.email == email).first()
    if not user:
        raise HTTPException(404, "该邮箱未注册")
    if len(req.new_password) < 6:
        raise HTTPException(400, "新密码至少 6 位")
    if not verify_code(db, email, req.code.strip(), "reset_password"):
        raise HTTPException(400, "验证码错误或已过期")
    user.password_hash = hash_password(req.new_password)
    db.commit()
    return {"message": "密码已重置，请使用新密码登录"}


@router.get("/me")
def get_me(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    post_count = db.query(func.count(Post.id)).filter(Post.author_id == user.id).scalar()
    comment_count = db.query(func.count(Comment.id)).filter(Comment.author_id == user.id).scalar()
    d = user.to_dict(include_email=True)
    d["post_count"] = post_count
    d["comment_count"] = comment_count
    return d


@router.put("/me")
def update_me(req: UpdateProfileReq, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    if req.avatar is not None:
        user.avatar = req.avatar[:10]
    if req.bio is not None:
        user.bio = req.bio[:500]
    if req.email is not None:
        new_email = req.email.lower().strip()
        if new_email and db.query(User).filter(User.email == new_email, User.id != user.id).first():
            raise HTTPException(400, "邮箱已被其他用户使用")
        user.email = new_email or None
    db.commit()
    db.refresh(user)
    return user.to_dict(include_email=True)


@router.put("/me/password")
def change_password(req: ChangePasswordReq, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    if not verify_password(req.old_password, user.password_hash):
        raise HTTPException(400, "原密码错误")
    if len(req.new_password) < 6:
        raise HTTPException(400, "新密码至少 6 位")
    user.password_hash = hash_password(req.new_password)
    db.commit()
    return {"message": "密码已修改"}


@router.get("/users/{user_id}")
def get_user_profile(user_id: str, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(404, "用户不存在")
    post_count = db.query(func.count(Post.id)).filter(Post.author_id == user.id).scalar()
    d = user.to_dict()
    d["post_count"] = post_count
    return d
