#!/bin/bash
# SWT 避雷系统 - 生产部署脚本
# 构建前端静态文件，由后端 FastAPI 直接 serve

set -e

echo "======================================"
echo "  SWT 避雷情报系统 - 生产构建"
echo "======================================"

# Build frontend
echo "📦 构建前端..."
cd frontend
npm install --silent
npm run build
echo "✅ 前端构建完成 -> frontend/dist/"
cd ..

# Copy dist to backend static folder for serving
mkdir -p backend/static
cp -r frontend/dist/* backend/static/
echo "✅ 静态文件已复制到 backend/static/"

echo ""
echo "🚀 启动生产服务器..."
echo "  访问地址: http://0.0.0.0:8000"
echo "  （修改 HOST/PORT 环境变量来自定义）"
echo ""

cd backend
HOST=${HOST:-0.0.0.0}
PORT=${PORT:-8000}
python3 -m uvicorn serve:app --host $HOST --port $PORT
