#!/bin/bash
# SWT 避雷系统 - 本地开发启动脚本
# 用法: bash start_dev.sh

set -e

echo "======================================"
echo "  SWT 避雷情报系统 - 本地开发模式"
echo "======================================"

# Check Python
if ! command -v python3 &>/dev/null; then
  echo "❌ 需要 Python 3.9+"
  exit 1
fi

# Check Node
if ! command -v node &>/dev/null; then
  echo "❌ 需要 Node.js 18+"
  exit 1
fi

# Install backend deps
echo ""
echo "📦 安装后端依赖..."
cd backend
pip3 install -r requirements.txt --quiet 2>/dev/null || pip install -r requirements.txt --quiet
cd ..

# Install frontend deps
echo "📦 安装前端依赖..."
cd frontend
npm install --silent
cd ..

echo ""
echo "🚀 启动后端 API (port 8000)..."
cd backend && python3 main.py &
BACKEND_PID=$!
cd ..

sleep 2

echo "🚀 启动前端开发服务器 (port 5173)..."
cd frontend && npm run dev &
FRONTEND_PID=$!
cd ..

echo ""
echo "======================================"
echo "✅ 服务已启动！"
echo ""
echo "  前端:  http://localhost:5173"
echo "  后端:  http://localhost:8000"
echo "  API文档: http://localhost:8000/docs"
echo "======================================"
echo ""
echo "按 Ctrl+C 停止所有服务"

# Cleanup on exit
trap "kill $BACKEND_PID $FRONTEND_PID 2>/dev/null; echo '服务已停止'" EXIT INT TERM
wait
