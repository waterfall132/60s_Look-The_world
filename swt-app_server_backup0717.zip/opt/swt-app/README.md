﻿# SWT 避雷情报系统

一个面向 SWT（Summer Work Travel / J1 签证）项目的求职避雷情报平台。
汇集小红书等社媒上的"避雷"信息，结构化展示美国各州 SWT 岗位的踩坑数据，
并提供社区论坛供留学生交流经验、寻找搭子、讨论面签。

前后端分离，支持本地开发与单服务器部署。

---

## 功能总览

### 美签面签助手（公开）
- **面签助手** — 登录后可用，复用 SWT 平台账号，支持题库管理、默认模板导入、JSON 导入导出、随机抽题练习
- **数据库同步** — 每个用户的面签题库保存到数据库，换设备或浏览器后登录同一账号即可继续使用

### 数据可视化（公开）
- **避雷地图** — 美国各州交互式地图，按严重度着色，点击查看该州全部避雷记录（弹窗翻页）
- **数据明细** — 全部避雷记录的可搜索/筛选表格
- **统计分析** — 避雷理由分布、高频岗位、时薪统计、严重度分布

### 账号系统
- **注册** — 用户名 + 密码 + **邮箱验证码**验证（开发模式验证码打印控制台/页面显示）
- **登录** — 用户名 + 密码
- **找回密码** — 邮箱验证码重置
- **个人中心** — emoji 头像、邮箱、简介、改密码
- **我的帖子** — 管理自己发布的内容

### 社区论坛
- **板块** — SWT避雷 / 美国找搭子 / 面签讨论 / 岗位推荐 / 闲聊灌水（可由管理员增删改）
- **发帖 / 回复 / 点赞** — 完整社区互动
- **置顶 / 锁定** — 帖子状态（管理员控制）

### 管理后台（仅管理员）
- **概览** — 用户/帖子/回复/板块/记录统计
- **用户管理** — 提权、禁用、改密、删除（带自我保护）
- **板块管理** — 增删改查
- **帖子审核** — 置顶、锁定、删除任意帖子
- **避雷数据** — 记录增删改查
- **导入导出** — JSON/JSONL 批量导入，JSONL 导出（仅管理员可见可用）

---

## 技术栈

| 层 | 技术 |
|---|---|
| 前端 | Vue 3 + Vite + Vue Router + Pinia |
| 后端 | FastAPI + Uvicorn |
| 数据库 | SQLite（开发）/ PostgreSQL·MySQL（生产，改 `DATABASE_URL` 即可） |
| ORM | SQLAlchemy |
| 认证 | JWT（python-jose）+ bcrypt 密码哈希 |
| 邮件 | SMTP（开发模式模拟发信） |

---

## 项目结构

```
swt-app/
├── backend/
│   ├── main.py            # FastAPI 主应用，挂载所有路由
│   ├── database.py        # SQLAlchemy 模型（records/users/categories/posts/comments/likes/email_codes）
│   ├── auth.py            # JWT + bcrypt + 权限依赖（get_current_user / require_admin）
│   ├── email_service.py   # 发信服务（开发模式打印；SMTP 模板已留）
│   ├── verification.py    # 验证码生成/校验/限流
│   ├── routes_auth.py     # 注册/登录/发码/找回密码/个人资料
│   ├── routes_forum.py    # 板块/帖子/回复/点赞
│   ├── routes_admin.py    # 管理员：用户/板块/帖子管理
│   ├── serve.py           # 生产环境：FastAPI 同时托管前端静态文件
│   └── requirements.txt
├── frontend/
│   ├── src/
│   │   ├── main.js        # 路由 + 路由守卫（登录/管理员拦截）
│   │   ├── App.vue        # 导航布局 + 全局样式
│   │   ├── api/index.js   # axios 客户端（自动注入 token）
│   │   ├── stores/auth.js # Pinia 认证状态
│   │   └── views/         # 所有页面组件
│   └── vite.config.js     # 开发代理 /api → localhost:8000
├── data/
│   └── swt.db             # SQLite 数据库（首次启动自动创建）
├── start_dev.sh           # 一键本地开发（前后端同时起）
├── start_prod.sh          # 一键生产构建 + 单服务部署
└── README.md
```

---

## 快速开始（本地开发）

### 前置要求
- Python 3.9+
- Node.js 18+

### 一键启动
```bash
bash start_dev.sh
```
启动后：
- 前端：http://localhost:5173
- 后端 API：http://localhost:8000
- API 文档（Swagger）：http://localhost:8000/docs

### 手动启动（分别）
```bash
# 后端
cd backend
pip install -r requirements.txt
python main.py              # 自动建表 + 创建默认管理员 + 5 个默认板块

# 前端（另开终端）
cd frontend
npm install
npm run dev
```

### 默认管理员账号
```
用户名: admin
密码:   admin123
```
> ⚠️ 生产环境务必通过 `ADMIN_PASSWORD` 环境变量修改默认密码。

---

## 注册流程（开发模式）

1. 打开 `/register`，填邮箱，点"获取验证码"
2. 验证码会 **① 打印在后端控制台 ② 直接显示在注册页绿色提示框**（开发模式特性，无需真收邮件）
3. 填入验证码 + 用户名 + 密码完成注册

详见 `部署文档.md` 中"切换真实邮件发送"一节。

---

## 数据导入

1. 用管理员账号登录
2. 进入「导入导出」页（仅管理员可见）
3. 上传 JSON 数组或 JSONL 文件

支持的记录格式：
```json
{
  "valuable": true,
  "source_type": "post",
  "job_position": "lifeguard",
  "location_name": "Tennessee",
  "state": "TN",
  "hourly_wage": 13,
  "avoidance_reasons": ["暴晒/户外高温", "工时过长"],
  "severity": 5,
  "summary": "时薪低且暴晒，慎去",
  "note_url": "https://www.xiaohongshu.com/..."
}
```

---

## 生产部署

详见 **`部署文档.md`**，包含：
- 单服务器部署（FastAPI 托管前端）
- 切换 PostgreSQL/MySQL
- 配置真实邮件发送（QQ/163/Gmail）
- Nginx 反向代理 + HTTPS
- systemd 守护进程
- 安全检查清单

快速生产部署：
```bash
bash start_prod.sh        # 构建前端 + 启动单服务（默认 :8000）
```

---

## 环境变量

| 变量 | 默认值 | 说明 |
|---|---|---|
| `DATABASE_URL` | `sqlite:///data/swt.db` | 数据库连接串 |
| `SECRET_KEY` | 开发默认值 | JWT 签名密钥（**生产必改**） |
| `ADMIN_PASSWORD` | `admin123` | 默认管理员密码（**生产必改**） |
| `EMAIL_DEV_MODE` | `true` | 邮件开发模式（true=模拟发信） |
| `SMTP_HOST` / `SMTP_PORT` / `SMTP_USER` / `SMTP_PASSWORD` | — | 真实发信配置 |
| `HOST` / `PORT` | `0.0.0.0` / `8000` | 生产服务监听地址 |

---

## API 一览

| 模块 | 前缀 | 说明 |
|---|---|---|
| 避雷数据 | `/api/records` `/api/stats` `/api/map-data` | 查询公开；增删改需管理员 |
| 导入导出 | `/api/import` `/api/export` | 仅管理员 |
| 认证 | `/api/auth/*` | 注册/登录/发码/找回密码/个人资料 |
| 论坛 | `/api/forum/*` | 板块/帖子/回复/点赞 |
| 管理 | `/api/admin/*` | 仅管理员 |

完整交互式文档：启动后访问 `/docs`。

---

## 备份

SQLite 模式下，直接复制 `data/swt.db` 即可完整备份（含用户、帖子、避雷数据）。
也可通过「导入导出」页导出避雷记录为 JSONL。


